package com.telesat.simulation;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
//import java.security.Timestamp;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.concurrent.TimeUnit;
import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.LinkedHashMap;
import java.util.Date;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.inprocess.InProcessChannelBuilder;
import io.grpc.Grpc;
import io.grpc.InsecureChannelCredentials;
import io.grpc.StatusRuntimeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aalyria.spacetime.api.simulation.v1alpha.SimulationServiceGrpc;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Value;
import com.google.type.Interval;
import com.telesat.feasibility.CIR_Calc;
import com.telesat.feasibility.ThroughputAvailabilityPair;
import com.aalyria.spacetime.api.simulation.v1alpha.SimulationOuterClass;

// LRO
import com.google.longrunning.Operation;
import com.google.longrunning.GetOperationRequest;

// Async gRPC
import io.grpc.stub.StreamObserver;

// Polling
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import io.grpc.CallOptions;
import io.grpc.ClientCall;
import io.grpc.Metadata;

import com.aalyria.spacetime.api.simulation.v1alpha.*;

public class SimulationClient {
    private static final Logger logger = LoggerFactory.getLogger(SimulationClient.class);
    
    private final ManagedChannel channel;
    private final SimulationServiceGrpc.SimulationServiceBlockingStub blockingStub;
    private final SimulationServiceGrpc.SimulationServiceStub asyncStub;
    
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();

    private SimulationConfiguration conf;

    /* To keep path based CIR-average stats provided through Analysis.
       The key is the path-name. 
       LinkedHasMap is used to have insertion-ordered data which is 
       effective on iteration (iteration order) 
       NOTE: We use ArrayList to store values wit assumption that a path
             may not be included in some AnalysisSegment, so if we use
             Double[], some values may have zero value. But, in this way
             we skip some possible 'no-value' cases (!?)
    */
    Map<String, ArrayList<Double>> pathStats = new LinkedHashMap<>();

    /**
     * Construct client connecting to the server at {@code host:port}.
     */
    public SimulationClient(String host, int port) {
        this(ManagedChannelBuilder.forAddress(host, port)
                // Channels are secure by default (via SSL/TLS). For the example we disable TLS to avoid
                // needing certificates.
                .usePlaintext()
                .build());
    }

    /**
     * Construct client connecting to an in-process server by name (no network sockets).
     */
    public static SimulationClient forInProcess(String inProcessName) {
        ManagedChannel ch = InProcessChannelBuilder.forName(inProcessName)
                .directExecutor()
                .build();
        return new SimulationClient(ch);
    }
    
    /**
     * Construct client for accessing SimulationService using the existing channel.
     */
    SimulationClient(ManagedChannel channel) {
        this.channel = channel;
        blockingStub = SimulationServiceGrpc.newBlockingStub(channel);
        asyncStub = SimulationServiceGrpc.newStub(channel);
    }
    
    /**
     * Shutdown the channel
     */
    public void shutdown() throws InterruptedException {
        channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
    }
    
    public int createScenario(String scenarioId, String scenarioName, String description) {
        logger.info("Creating scenario: '{}' with name: '{}' with desription: '{}'", 
                    scenarioId, scenarioName, description);

        Scenario sc = Scenario.newBuilder()
                                                                        .setName(scenarioName)
                                                                        .setDescription(description)
                                                                        .build();
        CreateScenarioRequest request = CreateScenarioRequest.newBuilder()
                                                                                                       .setScenarioId(scenarioId)
                                                                                                       .setScenario(sc)
                                                                                                       .build();
        
        try {
            Scenario response = blockingStub.createScenario(request);
            logger.info("CreateScenario response: scenario-name='{}', description='{}'", 
                        response.getName(), response.getDescription());
        } 
        catch (StatusRuntimeException e) {
            logger.error("RPC failed: {}", e.getStatus());
            return 1;
        }

        return 0;
    } 

    /* proto format of GetScenario:
     * message GetScenarioRequest {
     *   // Required. The name of the scenario to retrieve.
     *   // Format: scenarios/{scenario}
     *   string name = 1;
     * }
     * We consider 'scenarioName' is not int the for above, so it will be prefixed with 'scenarios/'
     */
    public Scenario getScenario(String scenarioName) {
        logger.info("Get scenario with name: '{}'", scenarioName);

        String formedScName = "scenarios/" + scenarioName;
        GetScenarioRequest request = GetScenarioRequest.newBuilder()
                                                                                                 .setName(formedScName)
                                                                                                 .build();
        try {
            Scenario response = blockingStub.getScenario(request);
            logger.info("GetScenario response: scenario-name='{}', description='{}'", 
                        response.getName(), response.getDescription());
            return response;
        } 
        catch (StatusRuntimeException e) {
            logger.error("RPC failed: {}", e.getStatus());
            /* Return an empty Scenario instance */
            return Scenario.newBuilder().setName("").build();
        }
    }

    /* Creates Simulation instance with specified attributes, 
     * which is ready for sending create-simulation request to the server.
     * 'startSeconds' and 'startNanos', 'endSeconds' and 'endTime' shall indicate timestamps for the 'interval'
     * */
    public Simulation createSimulation(String simulationName, long startSeconds, int startNanos, long endSeconds, int endNanos) {

        logger.info("Create simulation with simulation-name: '{}', start-seconds: '{}', start-nanos: '{}', end-seconds: '{}', end-nanos: '{}'",
                    simulationName, startSeconds, startNanos, endSeconds, endNanos);

        com.google.protobuf.Timestamp stimestamp = com.google.protobuf.Timestamp.newBuilder().setSeconds(startSeconds).setNanos(startNanos).build();
        com.google.protobuf.Timestamp etimestamp = com.google.protobuf.Timestamp.newBuilder().setSeconds(endSeconds).setNanos(endNanos).build();
        
        String simname = "simulations/" + simulationName;
        com.google.type.Interval interval = com.google.type.Interval.newBuilder().setStartTime(stimestamp).setEndTime(etimestamp).build();
        /* 'scenario' attribute will be assigned when this simuation is attached to a scenario */
        return Simulation.newBuilder().setName(simname).setInterval(interval).build();
    }

    /* Sends a create-smimulation request to the server for creation a simulation for the scenario specified with 'scenarioName' */
    public com.google.longrunning.Operation createSimulationForScenario(String scenarioName, String simulationId, Simulation simulation) {

        logger.info("Create simulation with scenario-name: '{}', simulation-id: '{}', name: '{}', start-time: '{}', end-time: '{}'",
                    scenarioName, simulationId, simulation.getName(), 
                    simulation.getInterval().getStartTime().getSeconds() + "_" + simulation.getInterval().getStartTime().getNanos(),
                    simulation.getInterval().getEndTime().getSeconds() + "_" + simulation.getInterval().getEndTime().getNanos());

        String snname = "scenarios/" + scenarioName;
        /* TODO: This method (update fields of a built message) may not be good way for realtime performance purposes. 
                 We may choose another approach. 
         */
        Simulation upsim = simulation.toBuilder().setScenario(snname).build(); 
        CreateSimulationRequest request = CreateSimulationRequest.newBuilder()
                                                                                                           .setSimulationId(simulationId)
                                                                                                           .setSimulation(upsim)
                                                                                                           .build();
        try {
            com.google.longrunning.Operation response = blockingStub.createSimulation(request);
            logger.info("Response to CreateSimulationRequest: operation-name='{}', is-done:='{}', code='{}'", 
                        response.getName(), response.getDone(), response.getError().getCode());
            return response;
        } 
        catch (StatusRuntimeException e) {
            logger.error("RPC failed: {}", e.getStatus());
            /* Return an errored operation. */
            com.google.rpc.Status status = com.google.rpc.Status.newBuilder()
                                                                .setCode(com.google.rpc.Code.DEADLINE_EXCEEDED_VALUE)
                                                                .setMessage("Runtime exception: " + e.getMessage())
                                                                .build();
            return com.google.longrunning.Operation.newBuilder().setName("").setDone(true).setError(status).build();
        }
    }

    /* Although it is not clear that 'name' attribute shall be based on simulation-id used during creation or name attribute
       of the simulation, we consider it as name attribute */
    public Simulation getSimulation(String simulationName) {
        logger.info("Get simulation with name: '{}'", simulationName);

        String formedSimName = "simulations/" + simulationName;
        GetSimulationRequest request = GetSimulationRequest.newBuilder()
                                                                                                     .setName(formedSimName)
                                                                                                     .build();
        try {
            Simulation response = blockingStub.getSimulation(request);
            logger.info("getSimulation response: simulation-name='{}', scenario-name='{}', state='{}', " +
                        "create-timestamp='{}', interval=(start='{}_{}', end='{}_{})", 
                        response.getName(), response.getScenario(), response.getState(), response.getCreateTime(), 
                        response.getInterval().getStartTime().getSeconds(), response.getInterval().getStartTime().getNanos(),
                        response.getInterval().getEndTime().getSeconds(), response.getInterval().getEndTime().getNanos());
            return response;
        } 
        catch (StatusRuntimeException e) {
            logger.error("RPC failed: {}", e.getStatus());
            /* Return an empty Scenario instance */
            return Simulation.newBuilder().setName("").build();
        }

    }

    public void createSimulationAsync(
        String simulationName,
        CreateSimulationRequest request) {

        asyncStub.createSimulation(
            request,
            new StreamObserver<Operation>() {

                @Override
                public void onNext(Operation operation) {
                    System.out.println(
                        "Simulation creation started. Operation = " + operation.getName());

                    pollSimulationUntilDone(simulationName);
                }

                @Override
                public void onError(Throwable t) {
                    System.err.println("CreateSimulation failed");
                    t.printStackTrace();
                }

                @Override
                public void onCompleted() {
                    // noop
                }
            }
        );
    }

    
    private void pollSimulationUntilDone(String simulationName) {

        Runnable pollTask = () -> {
            try {
                Simulation sim =
                    getSimulation(simulationName);

                if (sim.getState()
                        == Simulation.State.SUCCEEDED) {

                    System.out.println("Simulation DONE: " + sim.getName());
                    scheduler.shutdown();

                } else {
                    System.out.println(
                        "Simulation still running, state=" + sim.getState());
                }

            } catch (Exception e) {
                System.err.println("Polling failed: " + e.getMessage());
            }
        };

        scheduler.scheduleAtFixedRate(pollTask, 0, 3, TimeUnit.SECONDS);
    }

    
    

    /* Creates an Analysis instance for local usage, from client side point of view */
    public Analysis constructAnalysis(String scenarioName, String analysisName, 
                                                            com.google.type.Interval interval, com.google.protobuf.Duration resolution) {

        logger.info("Constructing Analysis object for scenario: '{}' with name: '{}' for start: '{}_{}' and end: '{}_{}' interval with resolution: '{}_{}'",
                    scenarioName, analysisName, interval.getStartTime().getSeconds(), interval.getStartTime().getNanos(),
                    interval.getEndTime().getSeconds(), interval.getEndTime().getNanos(),
                    resolution.getSeconds(), resolution.getNanos());

        // name shall be in the form of 'scenarios/{scenario}/analyses/{analysis}'
        String name = "scenarios/" + scenarioName + "/analyses/" + analysisName;
        return Analysis.newBuilder()
                                            .setName(name)
                                            .setInterval(interval)
                                            .setResolution(resolution)
                                            .build();
    }

    /* 'parent' shall be in the form of 'simulations/{simulation}' as indicating the simulation in which this analysis will be created. */
    public Analysis createAnalysis(String simulation, String id, Analysis analysis) {

        logger.info("Create analysis with id: '{}' and name: '{}' for simulation: '{}' with interval: '{}_{}-{}_{}' and resolution: '{}_{}'",
                    id, analysis.getName(), simulation, 
                    analysis.getInterval().getStartTime().getSeconds(), analysis.getInterval().getStartTime().getNanos(), 
                    analysis.getInterval().getEndTime().getSeconds(), analysis.getInterval().getEndTime().getNanos(),
                    analysis.getResolution().getSeconds(), analysis.getResolution().getNanos());

        /* 'parent' of the request shall be in the form of 'simulations/{simulation}' */
        String parent = "simulations/" + simulation;
        CreateAnalysisRequest request = CreateAnalysisRequest.newBuilder()
                                                                                                       .setParent(parent)
                                                                                                       .setAnalysisId(id)
                                                                                                       .setAnalysis(analysis)
                                                                                                       .build();

        try {
            Analysis response = blockingStub.createAnalysis(request);
            logger.info("Got response for 'createAnalysis with name: '{}' ", response.getName());
            return response;
        }
        catch (StatusRuntimeException e) {
            logger.error("createAnalysis: RPC failed: {}", e.getStatus());
            /* Return an empty Scenario instance */
            return null; 
        }
    }

    public Analysis getAnalysis(String analysisName, String parentSimulation) {
        logger.info("getAnalysis: Get request for analysis: '{}' for parent simulation: '{}'", analysisName, parentSimulation);

        /* 'name' of the request shall be in the form of 'simulations/{simulation}/analyses/{analysis}' */
        String name = "simulations/" + parentSimulation + "/analyses/" + analysisName;
        GetAnalysisRequest request = GetAnalysisRequest.newBuilder()
                                                                                                 .setName(name)
                                                                                                 .build();
        try {
            Analysis response = blockingStub.getAnalysis(request);
            logger.info("Got response for 'getAnalysis with name: '{}' ", response.getName());
            return response;
        }
        catch (StatusRuntimeException e) {
            logger.error("getAnalysis: RPC failed: {}", e.getStatus());
            /* Return an empty Scenario instance */
            return null; 
        }
    }

    @SuppressWarnings("unused")
    public void putIntoPathData(String pathName, int asegmentIdx, int pathIdx, double value) {
       ArrayList<Double> vals = this.pathStats.computeIfAbsent(pathName, k -> new ArrayList<Double>());
       vals.add(value);
    }

    /* Logs details of analysis and to process on provided anaysis data as collecting CIR average values into 'pathStats' per path */
    public void detailsOfAnalysis(Analysis analysis) {
        List<AnalysisSegment> analysisList = analysis.getSegmentsList();
        int anSegmentCount = (analysisList != null) ? analysisList.size() : 0;
        logger.info("detailsOfAnaysis: Successfully created Analysis with name: '{}', analysis-segment count: '{}'", analysis.getName(), anSegmentCount);
        for (int i = 0; i < anSegmentCount; i++) {
            AnalysisSegment aSegment = analysisList.get(i);
            List<P2pSrTePolicyCandidatePathStats> paths = aSegment.getP2PSrTePolcyCandidatePathStatsList();
            logger.info("detailsOfAnalysis: Number of paths: '{}'", paths.size());
            for (int j = 0; j < paths.size(); j++) {
                P2pSrTePolicyCandidatePathStats stats = paths.get(j);
                putIntoPathData(stats.getPath(), i, j, stats.getCirAvgBps());
                logger.info("detailsOfAnalysis: path({}) stats [{}, {}] -- \n" +
                            "    CIR.average: '{}', CIR.stddev: '{}', CIR.min: '{}', CIR.max: '{}', CIR.percentile: '{}'\n" +
                            "    EIR.average: '{}', EIR.stddev: '{}', EIR.min: '{}', EIR.max: '{}', EIR.percentile: '{}'\n" +
                            "    FD.average: '{}_{}', FD.stddev: '{}_{}', FD.min: '{}_{}', FD.max: '{}_{}', FD.percentile: '{}'\n" +
                            "    IFDV.average: '{}_{}', IFDV.stddev: '{}_{}', IFDV.min: '{}_{}', IFDV.max: '{}_{}', IFDV.percentile: '{}'\n",
                            stats.getPath(), i, j,
                            String.format("%.3f", stats.getCirAvgBps()), String.format("%.3f", stats.getCirStddevBps()), 
                            String.format("%.3f", stats.getCirMinBps()), String.format("%.3f", stats.getCirMaxBps()), String.format("%.3f", stats.getCirPercentile()),
                            String.format("%.3f", stats.getEirAvgBps()), String.format("%.3f", stats.getEirStddevBps()), 
                            String.format("%.3f", stats.getEirMinBps()), String.format("%.3f", stats.getEirMaxBps()), String.format("%.3f", stats.getEirPercentile()),
                            stats.getFrameDelayAvg().getSeconds(), stats.getFrameDelayAvg().getNanos(), 
                            stats.getFrameDelayStddev().getSeconds(), stats.getFrameDelayStddev().getNanos(),
                            stats.getFrameDelayMin().getSeconds(), stats.getFrameDelayMin().getNanos(),
                            stats.getFrameDelayMax().getSeconds(), stats.getFrameDelayMax().getNanos(),
                            stats.getFrameDelayPercentile(),
                            stats.getIfdvAvg().getSeconds(), stats.getIfdvAvg().getNanos(), 
                            stats.getIfdvStddev().getSeconds(), stats.getIfdvStddev().getNanos(),
                            stats.getIfdvMin().getSeconds(), stats.getIfdvMin().getNanos(),
                            stats.getIfdvMax().getSeconds(), stats.getIfdvMax().getNanos(),
                            stats.getIfdvPercentile());
            }
        }
        /* Dump collected CIR averages per path */
        System.out.println("Collected path data:\n" + this.pathStats);
    }

    public long determineSlaCirValue(String analysisName, String simulationName) {
        /* Returns SLA-CIR value configured for analysis or simulation. 
           Configuration for analysis has priority over the one of simulation */
        long slaCir = this.conf.getAnalysisSlaCir(analysisName);
        if (slaCir == 0) {
            slaCir = this.conf.getSimulationSlaCir(simulationName);
        }
        if (slaCir == 0) {
            logger.error("determineSlaCir: No SLA-CIR value configured either analysis: '{}' or simulation: '{}'", analysisName, simulationName);
        }
        return slaCir;
    }

    public ThroughputAvailabilityPair[] determineThroughputAvailabilityPairs(String analysisName, String simulationName) {
        /* Returns TA-pairt configured for analysis or simulation. 
           Configuration for analysis has priority over the one of simulation */
        ThroughputAvailabilityPair[] taPairs = this.conf.getAnalysisTAPairs(analysisName);
        if (taPairs.length == 0) {
            taPairs = this.conf.getSimulationTAPairs(simulationName);
        }
        if (taPairs.length == 0) {
            logger.error("determineThroughputAvailabilityPairs: No SLA-CIR value configured either analysis: '{}' or simulation: '{}'", 
                         analysisName, simulationName);
        }
        StringBuilder logstr = new StringBuilder();
        double total = 0.0;
        for (int i = 0; i < taPairs.length; i++) {
            logstr.append("[").append(Integer.toString(i)).append("]: ").append(taPairs[i]).append("\n");
            total += taPairs[i].getThroughput();
        }
        logger.info("Total: {}\n {}", total, logstr);
        return taPairs;
    }

    /**
     * Run a complete simulation workflow
     * @throws InterruptedException 
     * @throws InvalidProtocolBufferException 
     */
    public void runSimulationWorkflow() throws InterruptedException, InvalidProtocolBufferException {
        String scenarioId = "test-scenario-1:" + System.currentTimeMillis();
        String scenarioName = "test-scenario-1";
        String scenarioDescription = "Test for Spacetime scenario API.";

        String simulationName = "test-simulation-1";
        String simulationId = simulationName + ":" + System.currentTimeMillis();

        logger.info("=== Starting Simulation Workflow ===");
        
        // 1. Create scenario
        createScenario(scenarioId, scenarioName, scenarioDescription);
        Thread.sleep(1000);
        // Second try to create
        createScenario(scenarioId, scenarioName, scenarioDescription);
        
        // Get scenario
        Scenario gsc = getScenario(scenarioName);
        logger.info("Got scenario for name: '{}' -- scenario-name: '{}', description: '{}'",
                    scenarioName, gsc.getName(), gsc.getDescription());

        // 3. Create Simulation
        /* TODO: 'seconds' and 'nanos' for time values shall be provided through DateTime objects for both start-time and end-time */
        // If we compute Timestamp from`System.currentTimeMillis()`.
        long millis = System.currentTimeMillis();
        long seconds = millis/ 1000;
        int nanos = (int)((millis % 1000) * 1000000);
        logger.info("Timestamps by using currentTimeMillis: seconds: '{}', nanos: '{}'", seconds, nanos);
        // If we compute Timestamp from `Instant.now()`.
        Instant now = Instant.now();
        seconds = now.getEpochSecond();
        nanos = now.getNano();
        // logger.info("Now: timestamp: '{}_{}' -- '{}'", now.getEpochSecond(), now.getNano(), now);
        // Instant now5 = now.plusSeconds(5);
        // logger.info("Now+5: timestamp: '{}_{}' -- '{}'", now5.getEpochSecond(), now5.getNano(), now5);
        // Instant now25 = now.plusSeconds(25);
        // logger.info("Now+25: timestamp: '{}_{}' -- '{}'", now25.getEpochSecond(), now25.getNano(), now25);
        logger.info("Timestamps by using Instant.now(): seconds: '{}', nanos: '{}'", seconds, nanos);
        /* Create simulation starting 5 seconds later from 'now' for 20 seconds */
        //SimulationOuterClass.Simulation sim  = createSimulation(simulationName, now.plusSeconds(5).getEpochSecond(), nanos, 
        //                                                        now.plusSeconds(25).getEpochSecond(), nanos);
        //Instant simSt = this.conf.getSimulationStartTime(0);
        //Instant simEt = this.conf.getSimulationEndTime(0);
        Instant simSt = this.conf.getSimulationStartTimeAsInstant(simulationName);
        Instant simEt = this.conf.getSimulationEndTimeAsInstant(simulationName);
        Simulation sim  = createSimulation(simulationName, simSt.getEpochSecond(), simSt.getNano(), 
                                                                simEt.getEpochSecond(), simEt.getNano());
                                                    
        com.google.longrunning.Operation op1 = createSimulationForScenario(scenarioName, simulationId, sim);
        logger.info("Result of simulation creation -- operation-nmae: '{}', is-done: '{}'",
                    op1.getName(), op1.getDone());
        if ((op1.hasMetadata()) && (op1.getMetadata().is(CreateSimulationMetadata.class))) {
            CreateSimulationMetadata metadata = op1.getMetadata().unpack(CreateSimulationMetadata.class);
            logger.info("Received percentage of processing through metadata: '{}%'", metadata.getProgressPercent());
        }

        // 3a. Re-create simulation (to test progress-percent increase)
        op1 = createSimulationForScenario(scenarioName, simulationId, sim);
        logger.info("(2) Result of simulation creation -- operation-name: '{}', is-done: '{}'",
                    op1.getName(), op1.getDone());
        if ((op1.hasMetadata()) && (op1.getMetadata().is(CreateSimulationMetadata.class))) {
            CreateSimulationMetadata metadata = op1.getMetadata().unpack(CreateSimulationMetadata.class);
            logger.info("(2): Received percentage of processing through metadata: '{}%'", metadata.getProgressPercent());
        }

        // 3b. Re-create simulation (to test progress-percent increase)
        op1 = createSimulationForScenario(scenarioName, simulationId, sim);
        logger.info("(3) Result of simulation creation -- operation-name: '{}', is-done: '{}'",
                    op1.getName(), op1.getDone());
        if ((op1.hasMetadata()) && (op1.getMetadata().is(CreateSimulationMetadata.class))) {
            CreateSimulationMetadata metadata = op1.getMetadata().unpack(CreateSimulationMetadata.class);
            logger.info("(3): Received percentage of processing through metadata: '{}%'", metadata.getProgressPercent());
        }

        // Get Simulation
        Simulation gsim  = getSimulation(simulationName);
        logger.info("Received simulation due to 'getSimulation' with name: '{}'", gsim.getName());

        // Create anaysis
        String analysisName = "test-analysis-1.1";
        /* TODO: Interval and resolution parameters shall be built through DateTime objects */
        /* Use time interval determined for simulation */
        //com.google.protobuf.Timestamp istt = com.google.protobuf.Timestamp.newBuilder().setSeconds(System.currentTimeMillis()/1000).setNanos(0).build();
        //com.google.protobuf.Timestamp iett = com.google.protobuf.Timestamp.newBuilder().setSeconds(istt.getSeconds() + 20).setNanos(0).build();

        //com.google.protobuf.Timestamp istt = com.google.protobuf.Timestamp.newBuilder().setSeconds(now.plusSeconds(5).getEpochSecond()).setNanos(nanos).build();
        //com.google.protobuf.Timestamp iett = com.google.protobuf.Timestamp.newBuilder().setSeconds(now.plusSeconds(25).getEpochSecond()).setNanos(nanos).build();

        //Instant anlSt = this.conf.getAnalysisStartTime(0);
        //Instant anlEt = this.conf.getAnalysisEndTime(0);
        Instant anlSt = this.conf.getAnalysisStartTimeAsInstant(analysisName);
        Instant anlEt = this.conf.getAnalysisEndTimeAsInstant(analysisName);
        com.google.protobuf.Timestamp istt = com.google.protobuf.Timestamp.newBuilder().setSeconds(anlSt.getEpochSecond()).setNanos(anlSt.getNano()).build();
        com.google.protobuf.Timestamp iett = com.google.protobuf.Timestamp.newBuilder().setSeconds(anlEt.getEpochSecond()).setNanos(anlEt.getNano()).build();

        com.google.type.Interval anInterval = com.google.type.Interval.newBuilder().setStartTime(istt).setEndTime(iett).build();

        //com.google.protobuf.Duration anResolution = com.google.protobuf.Duration.newBuilder().setSeconds(1).setNanos(0).build();
        //com.google.protobuf.Duration anResolution = com.google.protobuf.Duration.newBuilder().setSeconds(this.conf.getResolution().getSeconds())
        //                                                                                     .setNanos(this.conf.getResolution().getNano()).build();
        Duration anlResDur = this.conf.getAnalysisResolutionAsDuration(analysisName); 
        com.google.protobuf.Duration anResolution = com.google.protobuf.Duration.newBuilder().setSeconds(anlResDur.getSeconds())
                                                                                             .setNanos(anlResDur.getNano()).build();
        Analysis anInstance = constructAnalysis(scenarioName, analysisName, anInterval, anResolution);

        String analysisId = analysisName + ":" + System.currentTimeMillis();
        Analysis analysis = createAnalysis(simulationName, analysisId, anInstance);
        if (analysis == null) {
            logger.warn("Cannot create an Analysis successfully with name: '{}' for simulation: '{}' of scenario: '{}'",
                        analysisName, simulationName, scenarioName);
        }
        else {
            List<AnalysisSegment> analysisList = analysis.getSegmentsList();
            int anSegmentCount = (analysisList != null) ? analysisList.size() : 0;
            logger.info("Successfully created Analysis with name: '{}', analysis-segment count: '{}'", analysisName, anSegmentCount);
            detailsOfAnalysis(analysis);
            long slaCIR = determineSlaCirValue(analysisName, simulationName);
            //ThroughputAvailabilityPair[] taPairs =  { new ThroughputAvailabilityPair(0.3, 99.0),
            //                                          /*new ThroughputAvailabilityPair(0.5, 95.0),*/
            //                                          new ThroughputAvailabilityPair(0.2, 99.5) };
            ThroughputAvailabilityPair[] taPairs =  determineThroughputAvailabilityPairs(analysisName, simulationName);
            for (Map.Entry<String, ArrayList<Double>> entry : this.pathStats.entrySet()) {
                logger.info("Calculation CIR for path: '{}' -- {}", entry.getKey(), entry.getValue());
                /* We need to convert the data to primitive double[] */
                double[] tputs = java.util.Arrays.stream(entry.getValue().toArray(new Double[0]))
                                          .mapToDouble(Double::doubleValue)
                                          .toArray();

                boolean feasibility = CIR_Calc.CalculateCIRFeasibility(tputs, 0, tputs.length, false, taPairs,
                                                                       95.0, 99.0, slaCIR);
                logger.info("Path <{}> is {}", entry.getKey(), ((feasibility) ? "feasible" : "infeasible"));
            }
        }

        
        long diff = anInterval.getEndTime().getSeconds() - anInterval.getStartTime().getSeconds();
        logger.info("Diff: '{}'", diff);

        // Get Analysis
        Analysis ganalysis = getAnalysis(analysisName, simulationName);
        if (ganalysis == null) {
            logger.warn("Cannot get an Analysis successfully with name: '{}' for simulation: '{}'",
                        analysisName, simulationName);
        }
        else {
            logger.info("Successfully get Analysis with name: '{}'", ganalysis.getName());
        }

        logger.info("=== Simulation Workflow Complete ===");
    }

    public void readConfiguration(String confFileName) {
        //this.conf = new SimulationConfiguration(confFileName);
        //this.conf.parseAsProperties();
        //SimulationConfiguration config = new SimulationConfiguration("config/sim_config.json");
        //config.parseForJson();
        this.conf = new SimulationConfiguration(confFileName);
        this.conf.parseForJson();
    }

    /**
     * Main method to run the client
     */
    public static void main(String[] args) throws Exception {
        String host = "localhost";
        int port = 50051;
        String inProcessName = null;
        String target = null; // e.g., "localhost:50051"

        //String confFileName = "config/sim.properties";
        String confFileName = "config/sim_config.json";

        for (int i = 0; i < args.length; i++) {
            if ("--inprocess".equals(args[i]) && i + 1 < args.length) {
                inProcessName = args[i + 1];
                i++;
            } 
            else if ("--target".equals(args[i]) && i + 1 < args.length) {
                target = args[i + 1];
                i++;
            } 
            else if (i == 0 && !args[i].startsWith("--")) {
                // If the first arg contains a colon, treat it as full target
                if (args[i].contains(":")) {
                    target = args[i];
                } else {
                    host = args[i];
                }
            } 
            else if (i == 1 && !args[i].startsWith("--")) {
                port = Integer.parseInt(args[i]);
            }
        }

        SimulationClient client;
        if (inProcessName != null) {
            client = SimulationClient.forInProcess(inProcessName);
        } 
        else if (target != null) {
            ManagedChannel ch = Grpc.newChannelBuilder(target, InsecureChannelCredentials.create()).build();
            client = new SimulationClient(ch);
        } 
        else {
            client = new SimulationClient(host, port);
        }
        client.readConfiguration(confFileName);

         java.util.Scanner scanner = new java.util.Scanner(System.in);
        try {
            boolean running = true;
            while (running) {
                System.out.println("\n=== Simulation Demo Menu ===");
                System.out.println("1) Run full simulation workflow");
                System.out.println("2) Create scenario");
                System.out.println("3) Get scenario");
                System.out.println("4) Create simulation for a scenario");
                System.out.println("5) Get simulation");
                System.out.println("6) Create analysis for a simulation");
                System.out.println("7) Get analysis");
                System.out.println("8) Async Mech");
                System.out.println("0) Exit");
                System.out.print("Enter your choice: ");

                String choice = scanner.nextLine().trim();

                try {
                    switch (choice) {
                        case "1":
                            // Full workflow
                            client.runSimulationWorkflow();
                            break;

                        case "2": {
                            // Create scenario
                            System.out.print("Scenario ID (leave empty for auto): ");
                            String scenarioId = scanner.nextLine().trim();
                            if (scenarioId.isEmpty()) {
                                scenarioId = "scenario-" + System.currentTimeMillis();
                            }

                            System.out.print("Scenario name (e.g. test-scenario): ");
                            String scenarioName = scanner.nextLine().trim();
                            if (scenarioName.isEmpty()) {
                                scenarioName = "test-scenario";
                            }

                            System.out.print("Scenario description: ");
                            String desc = scanner.nextLine().trim();
                            if (desc.isEmpty()) {
                                desc = "Demo scenario";
                            }

                            int rc = client.createScenario(scenarioId, scenarioName, desc);
                            System.out.println("createScenario returned: " + rc);
                            break;
                        }

                        case "3": {
                            // Get scenario
                            System.out.print("Scenario name (without prefix, e.g. test-scenario): ");
                            String gScName = scanner.nextLine().trim();
                            if (gScName.isEmpty()) {
                                gScName = "test-scenario";
                            }
                            Scenario sc = client.getScenario(gScName);
                            System.out.println("GetScenario -> name: " + sc.getName() +
                                               ", description: " + sc.getDescription());
                            break;
                        }

                        case "4": {
                            // Create simulation for a scenario
                            System.out.print("Scenario name (without prefix, e.g. test-scenario): ");
                            String scnName = scanner.nextLine().trim();
                            if (scnName.isEmpty()) {
                                scnName = "test-scenario";
                            }

                            System.out.print("Simulation name (e.g. test-simulation): ");
                            String simName = scanner.nextLine().trim();
                            if (simName.isEmpty()) {
                                simName = "test-simulation";
                            }

                            System.out.print("Simulation ID (leave empty for auto): ");
                            String simId = scanner.nextLine().trim();
                            if (simId.isEmpty()) {
                                simId = simName + ":" + System.currentTimeMillis();
                            }

                            System.out.print("Start offset in seconds (default 5): ");
                            String offStartStr = scanner.nextLine().trim();
                            long offStart = offStartStr.isEmpty() ? 5L : Long.parseLong(offStartStr);

                            System.out.print("Duration in seconds (default 20): ");
                            String durationStr = scanner.nextLine().trim();
                            long duration = durationStr.isEmpty() ? 20L : Long.parseLong(durationStr);

                            Instant now = Instant.now();
                            long startSec = now.plusSeconds(offStart).getEpochSecond();
                            long endSec = now.plusSeconds(offStart + duration).getEpochSecond();
                            int nanos = now.getNano();

                            Simulation sim =
                                client.createSimulation(simName, startSec, nanos, endSec, nanos);
                            com.google.longrunning.Operation op =
                                client.createSimulationForScenario(scnName, simId, sim);

                            System.out.println("CreateSimulation -> operation name: " + op.getName() +
                                               ", done: " + op.getDone());
                            break;
                        }

                        case "5": {
                            // Get simulation
                            System.out.print("Simulation name (without prefix, e.g. test-simulation): ");
                            String gSimName = scanner.nextLine().trim();
                            if (gSimName.isEmpty()) {
                                gSimName = "test-simulation";
                            }
                            Simulation gsim = client.getSimulation(gSimName);
                            System.out.println("GetSimulation -> name: " + gsim.getName() +
                                               ", scenario: " + gsim.getScenario() +
                                               ", state: " + gsim.getState());
                            break;
                        }

                        case "6": {
                            // Create analysis for a simulation
                            System.out.print("Scenario name (without prefix, e.g. test-scenario): ");
                            String aScName = scanner.nextLine().trim();
                            if (aScName.isEmpty()) {
                                aScName = "test-scenario";
                            }

                            System.out.print("Parent simulation name (without prefix, e.g. test-simulation): ");
                            String parentSim = scanner.nextLine().trim();
                            if (parentSim.isEmpty()) {
                                parentSim = "test-simulation";
                            }

                            System.out.print("Analysis name (e.g. test-analysis): ");
                            String anName = scanner.nextLine().trim();
                            if (anName.isEmpty()) {
                                anName = "test-analysis";
                            }

                            System.out.print("Start offset in seconds (default 5): ");
                            String aOffStartStr = scanner.nextLine().trim();
                            long aOffStart = aOffStartStr.isEmpty() ? 5L : Long.parseLong(aOffStartStr);

                            System.out.print("Duration in seconds (default 20): ");
                            String aDurationStr = scanner.nextLine().trim();
                            long aDuration = aDurationStr.isEmpty() ? 20L : Long.parseLong(aDurationStr);

                            System.out.print("Resolution in seconds (default 1): ");
                            String resStr = scanner.nextLine().trim();
                            long resSec = resStr.isEmpty() ? 1L : Long.parseLong(resStr);

                            Instant nowA = Instant.now();
                            com.google.protobuf.Timestamp st =
                                com.google.protobuf.Timestamp.newBuilder()
                                    .setSeconds(nowA.plusSeconds(aOffStart).getEpochSecond())
                                    .setNanos(nowA.getNano())
                                    .build();
                            com.google.protobuf.Timestamp et =
                                com.google.protobuf.Timestamp.newBuilder()
                                    .setSeconds(nowA.plusSeconds(aOffStart + aDuration).getEpochSecond())
                                    .setNanos(nowA.getNano())
                                    .build();

                            com.google.type.Interval interval =
                                com.google.type.Interval.newBuilder()
                                    .setStartTime(st)
                                    .setEndTime(et)
                                    .build();

                            com.google.protobuf.Duration resolution =
                                com.google.protobuf.Duration.newBuilder()
                                    .setSeconds(resSec)
                                    .setNanos(0)
                                    .build();

                            Analysis an =
                                client.constructAnalysis(aScName, anName, interval, resolution);
                            String anId = anName + ":" + System.currentTimeMillis();

                            Analysis createdAn =
                                client.createAnalysis(parentSim, anId, an);
                            if (createdAn == null) {
                                System.out.println("Analysis could not be created.");
                            } else {
                                System.out.println("Analysis created: " + createdAn.getName());
                                client.detailsOfAnalysis(createdAn);
                            }
                            break;
                        }

                        case "7": {
                            // Get analysis
                            System.out.print("Analysis name (without prefix, e.g. test-analysis): ");
                            String gaName = scanner.nextLine().trim();
                            if (gaName.isEmpty()) {
                                gaName = "test-analysis";
                            }

                            System.out.print("Parent simulation name (without prefix, e.g. test-simulation): ");
                            String gParentSim = scanner.nextLine().trim();
                            if (gParentSim.isEmpty()) {
                                gParentSim = "test-simulation";
                            }

                            Analysis gan = client.getAnalysis(gaName, gParentSim);
                            if (gan == null) {
                                System.out.println("Analysis not found.");
                            } else {
                                System.out.println("GetAnalysis -> name: " + gan.getName());
                                client.detailsOfAnalysis(gan);
                            }
                            break;
                        }

                        case "8": {
                            System.out.println("=== CreateScenario + ASYNC CreateSimulation ===");

                            // Create scenario
                            System.out.print("Scenario ID (leave empty for auto): ");
                            String scenarioId = scanner.nextLine().trim();
                            if (scenarioId.isEmpty()) {
                                scenarioId = "scenario-" + System.currentTimeMillis();
                            }

                            System.out.print("Scenario name (e.g. test-scenario): ");
                            String scenarioName = scanner.nextLine().trim();
                            if (scenarioName.isEmpty()) {
                                scenarioName = "test-scenario";
                            }

                            System.out.print("Scenario description: ");
                            String desc = scanner.nextLine().trim();
                            if (desc.isEmpty()) {
                                desc = "Demo scenario";
                            }

                            int rc = client.createScenario(scenarioId, scenarioName, desc);
                            System.out.println("createScenario returned: " + rc);

                            System.out.print("Simulation name (e.g. test-simulation): ");
                            String simName = scanner.nextLine().trim();
                            if (simName.isEmpty()) simName = "test-simulation";

                            String simId = simName + ":" + System.currentTimeMillis();

                            Instant now = Instant.now();
                            long startSec = now.plusSeconds(5).getEpochSecond();
                            long endSec = now.plusSeconds(25).getEpochSecond();
                            int nanos = now.getNano();

                            // Build Simulation proto
                            Simulation sim =
                                client.createSimulation(simName, startSec, nanos, endSec, nanos);

                            // Build CreateSimulationRequest
                            CreateSimulationRequest req =
                                CreateSimulationRequest.newBuilder()
                                    .setSimulationId(simId)
                                    .setSimulation(
                                        sim.toBuilder()
                                        .setScenario("scenarios/" + scenarioName)
                                        .build()
                                    )
                                    .build();

                            // ASYNC call (NON-BLOCKING)
                            System.out.println("[CLIENT] Sending async CreateSimulation request...");
                            client.createSimulationAsync(simName, req);

                            System.out.println("[CLIENT] Request sent. Client thread is NOT blocked.");

                            // Poll simulation state (demo purpose)
                            for (int i = 0; i < 10; i++) {
                                Thread.sleep(2000);

                                Simulation current =
                                    client.getSimulation(simName);

                                System.out.println(
                                    "[POLL] Simulation state = " + current.getState());

                                if (current.getState()
                                        == Simulation.State.SUCCEEDED) {
                                    System.out.println("[POLL] Simulation finished successfully.");
                                    break;
                                }
                            
                            }

                            System.out.println("=== ASYNC DEMO END ===");
                            break;
                        }

                        case "0":
                            running = false;
                            break;

                        default:
                            System.out.println("Invalid choice.");
                    }
                } catch (Exception ex) {
                    System.err.println("Error during operation: " + ex.getMessage());
                    ex.printStackTrace();
                }
            }
        } finally {
            try {
                client.shutdown();
            } finally {
                scanner.close();
            }
        }
        
        /*
        try {
            // Run the complete workflow
            client.runSimulationWorkflow();
        } 
        finally {
            client.shutdown();
        }
        */
    }
}