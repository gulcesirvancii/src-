package com.telesat.simulation;

import com.aalyria.spacetime.api.simulation.v1alpha.*;

/**
* Delegating class for Spacetime Scenario to keep all scenario related information
*/
public class ScenarioDelegation
{
    Scenario delegatedScenario;
        /* Scenario definition does not include 'scenarioId', so include in delegating class */
    String scenarioId;

    public ScenarioDelegation(String id, Scenario scenario) {
        this.scenarioId = id;
        this.delegatedScenario = scenario;
    }

    public Scenario getScenario() {
        return this.delegatedScenario;
    }

    public String getScenarioId() {
        return this.scenarioId;
    }
}

