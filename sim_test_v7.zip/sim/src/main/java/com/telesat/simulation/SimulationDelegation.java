package com.telesat.simulation;

import com.aalyria.spacetime.api.simulation.v1alpha.*;

 /* Delegating class for Spacetime Simulation */
public class SimulationDelegation
{
    Simulation delegatedSimulation;

    String simulationId;

    public SimulationDelegation(String id, Simulation simulation) {
        this.simulationId = id;
        this.delegatedSimulation = simulation;
    }

    public Simulation getSimulation() {
        return this.delegatedSimulation;
    }
        
    public String getSimulationId() {
        return this.simulationId;
    }
}