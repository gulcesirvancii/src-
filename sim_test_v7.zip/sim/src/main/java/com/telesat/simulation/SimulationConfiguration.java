package com.telesat.simulation;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.Duration;
import java.time.Instant;
import java.util.Properties;
import java.util.Set;
import java.util.Map.Entry;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.telesat.feasibility.ThroughputAvailabilityPair;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.ArrayList;
import java.util.LinkedHashMap;

public class SimulationConfiguration {
    
    public static final DateTimeFormatter SIMULATION_TIME_FORMATTER = DateTimeFormatter.RFC_1123_DATE_TIME;

    public static final String SIMULATION_START_TIME_PARM_NAME    = "sim.client.simulation.start.time";
    public static final String SIMULATION_END_TIME_PARM_NAME      = "sim.client.simulation.end.time";
    public static final String ANALYSIS_START_TIME_PARM_NAME      = "sim.client.analysis.start.time";
    public static final String ANALYSIS_END_TIME_PARM_NAME        = "sim.client.analysis.end.time";
    public static final String ANALYSIS_RESOLUTION_MS_PARM_NAME   = "sim.client.analysis.resolution.ms";

    String configFileName;

    List<Instant> simulationStartTimes = new ArrayList<>();
    List<Instant> simulationEndTimes = new ArrayList<>();

    List<Instant> analysisStartTimes = new ArrayList<>();
    List<Instant> analysisEndTimes = new ArrayList<>();

    /* TODO: Think about multiple resolution values per analysis period */
    Duration resolution;
    
    /* Use LinkedHashMap to preserve insertion order */
    LinkedHashMap<String, ScenarioConfig> scenarioConfig = new LinkedHashMap<>();
    LinkedHashMap<String, SimulationConfig> simulationConfig = new LinkedHashMap<>();
    LinkedHashMap<String, AnalysisConfig> analysisConfig = new LinkedHashMap<>();

    /* This implementation considers a Java properties file */
    public SimulationConfiguration(String confFileName) {
        this.configFileName = confFileName;
    }

    public class ScenarioConfig {
        String name;
        String description;

        public ScenarioConfig(JsonElement jelm) {
            JsonObject obj = jelm.getAsJsonObject();
            Set<Entry<String, JsonElement>> entries = obj.entrySet();
            for (Entry<String, JsonElement> entry : entries) {
                String key = entry.getKey();
                switch (key) {
                    case "name":
                        this.name = entry.getValue().getAsString();
                        break;
                    case "description":
                        this.description = entry.getValue().getAsString();
                        break;
                    default:
                        System.err.println("Unhandled parameters for scenario: " + key);
                }
            }
        }

        public String getName() {
            return this.name;
        }

        public String getDescription() {
            return this.description;
        }

        @Override
        public String toString() {
            return "[name=" + this.name + ", description=" + this.description + "]";
        }
    }

    public class SimulationConfig {
        String  name;
        String  scenario;
        String  startTime;
        Instant startTimeInstant;
        String  endTime;
        Instant endTimeInstant;

        long slaCIR;

        ArrayList<ThroughputAvailabilityPair> taPairs = new ArrayList<>();

        public SimulationConfig(JsonElement jelm) {
            JsonObject obj = jelm.getAsJsonObject();
            Set<Entry<String, JsonElement>> entries = obj.entrySet();
            for (Entry<String, JsonElement> entry : entries) {
                String key = entry.getKey();
                switch (key) {
                    case "name":
                        this.name = entry.getValue().getAsString();
                        break;
                    case "scenario":
                        this.scenario = entry.getValue().getAsString();
                        break;
                    case "start-time":
                    {
                        this.startTime = entry.getValue().getAsString();
                        LocalDateTime localDateTime = LocalDateTime.parse(this.startTime, SIMULATION_TIME_FORMATTER);
                        this.startTimeInstant = localDateTime.toInstant(ZoneOffset.UTC);
                    }
                        break;
                    case "end-time":
                    {
                        this.endTime = entry.getValue().getAsString();
                        LocalDateTime localDateTime = LocalDateTime.parse(this.endTime, SIMULATION_TIME_FORMATTER);
                        this.endTimeInstant = localDateTime.toInstant(ZoneOffset.UTC);
                    }
                        break;
                    case "sla-cir-bps":
                        this.slaCIR = entry.getValue().getAsLong();
                        break;
                    case "ta-pairs":
                    {
                        JsonArray tapairs = entry.getValue().getAsJsonArray();
                        for (int i = 0; i < tapairs.size(); i++) {
                            JsonArray pair = tapairs.get(i).getAsJsonArray();
                            ThroughputAvailabilityPair tapair = new ThroughputAvailabilityPair(pair.get(0).getAsDouble(), pair.get(1).getAsDouble());
                            this.taPairs.add(tapair);
                        }
                    }
                        break;
                    default:
                        System.err.println("Unhandled parameters for simulation: " + key);
                }
            }
        }

        public String getName() {
            return this.name;
        }

        public String getScenario() {
            return this.scenario;
        }

        public String getStartTime() {
            return this.startTime;
        }

        public Instant getStartTimeAsInstant() {
            return this.startTimeInstant;
        }

        public String getEndTime() {
            return this.endTime;
        }

        public Instant getEndTimeAsInstant() {
            return this.endTimeInstant;
        }

        public long getSlaCir() {
            return this.slaCIR;
        }

        public ThroughputAvailabilityPair[] getThroughputAvailabilityPairs() {
            return this.taPairs.toArray(new ThroughputAvailabilityPair[0]);
        }

        @Override
        public String toString() {
            return "[name=" + this.name + ", start-time=" + this.startTime + ", end-time=" + this.endTime + ", SLA-CIR=" + 
                   this.slaCIR + ", throughput-availability pairs: " + this.taPairs + "]";
        }
    }

    public class AnalysisConfig {
        String  name;
        String  simulation;
        String  startTime;
        Instant startTimeInstant;
        String  endTime;
        Instant endTimeInstant;

        long     resolution;
        Duration resolutionDur;

        long slaCIR;

        ArrayList<ThroughputAvailabilityPair> taPairs = new ArrayList<>();

        public AnalysisConfig(JsonElement jelm) {
            JsonObject obj = jelm.getAsJsonObject();
            Set<Entry<String, JsonElement>> entries = obj.entrySet();
            for (Entry<String, JsonElement> entry : entries) {
                String key = entry.getKey();
                switch (key) {
                    case "name":
                        this.name = entry.getValue().getAsString();
                        break;
                    case "simulation":
                        this.simulation = entry.getValue().getAsString();
                        break;
                    case "start-time":
                    {
                        this.startTime = entry.getValue().getAsString();
                        LocalDateTime localDateTime = LocalDateTime.parse(this.startTime, SIMULATION_TIME_FORMATTER);
                        this.startTimeInstant = localDateTime.toInstant(ZoneOffset.UTC);
                    }
                        break;
                    case "end-time":
                    {
                        this.endTime = entry.getValue().getAsString();
                        LocalDateTime localDateTime = LocalDateTime.parse(this.endTime, SIMULATION_TIME_FORMATTER);
                        this.endTimeInstant = localDateTime.toInstant(ZoneOffset.UTC);
                    }
                        break;
                    case "resolution-ms":
                        this.resolution = entry.getValue().getAsLong();
                        this.resolutionDur = Duration.ofMillis(this.resolution);
                        break;
                    case "sla-cir-bps":
                        this.slaCIR = entry.getValue().getAsLong();
                        break;
                    case "ta-pairs":
                    {
                        JsonArray tapairs = entry.getValue().getAsJsonArray();
                        for (int i = 0; i < tapairs.size(); i++) {
                            JsonArray pair = tapairs.get(i).getAsJsonArray();
                            ThroughputAvailabilityPair tapair = new ThroughputAvailabilityPair(pair.get(0).getAsDouble(), pair.get(1).getAsDouble());
                            this.taPairs.add(tapair);
                        }
                    }
                        break;
                    default:
                        System.err.println("Unhandled parameters for analysis: " + key);
                }
            }
        }

        public String getName() {
            return this.name;
        }

        public String getSimulation() {
            return this.simulation;
        }

        public String getStartTime() {
            return this.startTime;
        }

        public Instant getStartTimeAsInstant() {
            return this.startTimeInstant;
        }

        public String getEndTime() {
            return this.endTime;
        }

        public Instant getEndTimeAsInstant() {
            return this.endTimeInstant;
        }

        public long getResolution() {
            return this.resolution;
        }

        public Duration getResolutionAsDuration() {
            return this.resolutionDur;
        }

        public long getSlaCir() {
            return this.slaCIR;
        }
        
        public ThroughputAvailabilityPair[] getThroughputAvailabilityPairs() {
            return this.taPairs.toArray(new ThroughputAvailabilityPair[0]);
        }

        @Override
        public String toString() {
            return "[name=" + this.name + ", start-time=" + this.startTime + ", end-time=" + this.endTime + 
                   ", resolution-ms=" + this.resolution + ", SLA-CIR=" + this.slaCIR + 
                   ", throughput-availability pairs: " + this.taPairs + "]";
        }
    }

    public void parseAsProperties() {
        Properties prop = new Properties();

        try (InputStream fis = new FileInputStream(this.configFileName)) {
            prop.load(fis);
            
            // Read properties
            String simStartTime = prop.getProperty(SIMULATION_START_TIME_PARM_NAME);
            String simEndTime = prop.getProperty(SIMULATION_END_TIME_PARM_NAME);

            System.out.println("Simulation Start Time: " + simStartTime);
            System.out.println("Simulation End Time  : " + simEndTime);


            // Parse start-time string to a LocalDateTime
            LocalDateTime localDateTime = LocalDateTime.parse(simStartTime, SIMULATION_TIME_FORMATTER);
            // 2. Convert to an Instant using a specific time zone (e.g., UTC)
            Instant stInstant = localDateTime.toInstant(ZoneOffset.UTC);
            this.simulationStartTimes.add(stInstant);

            // end-time 
            localDateTime = LocalDateTime.parse(simEndTime, SIMULATION_TIME_FORMATTER);
            Instant endInstant = localDateTime.toInstant(ZoneOffset.UTC);
            this.simulationEndTimes.add(endInstant);

            System.out.println("Simulation start-time in ms: " + stInstant.toEpochMilli());
            System.out.println("Simulation end-time in ms: " + endInstant.toEpochMilli());
            
            // Analysis interval
            String anlStartTime = prop.getProperty(ANALYSIS_START_TIME_PARM_NAME);
            String anlEndTime = prop.getProperty(ANALYSIS_END_TIME_PARM_NAME);

            localDateTime = LocalDateTime.parse(anlStartTime, SIMULATION_TIME_FORMATTER);
            Instant anStInstant = localDateTime.toInstant(ZoneOffset.UTC);
            this.analysisStartTimes.add(anStInstant);

            localDateTime = LocalDateTime.parse(anlEndTime, SIMULATION_TIME_FORMATTER);
            Instant anEndInstant = localDateTime.toInstant(ZoneOffset.UTC);
            this.analysisEndTimes.add(anEndInstant);

            System.out.println("Analysis start-time: " + anStInstant.toEpochMilli());
            System.out.println("Analysis end-time: " + anEndInstant.toEpochMilli());

            // Analysis Resolution
            String anlResolution = prop.getProperty(ANALYSIS_RESOLUTION_MS_PARM_NAME);
            this.resolution = Duration.ofMillis(Long.valueOf(anlResolution));

            System.out.println("Analysis resolution: " + this.resolution.toMillis());

        } 
        catch (FileNotFoundException ex) {
            System.err.println("Configuration file '" + this.configFileName + "' not found.");
            ex.printStackTrace();
        } 
        catch (IOException ex) {
            System.err.println("Error reading configuration file.");
            ex.printStackTrace();
        }
        catch (DateTimeParseException ex) {
            System.err.println("Date parse exception occurred.");
            ex.printStackTrace();
        }
    }

    void parseForJson() {
        Path path = Paths.get(this.configFileName);

        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {

            JsonElement tree = JsonParser.parseReader(reader);

            JsonObject obj = tree.getAsJsonObject();
            System.out.println(obj);
            Set<String> keys = obj.keySet();
            for (String key : keys) {
                System.out.println(key);
                JsonElement element = obj.get(key);
                if (element.isJsonArray()) {
                    JsonArray earray = element.getAsJsonArray();
                    for (JsonElement aelm : earray) {
                        switch (key) {
                            case "scenarios":
                                System.out.println("Scenario element: " + aelm);
                                ScenarioConfig scconf = new ScenarioConfig(aelm);
                                this.scenarioConfig.put(scconf.getName(), scconf);
                                break;

                            case "simulations":
                                System.out.println("Simulation element: " + aelm);
                                SimulationConfig simconf = new SimulationConfig(aelm);
                                this.simulationConfig.put(simconf.getName(), simconf);
                                break;

                            case "analyses":
                                System.out.println("Analyses element: " + aelm);
                                AnalysisConfig anconf = new AnalysisConfig(aelm);
                                this.analysisConfig.put(anconf.getName(), anconf);
                                break;

                            default:
                                System.err.println("Unhandled key: " + key);
                        }
                    }
                }
                // else no-array element
            }
        }
        catch (FileNotFoundException ex) {
            System.err.println("parseFOrJson: Configuration file '" + this.configFileName + "' not found.");
            ex.printStackTrace();
        }
        catch (IOException ex) {
            System.err.println("parseFOrJson: Error reading configuration file.");
            ex.printStackTrace();
        }

        for (ScenarioConfig scconf : this.scenarioConfig.values()) {
            System.out.println(scconf);
        }
        for (SimulationConfig simconf : this.simulationConfig.values()) {
            System.out.println(simconf);
        }
        for (AnalysisConfig anconf : this.analysisConfig.values()) {
            System.out.println(anconf);
        }
    }

    /* Returns 'null' if 'index' is not valid */
    public Instant getSimulationStartTime(int index) {
        return this.simulationStartTimes.get(index);
    }
    /* Returns 'null' if 'index' is not valid */
    public Instant getSimulationEndTime(int index) {
        return this.simulationEndTimes.get(index);
    }

    /* Returns 'null' if 'index' is not valid */
    public Instant getAnalysisStartTime(int index) {
        return this.analysisStartTimes.get(index);
    }
    /* Returns 'null' if 'index' is not valid */
    public Instant getAnalysisEndTime(int index) {
        return this.analysisEndTimes.get(index);
    }

    public Duration getResolution() {
        return this.resolution;
    }

    public Instant getSimulationStartTimeAsInstant(String simName) throws NoSuchElementException {
        SimulationConfig simconf = this.simulationConfig.get(simName);
        if (simconf == null) {
            throw new NoSuchElementException();
        }
        return simconf.getStartTimeAsInstant();
    }

    public Instant getSimulationEndTimeAsInstant(String simName) throws NoSuchElementException {
        SimulationConfig simconf = this.simulationConfig.get(simName);
        if (simconf == null) {
            throw new NoSuchElementException();
        }
        return simconf.getEndTimeAsInstant();
    }

    public long getSimulationSlaCir(String simName) {
        SimulationConfig simconf = this.simulationConfig.get(simName);
        if (simconf == null) {
            return 0;
        }
        return simconf.getSlaCir();
    }

    public ThroughputAvailabilityPair[] getSimulationTAPairs(String simName) {
        SimulationConfig simconf = this.simulationConfig.get(simName);
        if (simconf == null) {
            return new ThroughputAvailabilityPair[0];
        }
        return simconf.getThroughputAvailabilityPairs();
    }

    public Instant getAnalysisStartTimeAsInstant(String anlName) throws NoSuchElementException {
        AnalysisConfig anconf = this.analysisConfig.get(anlName);
        if (anconf == null) {
            System.out.println("getAnalysisStartTimeAsInstant: No analysis with name: " + anlName);
            throw new NoSuchElementException();
        }
        return anconf.getStartTimeAsInstant();
    }

    public Instant getAnalysisEndTimeAsInstant(String anlName) throws NoSuchElementException {
        AnalysisConfig anconf = this.analysisConfig.get(anlName);
        if (anconf == null) {
            System.out.println("getAnalysisEndTimeAsInstant: No analysis with name: " + anlName);
            throw new NoSuchElementException();
        }
        return anconf.getEndTimeAsInstant();
    }

    public Duration getAnalysisResolutionAsDuration(String anlName) throws NoSuchElementException {
        AnalysisConfig anconf = this.analysisConfig.get(anlName);
        if (anconf == null) {
            System.out.println("getAnalysisResolutionAsDuration: No analysis with name: " + anlName);
            throw new NoSuchElementException();
        }
        return anconf.getResolutionAsDuration();
    }

    public long getAnalysisSlaCir(String anlName) {
        AnalysisConfig anconf = this.analysisConfig.get(anlName);
        if (anconf == null) {
            System.out.println("getAnalysisSlaCir: No analysis with name: " + anlName);
            return 0;
        }
        return anconf.getSlaCir();        
    }

    public ThroughputAvailabilityPair[] getAnalysisTAPairs(String anlName) {
        AnalysisConfig anconf = this.analysisConfig.get(anlName);
        if (anconf == null) {
            System.out.println("ThroughputAvailabilityPair: No analysis with name: " + anlName);
            return new ThroughputAvailabilityPair[0];
        }
        return anconf.getThroughputAvailabilityPairs();
    }
}
