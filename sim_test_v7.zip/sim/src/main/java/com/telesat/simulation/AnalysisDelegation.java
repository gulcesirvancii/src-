package com.telesat.simulation;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

import org.slf4j.Logger;

import com.aalyria.spacetime.api.simulation.v1alpha.*;


public class AnalysisDelegation 
{
    Analysis delegatedAnalysis;

    /* The following comes with Create-Analysis request and indicates the simulation 
       in which this analysis will be created. Its format: simulations/{simulation} such that
       the following 'parent' consists of only simulation-name part */
    String parentSimulation;

    String analysisId;

    ArrayList<AnalysisSegmentDelegation> analysisSegments;

    Logger logger;

    /* Hardcoded ranges for CIR, EIR, Frame Delay and IFDV. All can be defined from simulation provisioning 
       or configuration files. We consider them as hardcoded at the moment. 
     */
    static final long CIR_MIN_VALUE_BPS = 27000;
    static final long CIR_MAX_VALUE_BPS = 29000;
    static final long EIR_MIN_VALUE_BPS = 30000;
    static final long EIR_MAX_VALUE_BPS = 32000;

    static final long FRAME_DELAY_MIN_VALUE_MS = 200; // in ms (or micro-seconds (?))
    static final long FRAME_DELAY_MAX_VALUE_MS = 400; // in ms

    static final long IFDV_MIN_VALUE_MS = 200; // in ms (or micro-seconds (?))
    static final long IFDV_MAX_VALUE_MS = 300;

    static final int DEFAULT_PATH_COUNT = 2;

    static final long SAMPLING_PERIOD_MS = 100; // in ms

    public AnalysisDelegation(String parent, String id, Analysis analysis, 
                              SimulationServerConfiguration conf, Logger logger) {
        this.analysisId = id;
        //this.delegatedAnalysis = analysis;
        this.analysisSegments = new ArrayList<>();
        this.logger = logger;

        String fsimname = parent;
        String[] parts = fsimname.split("/");
        if (parts.length > 2) {
            logger.info("AnalysisDelegation: Name format of simulation is possibly unexpected: '{}'", fsimname);
        }
        this.parentSimulation = parts[parts.length - 1];
        /* Analysis name */
        parts = analysis.getName().split("/");
        if (parts.length > 2) {
            logger.info("AnalysisDelegation: Name format of Analysis is possibly unexpected: '{}'", analysis.getName());
        }
        String analysisName = parts[parts.length - 1];

        logger.info("AnalysisDelegation: Delegating to Analysis with name: '{}' of parent simulation: '{}'",
                    analysisName, this.parentSimulation);
        
        /* Create a copy of Analysis to own */
        Analysis.Builder anBuilder = Analysis.newBuilder(analysis);

        /* Analysis range */
        Instant now = Instant.now();
        Instant startIns = Instant.ofEpochSecond(anBuilder.getInterval().getStartTime().getSeconds(), 
                                                 anBuilder.getInterval().getStartTime().getNanos());
        Instant endIns = Instant.ofEpochSecond(anBuilder.getInterval().getEndTime().getSeconds(), 
                                               anBuilder.getInterval().getEndTime().getNanos());
        long durationInSec = startIns.until(endIns, ChronoUnit.SECONDS);
        long durationInMs = startIns.until(endIns, ChronoUnit.MILLIS);
            
        long startInMs = startIns.toEpochMilli();
        long endInMs = endIns.toEpochMilli();

        Instant resolutionIns = Instant.ofEpochSecond(anBuilder.getResolution().getSeconds(), 
                                                      anBuilder.getResolution().getNanos());
        /*  */                                              
        long resInMs = resolutionIns.toEpochMilli();
        Duration resolution = Duration.ofSeconds(anBuilder.getResolution().getSeconds(), 
                                                 anBuilder.getResolution().getNanos());
        long resultionInMs = resolution.toMillis();
        logger.info("Instant now: '{}', start: '{}', end: '{}', duration in secs: '{}', duration in ms: '{}', resolution in ms: '{}', segment count: '{}'"
                    + " resoultion with duration: '{}', resoultion-in-ms: '{}', segments: '{}', start-in-ms: '{}', end-in-ms: '{}'", 
                    now, startIns, endIns, durationInSec, durationInMs, resInMs, (durationInMs / resInMs), resolution, resultionInMs,
                    (durationInMs / resultionInMs), startInMs, endInMs);
        long asegmentCount = (durationInMs / resultionInMs);
        /* Create segments */
        for (int i = 0; i < asegmentCount; i++) {
            long asegmentStartInMs = startInMs + (resultionInMs * i);
            long asegmentEndInMs = asegmentStartInMs + resultionInMs;

            Duration asegmentStartDur = Duration.ofMillis(asegmentStartInMs);
            Duration asegmentEndDur = Duration.ofMillis(asegmentEndInMs);

            com.google.protobuf.Timestamp istt = com.google.protobuf.Timestamp.newBuilder().setSeconds(asegmentStartDur.getSeconds())
                                                                                           .setNanos(asegmentStartDur.getNano()).build();
            com.google.protobuf.Timestamp iett = com.google.protobuf.Timestamp.newBuilder().setSeconds(asegmentEndDur.getSeconds())
                                                                                           .setNanos(asegmentEndDur.getNano()).build();
            com.google.type.Interval anInterval = com.google.type.Interval.newBuilder().setStartTime(istt).setEndTime(iett).build();

            //int sampleCount = (int)(resultionInMs / SAMPLING_PERIOD_MS);
            int sampleCount = (int)(resultionInMs / conf.getAnalysisSamplingPeriodMs(analysisName));
            //AnalysisSegmentDelegation asegment = new AnalysisSegmentDelegation(anInterval, DEFAULT_PATH_COUNT, CIR_MIN_VALUE_BPS, CIR_MAX_VALUE_BPS, 
            //                                                                   EIR_MIN_VALUE_BPS, EIR_MAX_VALUE_BPS, FRAME_DELAY_MIN_VALUE_MS, 
            //                                                                   FRAME_DELAY_MAX_VALUE_MS, IFDV_MIN_VALUE_MS, IFDV_MAX_VALUE_MS, 
            //                                                                   sampleCount, this.logger);
            AnalysisSegmentDelegation asegment = new AnalysisSegmentDelegation(anInterval, conf.getAnalysisPathCount(analysisName), 
                                                                               conf.getAnalysisCirMinBps(analysisName), conf.getAnalysisCirMaxBps(analysisName), 
                                                                               conf.getAnalysisEirMinBps(analysisName), conf.getAnalysisEirMaxBps(analysisName),  
                                                                               conf.getAnalysisFrameDelayMinUs(analysisName), conf.getAnalysisFrameDelayMaxUs(analysisName),
                                                                               conf.getAnalysisIfdvMinUs(analysisName), conf.getAnalysisIfdvMaxUs(analysisName),
                                                                               sampleCount, this.logger);
            this.analysisSegments.add(asegment);
            anBuilder.addSegments(asegment.getAnalysisSegment());
        }
        this.delegatedAnalysis = anBuilder.build();
    }

    public Analysis getAnalysis() {
        return this.delegatedAnalysis;
    }

    public String getParentSimulation() {
        return this.parentSimulation;
    }

    public String getAnalysisId() {
        return this.analysisId;
    }

}
