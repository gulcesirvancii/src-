package com.telesat.feasibility;

import java.util.Arrays;

public class Percentile {

    /*
     * Performs the second approach given at NIST Engineering Statistics Handbook -
     * Section 7.2.6.2
     * (https://www.itl.nist.gov/div898/handbook/prc/section2/prc262.htm)
     * 
     * To estimate (p)th percentile of a series of measurements Y1,..., YN, and
     * ordered version in increasing order, Y[1],..., Y[N], such that at most p% of
     * the measurements are less than this value and at most (100 - p) % are
     * greater, it is considered that 1 + (p/100)*(N-1) = k + d, where k an integer,
     * and d, a fraction greater than or equal to 0 and less than 1. Then
     * 
     * For 0 < k < N : Y(p) = Y[k] + d * (Y[k+1] - Y[k]) 
     * For k = 0 : Y(p) = Y[1] 
     * For k >= N : Y(p) = Y[N]
     * 
     * values   - consists of data values to evaluate for percentile 
     * begin    - index of 'values' as the start point 
     * length   - length of 'values' as the end point 
     * isSorted - boolean indicates if provided 'values' are already sorted
     * p        - represent (100p)th percentile. 
     *            For example 90th percentile p = 90/100 = 0.9
     * 
     * It returns evaluated value for (100p)th percentile
     */
    public double evaluate(final double[] values, final int begin, final int length, boolean isSorted, final double p) {

        /*
         * TODO: Add pre-test for provided parameters, such that 'values' shall be in
         * (0, 100], etc.) and return an appropriate value or throw an exception
         */

        if (length == 0) {
            return Double.NaN;
        }
        if (length == 1) {
            return values[begin];
        }
        double n = length;
        double pos = 1 + (p * (n - 1)) / 100;
        int k = (int) Math.floor(pos);
        double d = pos - k;

        double[] sorted = null;
        if (!isSorted) {
            sorted = new double[length];
            System.arraycopy(values, begin, sorted, 0, length);
            Arrays.sort(sorted);
        }
        else {
            sorted = values;
        }
        /* 
        double[] sorted = new double[length];
        System.arraycopy(values, begin, sorted, 0, length);
        Arrays.sort(sorted);
        */
        if (pos < 1) {
            return sorted[0];
        }
        if (pos >= n) {
            return sorted[(length - 1)];
        }

        double yk = sorted[(k - 1)];
        double yk_upper = sorted[k];

        return yk + (d * (yk_upper - yk));
    }

    /*
     * Performs the first approach given at NIST Engineering Statistics Handbook -
     * Section 7.2.6.2
     * (https://www.itl.nist.gov/div898/handbook/prc/section2/prc262.htm)
     * 
     * To estimate (p)th percentile of a series of measurements Y1,..., YN, and
     * ordered version in increasing order, Y[1],..., Y[N], such that at most p% of
     * the measurements are less than this value and at most (100 - p) % are
     * greater, it is considered that (p/100) * (N + 1) = k + d, where k an integer,
     * and d, a fraction greater than or equal to 0 and less than 1. Then
     * 
     * For 0 < k < N : Y(p) = Y[k] + d * (Y[k+1] - Y[k]) 
     * For k = 0 : Y(p) = Y[1] 
     * For k >= N : Y(p) = Y[N]
     * 
     * values - consists of data values to evaluate for percentile 
     * begin  - index of 'values' as the start point 
     * length - length of 'values' as the end point 
     * p - represent (100p)th percentile. 
     *     For example 90th percentile p = 90/100 = 0.9
     * 
     * It returns evaluated value for (100p)th percentile
     */
    public double evaluate2(final double[] values, final int begin, final int length, final double p) {

        /*
         * TODO: Add pre-test for provided parameters, such that 'values' shall be in
         * (0, 100], etc.) and return an appropriate value or throw an exception
         */

        if (length == 0) {
            return Double.NaN;
        }
        if (length == 1) {
            return values[begin];
        }
        double n = length;
        double pos = (p * (n + 1)) / 100;
        int k = (int) Math.floor(pos);
        double d = pos - k;
        double[] sorted = new double[length];
        System.arraycopy(values, begin, sorted, 0, length);
        Arrays.sort(sorted);
        if (pos < 1) {
            return sorted[0];
        }
        if (pos >= n) {
            return sorted[(length - 1)];
        }

        double yk = sorted[(k - 1)];
        double yk_upper = sorted[k];

        return yk + (d * (yk_upper - yk));
    }
}
