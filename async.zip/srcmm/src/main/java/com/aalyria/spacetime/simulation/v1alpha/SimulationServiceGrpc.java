package com.aalyria.spacetime.simulation.v1alpha;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * Simulation API.
 * The resources managed by this API are:
 * * Scenarios, which define a system to be simulated.
 *   * Network model entities, which represent entities in a network.
 *   * Network model relationships, which represent relationships between
 *     entities in a network.
 *   * P2pSrTePolicies, which represent point-to-point SR-TE policies in the
 *     network.
 *     * P2pSrTePolicyCandidatePaths, which represent requests to establish
 *       candidate paths in service of SR-TE policies.
 *   * Downtimes, which represent downtimes of entities in the scenario.
 *   * ProtectionAssociationGroups, which indicate which paths through the
 *     network are to serve as protection to others.
 *   * DisjointAssociationGroups, which indicate which paths are to traverse
 *     disjoint paths through the network.
 * * Simulations, which represent simulations of a scenario over a time
 *   interval.
 *   * Analyses, statistical analyses of a simulation's results.
 * A simulation may be set-up, run, and analyzed via the following process:
 * 1. Create a scenario, giving the scenario a name and description.
 * 2. Define the scenario by creating the scenario's network model entities and
 *    relationships, point-to-point SR-TE policies and candidate paths,
 *    downtimes, protection association groups, and disjoint association groups.
 * 3. Create a simulation, referencing the scenario by name and specifying a
 *    time interval to be simulated. Spacetime will populate the simulation with
 *    the results of the simulation.
 * 4. Create an analysis, specifying analysis interval and granularity.
 *    Spacetime will populate the analysis with the results of the statistical
 *    analysis of the simulation results.
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.65.1)",
    comments = "Source: simulation.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class SimulationServiceGrpc {

  private SimulationServiceGrpc() {}

  public static final java.lang.String SERVICE_NAME = "aalyria.spacetime.api.simulation.v1alpha.SimulationService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetScenarioRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> getGetScenarioMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetScenario",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetScenarioRequest.class,
      responseType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetScenarioRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> getGetScenarioMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetScenarioRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> getGetScenarioMethod;
    if ((getGetScenarioMethod = SimulationServiceGrpc.getGetScenarioMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getGetScenarioMethod = SimulationServiceGrpc.getGetScenarioMethod) == null) {
          SimulationServiceGrpc.getGetScenarioMethod = getGetScenarioMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetScenarioRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetScenario"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetScenarioRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("GetScenario"))
              .build();
        }
      }
    }
    return getGetScenarioMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosResponse> getListScenariosMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListScenarios",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosRequest.class,
      responseType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosResponse> getListScenariosMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosResponse> getListScenariosMethod;
    if ((getListScenariosMethod = SimulationServiceGrpc.getListScenariosMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getListScenariosMethod = SimulationServiceGrpc.getListScenariosMethod) == null) {
          SimulationServiceGrpc.getListScenariosMethod = getListScenariosMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListScenarios"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosResponse.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("ListScenarios"))
              .build();
        }
      }
    }
    return getListScenariosMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateScenarioRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> getCreateScenarioMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateScenario",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateScenarioRequest.class,
      responseType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateScenarioRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> getCreateScenarioMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateScenarioRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> getCreateScenarioMethod;
    if ((getCreateScenarioMethod = SimulationServiceGrpc.getCreateScenarioMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getCreateScenarioMethod = SimulationServiceGrpc.getCreateScenarioMethod) == null) {
          SimulationServiceGrpc.getCreateScenarioMethod = getCreateScenarioMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateScenarioRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateScenario"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateScenarioRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("CreateScenario"))
              .build();
        }
      }
    }
    return getCreateScenarioMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateScenarioRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> getUpdateScenarioMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateScenario",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateScenarioRequest.class,
      responseType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateScenarioRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> getUpdateScenarioMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateScenarioRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> getUpdateScenarioMethod;
    if ((getUpdateScenarioMethod = SimulationServiceGrpc.getUpdateScenarioMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getUpdateScenarioMethod = SimulationServiceGrpc.getUpdateScenarioMethod) == null) {
          SimulationServiceGrpc.getUpdateScenarioMethod = getUpdateScenarioMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateScenarioRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateScenario"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateScenarioRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("UpdateScenario"))
              .build();
        }
      }
    }
    return getUpdateScenarioMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteScenarioRequest,
      com.google.protobuf.Empty> getDeleteScenarioMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteScenario",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteScenarioRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteScenarioRequest,
      com.google.protobuf.Empty> getDeleteScenarioMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteScenarioRequest, com.google.protobuf.Empty> getDeleteScenarioMethod;
    if ((getDeleteScenarioMethod = SimulationServiceGrpc.getDeleteScenarioMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getDeleteScenarioMethod = SimulationServiceGrpc.getDeleteScenarioMethod) == null) {
          SimulationServiceGrpc.getDeleteScenarioMethod = getDeleteScenarioMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteScenarioRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeleteScenario"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteScenarioRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("DeleteScenario"))
              .build();
        }
      }
    }
    return getDeleteScenarioMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CopyScenarioRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> getCopyScenarioMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CopyScenario",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CopyScenarioRequest.class,
      responseType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CopyScenarioRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> getCopyScenarioMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CopyScenarioRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> getCopyScenarioMethod;
    if ((getCopyScenarioMethod = SimulationServiceGrpc.getCopyScenarioMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getCopyScenarioMethod = SimulationServiceGrpc.getCopyScenarioMethod) == null) {
          SimulationServiceGrpc.getCopyScenarioMethod = getCopyScenarioMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CopyScenarioRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CopyScenario"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CopyScenarioRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("CopyScenario"))
              .build();
        }
      }
    }
    return getCopyScenarioMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelEntityRequest,
      org.outernetcouncil.nmts.v1.proto.Nmts.Entity> getGetNetworkModelEntityMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetNetworkModelEntity",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelEntityRequest.class,
      responseType = org.outernetcouncil.nmts.v1.proto.Nmts.Entity.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelEntityRequest,
      org.outernetcouncil.nmts.v1.proto.Nmts.Entity> getGetNetworkModelEntityMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelEntityRequest, org.outernetcouncil.nmts.v1.proto.Nmts.Entity> getGetNetworkModelEntityMethod;
    if ((getGetNetworkModelEntityMethod = SimulationServiceGrpc.getGetNetworkModelEntityMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getGetNetworkModelEntityMethod = SimulationServiceGrpc.getGetNetworkModelEntityMethod) == null) {
          SimulationServiceGrpc.getGetNetworkModelEntityMethod = getGetNetworkModelEntityMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelEntityRequest, org.outernetcouncil.nmts.v1.proto.Nmts.Entity>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetNetworkModelEntity"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelEntityRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  org.outernetcouncil.nmts.v1.proto.Nmts.Entity.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("GetNetworkModelEntity"))
              .build();
        }
      }
    }
    return getGetNetworkModelEntityMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesResponse> getListNetworkModelEntitiesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListNetworkModelEntities",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesRequest.class,
      responseType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesResponse> getListNetworkModelEntitiesMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesResponse> getListNetworkModelEntitiesMethod;
    if ((getListNetworkModelEntitiesMethod = SimulationServiceGrpc.getListNetworkModelEntitiesMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getListNetworkModelEntitiesMethod = SimulationServiceGrpc.getListNetworkModelEntitiesMethod) == null) {
          SimulationServiceGrpc.getListNetworkModelEntitiesMethod = getListNetworkModelEntitiesMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListNetworkModelEntities"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesResponse.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("ListNetworkModelEntities"))
              .build();
        }
      }
    }
    return getListNetworkModelEntitiesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelEntityRequest,
      org.outernetcouncil.nmts.v1.proto.Nmts.Entity> getCreateNetworkModelEntityMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateNetworkModelEntity",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelEntityRequest.class,
      responseType = org.outernetcouncil.nmts.v1.proto.Nmts.Entity.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelEntityRequest,
      org.outernetcouncil.nmts.v1.proto.Nmts.Entity> getCreateNetworkModelEntityMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelEntityRequest, org.outernetcouncil.nmts.v1.proto.Nmts.Entity> getCreateNetworkModelEntityMethod;
    if ((getCreateNetworkModelEntityMethod = SimulationServiceGrpc.getCreateNetworkModelEntityMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getCreateNetworkModelEntityMethod = SimulationServiceGrpc.getCreateNetworkModelEntityMethod) == null) {
          SimulationServiceGrpc.getCreateNetworkModelEntityMethod = getCreateNetworkModelEntityMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelEntityRequest, org.outernetcouncil.nmts.v1.proto.Nmts.Entity>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateNetworkModelEntity"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelEntityRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  org.outernetcouncil.nmts.v1.proto.Nmts.Entity.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("CreateNetworkModelEntity"))
              .build();
        }
      }
    }
    return getCreateNetworkModelEntityMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateNetworkModelEntityRequest,
      org.outernetcouncil.nmts.v1.proto.Nmts.Entity> getUpdateNetworkModelEntityMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateNetworkModelEntity",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateNetworkModelEntityRequest.class,
      responseType = org.outernetcouncil.nmts.v1.proto.Nmts.Entity.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateNetworkModelEntityRequest,
      org.outernetcouncil.nmts.v1.proto.Nmts.Entity> getUpdateNetworkModelEntityMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateNetworkModelEntityRequest, org.outernetcouncil.nmts.v1.proto.Nmts.Entity> getUpdateNetworkModelEntityMethod;
    if ((getUpdateNetworkModelEntityMethod = SimulationServiceGrpc.getUpdateNetworkModelEntityMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getUpdateNetworkModelEntityMethod = SimulationServiceGrpc.getUpdateNetworkModelEntityMethod) == null) {
          SimulationServiceGrpc.getUpdateNetworkModelEntityMethod = getUpdateNetworkModelEntityMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateNetworkModelEntityRequest, org.outernetcouncil.nmts.v1.proto.Nmts.Entity>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateNetworkModelEntity"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateNetworkModelEntityRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  org.outernetcouncil.nmts.v1.proto.Nmts.Entity.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("UpdateNetworkModelEntity"))
              .build();
        }
      }
    }
    return getUpdateNetworkModelEntityMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelEntityRequest,
      com.google.protobuf.Empty> getDeleteNetworkModelEntityMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteNetworkModelEntity",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelEntityRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelEntityRequest,
      com.google.protobuf.Empty> getDeleteNetworkModelEntityMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelEntityRequest, com.google.protobuf.Empty> getDeleteNetworkModelEntityMethod;
    if ((getDeleteNetworkModelEntityMethod = SimulationServiceGrpc.getDeleteNetworkModelEntityMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getDeleteNetworkModelEntityMethod = SimulationServiceGrpc.getDeleteNetworkModelEntityMethod) == null) {
          SimulationServiceGrpc.getDeleteNetworkModelEntityMethod = getDeleteNetworkModelEntityMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelEntityRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeleteNetworkModelEntity"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelEntityRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("DeleteNetworkModelEntity"))
              .build();
        }
      }
    }
    return getDeleteNetworkModelEntityMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelRelationshipRequest,
      org.outernetcouncil.nmts.v1.proto.Nmts.Relationship> getGetNetworkModelRelationshipMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetNetworkModelRelationship",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelRelationshipRequest.class,
      responseType = org.outernetcouncil.nmts.v1.proto.Nmts.Relationship.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelRelationshipRequest,
      org.outernetcouncil.nmts.v1.proto.Nmts.Relationship> getGetNetworkModelRelationshipMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelRelationshipRequest, org.outernetcouncil.nmts.v1.proto.Nmts.Relationship> getGetNetworkModelRelationshipMethod;
    if ((getGetNetworkModelRelationshipMethod = SimulationServiceGrpc.getGetNetworkModelRelationshipMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getGetNetworkModelRelationshipMethod = SimulationServiceGrpc.getGetNetworkModelRelationshipMethod) == null) {
          SimulationServiceGrpc.getGetNetworkModelRelationshipMethod = getGetNetworkModelRelationshipMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelRelationshipRequest, org.outernetcouncil.nmts.v1.proto.Nmts.Relationship>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetNetworkModelRelationship"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelRelationshipRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  org.outernetcouncil.nmts.v1.proto.Nmts.Relationship.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("GetNetworkModelRelationship"))
              .build();
        }
      }
    }
    return getGetNetworkModelRelationshipMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsResponse> getListNetworkModelRelationshipsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListNetworkModelRelationships",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsRequest.class,
      responseType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsResponse> getListNetworkModelRelationshipsMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsResponse> getListNetworkModelRelationshipsMethod;
    if ((getListNetworkModelRelationshipsMethod = SimulationServiceGrpc.getListNetworkModelRelationshipsMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getListNetworkModelRelationshipsMethod = SimulationServiceGrpc.getListNetworkModelRelationshipsMethod) == null) {
          SimulationServiceGrpc.getListNetworkModelRelationshipsMethod = getListNetworkModelRelationshipsMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListNetworkModelRelationships"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("ListNetworkModelRelationships"))
              .build();
        }
      }
    }
    return getListNetworkModelRelationshipsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelRelationshipRequest,
      org.outernetcouncil.nmts.v1.proto.Nmts.Relationship> getCreateNetworkModelRelationshipMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateNetworkModelRelationship",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelRelationshipRequest.class,
      responseType = org.outernetcouncil.nmts.v1.proto.Nmts.Relationship.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelRelationshipRequest,
      org.outernetcouncil.nmts.v1.proto.Nmts.Relationship> getCreateNetworkModelRelationshipMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelRelationshipRequest, org.outernetcouncil.nmts.v1.proto.Nmts.Relationship> getCreateNetworkModelRelationshipMethod;
    if ((getCreateNetworkModelRelationshipMethod = SimulationServiceGrpc.getCreateNetworkModelRelationshipMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getCreateNetworkModelRelationshipMethod = SimulationServiceGrpc.getCreateNetworkModelRelationshipMethod) == null) {
          SimulationServiceGrpc.getCreateNetworkModelRelationshipMethod = getCreateNetworkModelRelationshipMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelRelationshipRequest, org.outernetcouncil.nmts.v1.proto.Nmts.Relationship>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateNetworkModelRelationship"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelRelationshipRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  org.outernetcouncil.nmts.v1.proto.Nmts.Relationship.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("CreateNetworkModelRelationship"))
              .build();
        }
      }
    }
    return getCreateNetworkModelRelationshipMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelRelationshipRequest,
      com.google.protobuf.Empty> getDeleteNetworkModelRelationshipMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteNetworkModelRelationship",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelRelationshipRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelRelationshipRequest,
      com.google.protobuf.Empty> getDeleteNetworkModelRelationshipMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelRelationshipRequest, com.google.protobuf.Empty> getDeleteNetworkModelRelationshipMethod;
    if ((getDeleteNetworkModelRelationshipMethod = SimulationServiceGrpc.getDeleteNetworkModelRelationshipMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getDeleteNetworkModelRelationshipMethod = SimulationServiceGrpc.getDeleteNetworkModelRelationshipMethod) == null) {
          SimulationServiceGrpc.getDeleteNetworkModelRelationshipMethod = getDeleteNetworkModelRelationshipMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelRelationshipRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeleteNetworkModelRelationship"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelRelationshipRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("DeleteNetworkModelRelationship"))
              .build();
        }
      }
    }
    return getDeleteNetworkModelRelationshipMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy> getGetP2pSrTePolicyMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetP2pSrTePolicy",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyRequest.class,
      responseType = com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy> getGetP2pSrTePolicyMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy> getGetP2pSrTePolicyMethod;
    if ((getGetP2pSrTePolicyMethod = SimulationServiceGrpc.getGetP2pSrTePolicyMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getGetP2pSrTePolicyMethod = SimulationServiceGrpc.getGetP2pSrTePolicyMethod) == null) {
          SimulationServiceGrpc.getGetP2pSrTePolicyMethod = getGetP2pSrTePolicyMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetP2pSrTePolicy"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("GetP2pSrTePolicy"))
              .build();
        }
      }
    }
    return getGetP2pSrTePolicyMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesResponse> getListP2pSrTePoliciesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListP2pSrTePolicies",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesRequest.class,
      responseType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesResponse> getListP2pSrTePoliciesMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesResponse> getListP2pSrTePoliciesMethod;
    if ((getListP2pSrTePoliciesMethod = SimulationServiceGrpc.getListP2pSrTePoliciesMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getListP2pSrTePoliciesMethod = SimulationServiceGrpc.getListP2pSrTePoliciesMethod) == null) {
          SimulationServiceGrpc.getListP2pSrTePoliciesMethod = getListP2pSrTePoliciesMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListP2pSrTePolicies"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesResponse.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("ListP2pSrTePolicies"))
              .build();
        }
      }
    }
    return getListP2pSrTePoliciesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy> getCreateP2pSrTePolicyMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateP2pSrTePolicy",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyRequest.class,
      responseType = com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy> getCreateP2pSrTePolicyMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy> getCreateP2pSrTePolicyMethod;
    if ((getCreateP2pSrTePolicyMethod = SimulationServiceGrpc.getCreateP2pSrTePolicyMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getCreateP2pSrTePolicyMethod = SimulationServiceGrpc.getCreateP2pSrTePolicyMethod) == null) {
          SimulationServiceGrpc.getCreateP2pSrTePolicyMethod = getCreateP2pSrTePolicyMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateP2pSrTePolicy"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("CreateP2pSrTePolicy"))
              .build();
        }
      }
    }
    return getCreateP2pSrTePolicyMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy> getUpdateP2pSrTePolicyMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateP2pSrTePolicy",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyRequest.class,
      responseType = com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy> getUpdateP2pSrTePolicyMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy> getUpdateP2pSrTePolicyMethod;
    if ((getUpdateP2pSrTePolicyMethod = SimulationServiceGrpc.getUpdateP2pSrTePolicyMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getUpdateP2pSrTePolicyMethod = SimulationServiceGrpc.getUpdateP2pSrTePolicyMethod) == null) {
          SimulationServiceGrpc.getUpdateP2pSrTePolicyMethod = getUpdateP2pSrTePolicyMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateP2pSrTePolicy"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("UpdateP2pSrTePolicy"))
              .build();
        }
      }
    }
    return getUpdateP2pSrTePolicyMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyRequest,
      com.google.protobuf.Empty> getDeleteP2pSrTePolicyMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteP2pSrTePolicy",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyRequest,
      com.google.protobuf.Empty> getDeleteP2pSrTePolicyMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyRequest, com.google.protobuf.Empty> getDeleteP2pSrTePolicyMethod;
    if ((getDeleteP2pSrTePolicyMethod = SimulationServiceGrpc.getDeleteP2pSrTePolicyMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getDeleteP2pSrTePolicyMethod = SimulationServiceGrpc.getDeleteP2pSrTePolicyMethod) == null) {
          SimulationServiceGrpc.getDeleteP2pSrTePolicyMethod = getDeleteP2pSrTePolicyMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeleteP2pSrTePolicy"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("DeleteP2pSrTePolicy"))
              .build();
        }
      }
    }
    return getDeleteP2pSrTePolicyMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyCandidatePathRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath> getGetP2pSrTePolicyCandidatePathMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetP2pSrTePolicyCandidatePath",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyCandidatePathRequest.class,
      responseType = com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyCandidatePathRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath> getGetP2pSrTePolicyCandidatePathMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyCandidatePathRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath> getGetP2pSrTePolicyCandidatePathMethod;
    if ((getGetP2pSrTePolicyCandidatePathMethod = SimulationServiceGrpc.getGetP2pSrTePolicyCandidatePathMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getGetP2pSrTePolicyCandidatePathMethod = SimulationServiceGrpc.getGetP2pSrTePolicyCandidatePathMethod) == null) {
          SimulationServiceGrpc.getGetP2pSrTePolicyCandidatePathMethod = getGetP2pSrTePolicyCandidatePathMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyCandidatePathRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetP2pSrTePolicyCandidatePath"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyCandidatePathRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("GetP2pSrTePolicyCandidatePath"))
              .build();
        }
      }
    }
    return getGetP2pSrTePolicyCandidatePathMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsResponse> getListP2pSrTePolicyCandidatePathsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListP2pSrTePolicyCandidatePaths",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsRequest.class,
      responseType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsResponse> getListP2pSrTePolicyCandidatePathsMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsResponse> getListP2pSrTePolicyCandidatePathsMethod;
    if ((getListP2pSrTePolicyCandidatePathsMethod = SimulationServiceGrpc.getListP2pSrTePolicyCandidatePathsMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getListP2pSrTePolicyCandidatePathsMethod = SimulationServiceGrpc.getListP2pSrTePolicyCandidatePathsMethod) == null) {
          SimulationServiceGrpc.getListP2pSrTePolicyCandidatePathsMethod = getListP2pSrTePolicyCandidatePathsMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListP2pSrTePolicyCandidatePaths"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("ListP2pSrTePolicyCandidatePaths"))
              .build();
        }
      }
    }
    return getListP2pSrTePolicyCandidatePathsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyCandidatePathRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath> getCreateP2pSrTePolicyCandidatePathMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateP2pSrTePolicyCandidatePath",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyCandidatePathRequest.class,
      responseType = com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyCandidatePathRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath> getCreateP2pSrTePolicyCandidatePathMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyCandidatePathRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath> getCreateP2pSrTePolicyCandidatePathMethod;
    if ((getCreateP2pSrTePolicyCandidatePathMethod = SimulationServiceGrpc.getCreateP2pSrTePolicyCandidatePathMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getCreateP2pSrTePolicyCandidatePathMethod = SimulationServiceGrpc.getCreateP2pSrTePolicyCandidatePathMethod) == null) {
          SimulationServiceGrpc.getCreateP2pSrTePolicyCandidatePathMethod = getCreateP2pSrTePolicyCandidatePathMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyCandidatePathRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateP2pSrTePolicyCandidatePath"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyCandidatePathRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("CreateP2pSrTePolicyCandidatePath"))
              .build();
        }
      }
    }
    return getCreateP2pSrTePolicyCandidatePathMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyCandidatePathRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath> getUpdateP2pSrTePolicyCandidatePathMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateP2pSrTePolicyCandidatePath",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyCandidatePathRequest.class,
      responseType = com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyCandidatePathRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath> getUpdateP2pSrTePolicyCandidatePathMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyCandidatePathRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath> getUpdateP2pSrTePolicyCandidatePathMethod;
    if ((getUpdateP2pSrTePolicyCandidatePathMethod = SimulationServiceGrpc.getUpdateP2pSrTePolicyCandidatePathMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getUpdateP2pSrTePolicyCandidatePathMethod = SimulationServiceGrpc.getUpdateP2pSrTePolicyCandidatePathMethod) == null) {
          SimulationServiceGrpc.getUpdateP2pSrTePolicyCandidatePathMethod = getUpdateP2pSrTePolicyCandidatePathMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyCandidatePathRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateP2pSrTePolicyCandidatePath"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyCandidatePathRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("UpdateP2pSrTePolicyCandidatePath"))
              .build();
        }
      }
    }
    return getUpdateP2pSrTePolicyCandidatePathMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyCandidatePathRequest,
      com.google.protobuf.Empty> getDeleteP2pSrTePolicyCandidatePathMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteP2pSrTePolicyCandidatePath",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyCandidatePathRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyCandidatePathRequest,
      com.google.protobuf.Empty> getDeleteP2pSrTePolicyCandidatePathMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyCandidatePathRequest, com.google.protobuf.Empty> getDeleteP2pSrTePolicyCandidatePathMethod;
    if ((getDeleteP2pSrTePolicyCandidatePathMethod = SimulationServiceGrpc.getDeleteP2pSrTePolicyCandidatePathMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getDeleteP2pSrTePolicyCandidatePathMethod = SimulationServiceGrpc.getDeleteP2pSrTePolicyCandidatePathMethod) == null) {
          SimulationServiceGrpc.getDeleteP2pSrTePolicyCandidatePathMethod = getDeleteP2pSrTePolicyCandidatePathMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyCandidatePathRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeleteP2pSrTePolicyCandidatePath"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyCandidatePathRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("DeleteP2pSrTePolicyCandidatePath"))
              .build();
        }
      }
    }
    return getDeleteP2pSrTePolicyCandidatePathMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDowntimeRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime> getGetDowntimeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetDowntime",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDowntimeRequest.class,
      responseType = com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDowntimeRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime> getGetDowntimeMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDowntimeRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime> getGetDowntimeMethod;
    if ((getGetDowntimeMethod = SimulationServiceGrpc.getGetDowntimeMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getGetDowntimeMethod = SimulationServiceGrpc.getGetDowntimeMethod) == null) {
          SimulationServiceGrpc.getGetDowntimeMethod = getGetDowntimeMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDowntimeRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetDowntime"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDowntimeRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("GetDowntime"))
              .build();
        }
      }
    }
    return getGetDowntimeMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesResponse> getListDowntimesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListDowntimes",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesRequest.class,
      responseType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesResponse> getListDowntimesMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesResponse> getListDowntimesMethod;
    if ((getListDowntimesMethod = SimulationServiceGrpc.getListDowntimesMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getListDowntimesMethod = SimulationServiceGrpc.getListDowntimesMethod) == null) {
          SimulationServiceGrpc.getListDowntimesMethod = getListDowntimesMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListDowntimes"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesResponse.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("ListDowntimes"))
              .build();
        }
      }
    }
    return getListDowntimesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDowntimeRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime> getCreateDowntimeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateDowntime",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDowntimeRequest.class,
      responseType = com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDowntimeRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime> getCreateDowntimeMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDowntimeRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime> getCreateDowntimeMethod;
    if ((getCreateDowntimeMethod = SimulationServiceGrpc.getCreateDowntimeMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getCreateDowntimeMethod = SimulationServiceGrpc.getCreateDowntimeMethod) == null) {
          SimulationServiceGrpc.getCreateDowntimeMethod = getCreateDowntimeMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDowntimeRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateDowntime"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDowntimeRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("CreateDowntime"))
              .build();
        }
      }
    }
    return getCreateDowntimeMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDowntimeRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime> getUpdateDowntimeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateDowntime",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDowntimeRequest.class,
      responseType = com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDowntimeRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime> getUpdateDowntimeMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDowntimeRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime> getUpdateDowntimeMethod;
    if ((getUpdateDowntimeMethod = SimulationServiceGrpc.getUpdateDowntimeMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getUpdateDowntimeMethod = SimulationServiceGrpc.getUpdateDowntimeMethod) == null) {
          SimulationServiceGrpc.getUpdateDowntimeMethod = getUpdateDowntimeMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDowntimeRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateDowntime"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDowntimeRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("UpdateDowntime"))
              .build();
        }
      }
    }
    return getUpdateDowntimeMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDowntimeRequest,
      com.google.protobuf.Empty> getDeleteDowntimeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteDowntime",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDowntimeRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDowntimeRequest,
      com.google.protobuf.Empty> getDeleteDowntimeMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDowntimeRequest, com.google.protobuf.Empty> getDeleteDowntimeMethod;
    if ((getDeleteDowntimeMethod = SimulationServiceGrpc.getDeleteDowntimeMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getDeleteDowntimeMethod = SimulationServiceGrpc.getDeleteDowntimeMethod) == null) {
          SimulationServiceGrpc.getDeleteDowntimeMethod = getDeleteDowntimeMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDowntimeRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeleteDowntime"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDowntimeRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("DeleteDowntime"))
              .build();
        }
      }
    }
    return getDeleteDowntimeMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetProtectionAssociationGroupRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup> getGetProtectionAssociationGroupMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetProtectionAssociationGroup",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetProtectionAssociationGroupRequest.class,
      responseType = com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetProtectionAssociationGroupRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup> getGetProtectionAssociationGroupMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetProtectionAssociationGroupRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup> getGetProtectionAssociationGroupMethod;
    if ((getGetProtectionAssociationGroupMethod = SimulationServiceGrpc.getGetProtectionAssociationGroupMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getGetProtectionAssociationGroupMethod = SimulationServiceGrpc.getGetProtectionAssociationGroupMethod) == null) {
          SimulationServiceGrpc.getGetProtectionAssociationGroupMethod = getGetProtectionAssociationGroupMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetProtectionAssociationGroupRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetProtectionAssociationGroup"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetProtectionAssociationGroupRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("GetProtectionAssociationGroup"))
              .build();
        }
      }
    }
    return getGetProtectionAssociationGroupMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsResponse> getListProtectionAssociationGroupsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListProtectionAssociationGroups",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsRequest.class,
      responseType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsResponse> getListProtectionAssociationGroupsMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsResponse> getListProtectionAssociationGroupsMethod;
    if ((getListProtectionAssociationGroupsMethod = SimulationServiceGrpc.getListProtectionAssociationGroupsMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getListProtectionAssociationGroupsMethod = SimulationServiceGrpc.getListProtectionAssociationGroupsMethod) == null) {
          SimulationServiceGrpc.getListProtectionAssociationGroupsMethod = getListProtectionAssociationGroupsMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListProtectionAssociationGroups"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("ListProtectionAssociationGroups"))
              .build();
        }
      }
    }
    return getListProtectionAssociationGroupsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateProtectionAssociationGroupRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup> getCreateProtectionAssociationGroupMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateProtectionAssociationGroup",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateProtectionAssociationGroupRequest.class,
      responseType = com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateProtectionAssociationGroupRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup> getCreateProtectionAssociationGroupMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateProtectionAssociationGroupRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup> getCreateProtectionAssociationGroupMethod;
    if ((getCreateProtectionAssociationGroupMethod = SimulationServiceGrpc.getCreateProtectionAssociationGroupMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getCreateProtectionAssociationGroupMethod = SimulationServiceGrpc.getCreateProtectionAssociationGroupMethod) == null) {
          SimulationServiceGrpc.getCreateProtectionAssociationGroupMethod = getCreateProtectionAssociationGroupMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateProtectionAssociationGroupRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateProtectionAssociationGroup"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateProtectionAssociationGroupRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("CreateProtectionAssociationGroup"))
              .build();
        }
      }
    }
    return getCreateProtectionAssociationGroupMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateProtectionAssociationGroupRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup> getUpdateProtectionAssociationGroupMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateProtectionAssociationGroup",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateProtectionAssociationGroupRequest.class,
      responseType = com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateProtectionAssociationGroupRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup> getUpdateProtectionAssociationGroupMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateProtectionAssociationGroupRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup> getUpdateProtectionAssociationGroupMethod;
    if ((getUpdateProtectionAssociationGroupMethod = SimulationServiceGrpc.getUpdateProtectionAssociationGroupMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getUpdateProtectionAssociationGroupMethod = SimulationServiceGrpc.getUpdateProtectionAssociationGroupMethod) == null) {
          SimulationServiceGrpc.getUpdateProtectionAssociationGroupMethod = getUpdateProtectionAssociationGroupMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateProtectionAssociationGroupRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateProtectionAssociationGroup"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateProtectionAssociationGroupRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("UpdateProtectionAssociationGroup"))
              .build();
        }
      }
    }
    return getUpdateProtectionAssociationGroupMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteProtectionAssociationGroupRequest,
      com.google.protobuf.Empty> getDeleteProtectionAssociationGroupMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteProtectionAssociationGroup",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteProtectionAssociationGroupRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteProtectionAssociationGroupRequest,
      com.google.protobuf.Empty> getDeleteProtectionAssociationGroupMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteProtectionAssociationGroupRequest, com.google.protobuf.Empty> getDeleteProtectionAssociationGroupMethod;
    if ((getDeleteProtectionAssociationGroupMethod = SimulationServiceGrpc.getDeleteProtectionAssociationGroupMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getDeleteProtectionAssociationGroupMethod = SimulationServiceGrpc.getDeleteProtectionAssociationGroupMethod) == null) {
          SimulationServiceGrpc.getDeleteProtectionAssociationGroupMethod = getDeleteProtectionAssociationGroupMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteProtectionAssociationGroupRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeleteProtectionAssociationGroup"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteProtectionAssociationGroupRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("DeleteProtectionAssociationGroup"))
              .build();
        }
      }
    }
    return getDeleteProtectionAssociationGroupMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDisjointAssociationGroupRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup> getGetDisjointAssociationGroupMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetDisjointAssociationGroup",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDisjointAssociationGroupRequest.class,
      responseType = com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDisjointAssociationGroupRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup> getGetDisjointAssociationGroupMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDisjointAssociationGroupRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup> getGetDisjointAssociationGroupMethod;
    if ((getGetDisjointAssociationGroupMethod = SimulationServiceGrpc.getGetDisjointAssociationGroupMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getGetDisjointAssociationGroupMethod = SimulationServiceGrpc.getGetDisjointAssociationGroupMethod) == null) {
          SimulationServiceGrpc.getGetDisjointAssociationGroupMethod = getGetDisjointAssociationGroupMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDisjointAssociationGroupRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetDisjointAssociationGroup"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDisjointAssociationGroupRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("GetDisjointAssociationGroup"))
              .build();
        }
      }
    }
    return getGetDisjointAssociationGroupMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsResponse> getListDisjointAssociationGroupsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListDisjointAssociationGroups",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsRequest.class,
      responseType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsResponse> getListDisjointAssociationGroupsMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsResponse> getListDisjointAssociationGroupsMethod;
    if ((getListDisjointAssociationGroupsMethod = SimulationServiceGrpc.getListDisjointAssociationGroupsMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getListDisjointAssociationGroupsMethod = SimulationServiceGrpc.getListDisjointAssociationGroupsMethod) == null) {
          SimulationServiceGrpc.getListDisjointAssociationGroupsMethod = getListDisjointAssociationGroupsMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListDisjointAssociationGroups"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("ListDisjointAssociationGroups"))
              .build();
        }
      }
    }
    return getListDisjointAssociationGroupsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDisjointAssociationGroupRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup> getCreateDisjointAssociationGroupMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateDisjointAssociationGroup",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDisjointAssociationGroupRequest.class,
      responseType = com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDisjointAssociationGroupRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup> getCreateDisjointAssociationGroupMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDisjointAssociationGroupRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup> getCreateDisjointAssociationGroupMethod;
    if ((getCreateDisjointAssociationGroupMethod = SimulationServiceGrpc.getCreateDisjointAssociationGroupMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getCreateDisjointAssociationGroupMethod = SimulationServiceGrpc.getCreateDisjointAssociationGroupMethod) == null) {
          SimulationServiceGrpc.getCreateDisjointAssociationGroupMethod = getCreateDisjointAssociationGroupMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDisjointAssociationGroupRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateDisjointAssociationGroup"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDisjointAssociationGroupRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("CreateDisjointAssociationGroup"))
              .build();
        }
      }
    }
    return getCreateDisjointAssociationGroupMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDisjointAssociationGroupRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup> getUpdateDisjointAssociationGroupMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateDisjointAssociationGroup",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDisjointAssociationGroupRequest.class,
      responseType = com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDisjointAssociationGroupRequest,
      com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup> getUpdateDisjointAssociationGroupMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDisjointAssociationGroupRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup> getUpdateDisjointAssociationGroupMethod;
    if ((getUpdateDisjointAssociationGroupMethod = SimulationServiceGrpc.getUpdateDisjointAssociationGroupMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getUpdateDisjointAssociationGroupMethod = SimulationServiceGrpc.getUpdateDisjointAssociationGroupMethod) == null) {
          SimulationServiceGrpc.getUpdateDisjointAssociationGroupMethod = getUpdateDisjointAssociationGroupMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDisjointAssociationGroupRequest, com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateDisjointAssociationGroup"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDisjointAssociationGroupRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("UpdateDisjointAssociationGroup"))
              .build();
        }
      }
    }
    return getUpdateDisjointAssociationGroupMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDisjointAssociationGroupRequest,
      com.google.protobuf.Empty> getDeleteDisjointAssociationGroupMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteDisjointAssociationGroup",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDisjointAssociationGroupRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDisjointAssociationGroupRequest,
      com.google.protobuf.Empty> getDeleteDisjointAssociationGroupMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDisjointAssociationGroupRequest, com.google.protobuf.Empty> getDeleteDisjointAssociationGroupMethod;
    if ((getDeleteDisjointAssociationGroupMethod = SimulationServiceGrpc.getDeleteDisjointAssociationGroupMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getDeleteDisjointAssociationGroupMethod = SimulationServiceGrpc.getDeleteDisjointAssociationGroupMethod) == null) {
          SimulationServiceGrpc.getDeleteDisjointAssociationGroupMethod = getDeleteDisjointAssociationGroupMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDisjointAssociationGroupRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeleteDisjointAssociationGroup"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDisjointAssociationGroupRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("DeleteDisjointAssociationGroup"))
              .build();
        }
      }
    }
    return getDeleteDisjointAssociationGroupMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetSimulationRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation> getGetSimulationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetSimulation",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetSimulationRequest.class,
      responseType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetSimulationRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation> getGetSimulationMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetSimulationRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation> getGetSimulationMethod;
    if ((getGetSimulationMethod = SimulationServiceGrpc.getGetSimulationMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getGetSimulationMethod = SimulationServiceGrpc.getGetSimulationMethod) == null) {
          SimulationServiceGrpc.getGetSimulationMethod = getGetSimulationMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetSimulationRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetSimulation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetSimulationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("GetSimulation"))
              .build();
        }
      }
    }
    return getGetSimulationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsResponse> getListSimulationsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListSimulations",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsRequest.class,
      responseType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsResponse> getListSimulationsMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsResponse> getListSimulationsMethod;
    if ((getListSimulationsMethod = SimulationServiceGrpc.getListSimulationsMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getListSimulationsMethod = SimulationServiceGrpc.getListSimulationsMethod) == null) {
          SimulationServiceGrpc.getListSimulationsMethod = getListSimulationsMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListSimulations"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("ListSimulations"))
              .build();
        }
      }
    }
    return getListSimulationsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateSimulationRequest,
      com.google.longrunning.Operation> getCreateSimulationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateSimulation",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateSimulationRequest.class,
      responseType = com.google.longrunning.Operation.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateSimulationRequest,
      com.google.longrunning.Operation> getCreateSimulationMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateSimulationRequest, com.google.longrunning.Operation> getCreateSimulationMethod;
    if ((getCreateSimulationMethod = SimulationServiceGrpc.getCreateSimulationMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getCreateSimulationMethod = SimulationServiceGrpc.getCreateSimulationMethod) == null) {
          SimulationServiceGrpc.getCreateSimulationMethod = getCreateSimulationMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateSimulationRequest, com.google.longrunning.Operation>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateSimulation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateSimulationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.longrunning.Operation.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("CreateSimulation"))
              .build();
        }
      }
    }
    return getCreateSimulationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteSimulationRequest,
      com.google.protobuf.Empty> getDeleteSimulationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteSimulation",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteSimulationRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteSimulationRequest,
      com.google.protobuf.Empty> getDeleteSimulationMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteSimulationRequest, com.google.protobuf.Empty> getDeleteSimulationMethod;
    if ((getDeleteSimulationMethod = SimulationServiceGrpc.getDeleteSimulationMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getDeleteSimulationMethod = SimulationServiceGrpc.getDeleteSimulationMethod) == null) {
          SimulationServiceGrpc.getDeleteSimulationMethod = getDeleteSimulationMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteSimulationRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeleteSimulation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteSimulationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("DeleteSimulation"))
              .build();
        }
      }
    }
    return getDeleteSimulationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetAnalysisRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis> getGetAnalysisMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetAnalysis",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetAnalysisRequest.class,
      responseType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetAnalysisRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis> getGetAnalysisMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetAnalysisRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis> getGetAnalysisMethod;
    if ((getGetAnalysisMethod = SimulationServiceGrpc.getGetAnalysisMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getGetAnalysisMethod = SimulationServiceGrpc.getGetAnalysisMethod) == null) {
          SimulationServiceGrpc.getGetAnalysisMethod = getGetAnalysisMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetAnalysisRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetAnalysis"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetAnalysisRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("GetAnalysis"))
              .build();
        }
      }
    }
    return getGetAnalysisMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesResponse> getListAnalysesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListAnalyses",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesRequest.class,
      responseType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesResponse> getListAnalysesMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesResponse> getListAnalysesMethod;
    if ((getListAnalysesMethod = SimulationServiceGrpc.getListAnalysesMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getListAnalysesMethod = SimulationServiceGrpc.getListAnalysesMethod) == null) {
          SimulationServiceGrpc.getListAnalysesMethod = getListAnalysesMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListAnalyses"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesResponse.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("ListAnalyses"))
              .build();
        }
      }
    }
    return getListAnalysesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateAnalysisRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis> getCreateAnalysisMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateAnalysis",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateAnalysisRequest.class,
      responseType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateAnalysisRequest,
      com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis> getCreateAnalysisMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateAnalysisRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis> getCreateAnalysisMethod;
    if ((getCreateAnalysisMethod = SimulationServiceGrpc.getCreateAnalysisMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getCreateAnalysisMethod = SimulationServiceGrpc.getCreateAnalysisMethod) == null) {
          SimulationServiceGrpc.getCreateAnalysisMethod = getCreateAnalysisMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateAnalysisRequest, com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateAnalysis"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateAnalysisRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("CreateAnalysis"))
              .build();
        }
      }
    }
    return getCreateAnalysisMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteAnalysisRequest,
      com.google.protobuf.Empty> getDeleteAnalysisMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteAnalysis",
      requestType = com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteAnalysisRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteAnalysisRequest,
      com.google.protobuf.Empty> getDeleteAnalysisMethod() {
    io.grpc.MethodDescriptor<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteAnalysisRequest, com.google.protobuf.Empty> getDeleteAnalysisMethod;
    if ((getDeleteAnalysisMethod = SimulationServiceGrpc.getDeleteAnalysisMethod) == null) {
      synchronized (SimulationServiceGrpc.class) {
        if ((getDeleteAnalysisMethod = SimulationServiceGrpc.getDeleteAnalysisMethod) == null) {
          SimulationServiceGrpc.getDeleteAnalysisMethod = getDeleteAnalysisMethod =
              io.grpc.MethodDescriptor.<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteAnalysisRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeleteAnalysis"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteAnalysisRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new SimulationServiceMethodDescriptorSupplier("DeleteAnalysis"))
              .build();
        }
      }
    }
    return getDeleteAnalysisMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static SimulationServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<SimulationServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<SimulationServiceStub>() {
        @java.lang.Override
        public SimulationServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new SimulationServiceStub(channel, callOptions);
        }
      };
    return SimulationServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static SimulationServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<SimulationServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<SimulationServiceBlockingStub>() {
        @java.lang.Override
        public SimulationServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new SimulationServiceBlockingStub(channel, callOptions);
        }
      };
    return SimulationServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static SimulationServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<SimulationServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<SimulationServiceFutureStub>() {
        @java.lang.Override
        public SimulationServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new SimulationServiceFutureStub(channel, callOptions);
        }
      };
    return SimulationServiceFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * Simulation API.
   * The resources managed by this API are:
   * * Scenarios, which define a system to be simulated.
   *   * Network model entities, which represent entities in a network.
   *   * Network model relationships, which represent relationships between
   *     entities in a network.
   *   * P2pSrTePolicies, which represent point-to-point SR-TE policies in the
   *     network.
   *     * P2pSrTePolicyCandidatePaths, which represent requests to establish
   *       candidate paths in service of SR-TE policies.
   *   * Downtimes, which represent downtimes of entities in the scenario.
   *   * ProtectionAssociationGroups, which indicate which paths through the
   *     network are to serve as protection to others.
   *   * DisjointAssociationGroups, which indicate which paths are to traverse
   *     disjoint paths through the network.
   * * Simulations, which represent simulations of a scenario over a time
   *   interval.
   *   * Analyses, statistical analyses of a simulation's results.
   * A simulation may be set-up, run, and analyzed via the following process:
   * 1. Create a scenario, giving the scenario a name and description.
   * 2. Define the scenario by creating the scenario's network model entities and
   *    relationships, point-to-point SR-TE policies and candidate paths,
   *    downtimes, protection association groups, and disjoint association groups.
   * 3. Create a simulation, referencing the scenario by name and specifying a
   *    time interval to be simulated. Spacetime will populate the simulation with
   *    the results of the simulation.
   * 4. Create an analysis, specifying analysis interval and granularity.
   *    Spacetime will populate the analysis with the results of the statistical
   *    analysis of the simulation results.
   * </pre>
   */
  public interface AsyncService {

    /**
     */
    default void getScenario(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetScenarioRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetScenarioMethod(), responseObserver);
    }

    /**
     */
    default void listScenarios(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListScenariosMethod(), responseObserver);
    }

    /**
     */
    default void createScenario(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateScenarioRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateScenarioMethod(), responseObserver);
    }

    /**
     */
    default void updateScenario(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateScenarioRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateScenarioMethod(), responseObserver);
    }

    /**
     */
    default void deleteScenario(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteScenarioRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteScenarioMethod(), responseObserver);
    }

    /**
     */
    default void copyScenario(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CopyScenarioRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCopyScenarioMethod(), responseObserver);
    }

    /**
     */
    default void getNetworkModelEntity(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelEntityRequest request,
        io.grpc.stub.StreamObserver<org.outernetcouncil.nmts.v1.proto.Nmts.Entity> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetNetworkModelEntityMethod(), responseObserver);
    }

    /**
     */
    default void listNetworkModelEntities(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListNetworkModelEntitiesMethod(), responseObserver);
    }

    /**
     */
    default void createNetworkModelEntity(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelEntityRequest request,
        io.grpc.stub.StreamObserver<org.outernetcouncil.nmts.v1.proto.Nmts.Entity> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateNetworkModelEntityMethod(), responseObserver);
    }

    /**
     */
    default void updateNetworkModelEntity(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateNetworkModelEntityRequest request,
        io.grpc.stub.StreamObserver<org.outernetcouncil.nmts.v1.proto.Nmts.Entity> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateNetworkModelEntityMethod(), responseObserver);
    }

    /**
     */
    default void deleteNetworkModelEntity(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelEntityRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteNetworkModelEntityMethod(), responseObserver);
    }

    /**
     */
    default void getNetworkModelRelationship(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelRelationshipRequest request,
        io.grpc.stub.StreamObserver<org.outernetcouncil.nmts.v1.proto.Nmts.Relationship> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetNetworkModelRelationshipMethod(), responseObserver);
    }

    /**
     */
    default void listNetworkModelRelationships(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListNetworkModelRelationshipsMethod(), responseObserver);
    }

    /**
     */
    default void createNetworkModelRelationship(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelRelationshipRequest request,
        io.grpc.stub.StreamObserver<org.outernetcouncil.nmts.v1.proto.Nmts.Relationship> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateNetworkModelRelationshipMethod(), responseObserver);
    }

    /**
     */
    default void deleteNetworkModelRelationship(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelRelationshipRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteNetworkModelRelationshipMethod(), responseObserver);
    }

    /**
     */
    default void getP2pSrTePolicy(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetP2pSrTePolicyMethod(), responseObserver);
    }

    /**
     */
    default void listP2pSrTePolicies(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListP2pSrTePoliciesMethod(), responseObserver);
    }

    /**
     */
    default void createP2pSrTePolicy(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateP2pSrTePolicyMethod(), responseObserver);
    }

    /**
     */
    default void updateP2pSrTePolicy(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateP2pSrTePolicyMethod(), responseObserver);
    }

    /**
     */
    default void deleteP2pSrTePolicy(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteP2pSrTePolicyMethod(), responseObserver);
    }

    /**
     */
    default void getP2pSrTePolicyCandidatePath(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyCandidatePathRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetP2pSrTePolicyCandidatePathMethod(), responseObserver);
    }

    /**
     */
    default void listP2pSrTePolicyCandidatePaths(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListP2pSrTePolicyCandidatePathsMethod(), responseObserver);
    }

    /**
     */
    default void createP2pSrTePolicyCandidatePath(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyCandidatePathRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateP2pSrTePolicyCandidatePathMethod(), responseObserver);
    }

    /**
     */
    default void updateP2pSrTePolicyCandidatePath(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyCandidatePathRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateP2pSrTePolicyCandidatePathMethod(), responseObserver);
    }

    /**
     */
    default void deleteP2pSrTePolicyCandidatePath(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyCandidatePathRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteP2pSrTePolicyCandidatePathMethod(), responseObserver);
    }

    /**
     */
    default void getDowntime(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDowntimeRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetDowntimeMethod(), responseObserver);
    }

    /**
     */
    default void listDowntimes(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListDowntimesMethod(), responseObserver);
    }

    /**
     */
    default void createDowntime(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDowntimeRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateDowntimeMethod(), responseObserver);
    }

    /**
     */
    default void updateDowntime(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDowntimeRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateDowntimeMethod(), responseObserver);
    }

    /**
     */
    default void deleteDowntime(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDowntimeRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteDowntimeMethod(), responseObserver);
    }

    /**
     */
    default void getProtectionAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetProtectionAssociationGroupRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetProtectionAssociationGroupMethod(), responseObserver);
    }

    /**
     */
    default void listProtectionAssociationGroups(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListProtectionAssociationGroupsMethod(), responseObserver);
    }

    /**
     */
    default void createProtectionAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateProtectionAssociationGroupRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateProtectionAssociationGroupMethod(), responseObserver);
    }

    /**
     */
    default void updateProtectionAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateProtectionAssociationGroupRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateProtectionAssociationGroupMethod(), responseObserver);
    }

    /**
     */
    default void deleteProtectionAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteProtectionAssociationGroupRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteProtectionAssociationGroupMethod(), responseObserver);
    }

    /**
     */
    default void getDisjointAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDisjointAssociationGroupRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetDisjointAssociationGroupMethod(), responseObserver);
    }

    /**
     */
    default void listDisjointAssociationGroups(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListDisjointAssociationGroupsMethod(), responseObserver);
    }

    /**
     */
    default void createDisjointAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDisjointAssociationGroupRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateDisjointAssociationGroupMethod(), responseObserver);
    }

    /**
     */
    default void updateDisjointAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDisjointAssociationGroupRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateDisjointAssociationGroupMethod(), responseObserver);
    }

    /**
     */
    default void deleteDisjointAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDisjointAssociationGroupRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteDisjointAssociationGroupMethod(), responseObserver);
    }

    /**
     */
    default void getSimulation(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetSimulationRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetSimulationMethod(), responseObserver);
    }

    /**
     */
    default void listSimulations(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListSimulationsMethod(), responseObserver);
    }

    /**
     */
    default void createSimulation(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateSimulationRequest request,
        io.grpc.stub.StreamObserver<com.google.longrunning.Operation> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateSimulationMethod(), responseObserver);
    }

    /**
     */
    default void deleteSimulation(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteSimulationRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteSimulationMethod(), responseObserver);
    }

    /**
     */
    default void getAnalysis(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetAnalysisRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetAnalysisMethod(), responseObserver);
    }

    /**
     */
    default void listAnalyses(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListAnalysesMethod(), responseObserver);
    }

    /**
     */
    default void createAnalysis(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateAnalysisRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateAnalysisMethod(), responseObserver);
    }

    /**
     */
    default void deleteAnalysis(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteAnalysisRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteAnalysisMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service SimulationService.
   * <pre>
   * Simulation API.
   * The resources managed by this API are:
   * * Scenarios, which define a system to be simulated.
   *   * Network model entities, which represent entities in a network.
   *   * Network model relationships, which represent relationships between
   *     entities in a network.
   *   * P2pSrTePolicies, which represent point-to-point SR-TE policies in the
   *     network.
   *     * P2pSrTePolicyCandidatePaths, which represent requests to establish
   *       candidate paths in service of SR-TE policies.
   *   * Downtimes, which represent downtimes of entities in the scenario.
   *   * ProtectionAssociationGroups, which indicate which paths through the
   *     network are to serve as protection to others.
   *   * DisjointAssociationGroups, which indicate which paths are to traverse
   *     disjoint paths through the network.
   * * Simulations, which represent simulations of a scenario over a time
   *   interval.
   *   * Analyses, statistical analyses of a simulation's results.
   * A simulation may be set-up, run, and analyzed via the following process:
   * 1. Create a scenario, giving the scenario a name and description.
   * 2. Define the scenario by creating the scenario's network model entities and
   *    relationships, point-to-point SR-TE policies and candidate paths,
   *    downtimes, protection association groups, and disjoint association groups.
   * 3. Create a simulation, referencing the scenario by name and specifying a
   *    time interval to be simulated. Spacetime will populate the simulation with
   *    the results of the simulation.
   * 4. Create an analysis, specifying analysis interval and granularity.
   *    Spacetime will populate the analysis with the results of the statistical
   *    analysis of the simulation results.
   * </pre>
   */
  public static abstract class SimulationServiceImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return SimulationServiceGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service SimulationService.
   * <pre>
   * Simulation API.
   * The resources managed by this API are:
   * * Scenarios, which define a system to be simulated.
   *   * Network model entities, which represent entities in a network.
   *   * Network model relationships, which represent relationships between
   *     entities in a network.
   *   * P2pSrTePolicies, which represent point-to-point SR-TE policies in the
   *     network.
   *     * P2pSrTePolicyCandidatePaths, which represent requests to establish
   *       candidate paths in service of SR-TE policies.
   *   * Downtimes, which represent downtimes of entities in the scenario.
   *   * ProtectionAssociationGroups, which indicate which paths through the
   *     network are to serve as protection to others.
   *   * DisjointAssociationGroups, which indicate which paths are to traverse
   *     disjoint paths through the network.
   * * Simulations, which represent simulations of a scenario over a time
   *   interval.
   *   * Analyses, statistical analyses of a simulation's results.
   * A simulation may be set-up, run, and analyzed via the following process:
   * 1. Create a scenario, giving the scenario a name and description.
   * 2. Define the scenario by creating the scenario's network model entities and
   *    relationships, point-to-point SR-TE policies and candidate paths,
   *    downtimes, protection association groups, and disjoint association groups.
   * 3. Create a simulation, referencing the scenario by name and specifying a
   *    time interval to be simulated. Spacetime will populate the simulation with
   *    the results of the simulation.
   * 4. Create an analysis, specifying analysis interval and granularity.
   *    Spacetime will populate the analysis with the results of the statistical
   *    analysis of the simulation results.
   * </pre>
   */
  public static final class SimulationServiceStub
      extends io.grpc.stub.AbstractAsyncStub<SimulationServiceStub> {
    private SimulationServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected SimulationServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new SimulationServiceStub(channel, callOptions);
    }

    /**
     */
    public void getScenario(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetScenarioRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetScenarioMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void listScenarios(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListScenariosMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void createScenario(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateScenarioRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateScenarioMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateScenario(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateScenarioRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateScenarioMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteScenario(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteScenarioRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteScenarioMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void copyScenario(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CopyScenarioRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCopyScenarioMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getNetworkModelEntity(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelEntityRequest request,
        io.grpc.stub.StreamObserver<org.outernetcouncil.nmts.v1.proto.Nmts.Entity> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetNetworkModelEntityMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void listNetworkModelEntities(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListNetworkModelEntitiesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void createNetworkModelEntity(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelEntityRequest request,
        io.grpc.stub.StreamObserver<org.outernetcouncil.nmts.v1.proto.Nmts.Entity> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateNetworkModelEntityMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateNetworkModelEntity(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateNetworkModelEntityRequest request,
        io.grpc.stub.StreamObserver<org.outernetcouncil.nmts.v1.proto.Nmts.Entity> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateNetworkModelEntityMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteNetworkModelEntity(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelEntityRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteNetworkModelEntityMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getNetworkModelRelationship(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelRelationshipRequest request,
        io.grpc.stub.StreamObserver<org.outernetcouncil.nmts.v1.proto.Nmts.Relationship> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetNetworkModelRelationshipMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void listNetworkModelRelationships(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListNetworkModelRelationshipsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void createNetworkModelRelationship(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelRelationshipRequest request,
        io.grpc.stub.StreamObserver<org.outernetcouncil.nmts.v1.proto.Nmts.Relationship> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateNetworkModelRelationshipMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteNetworkModelRelationship(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelRelationshipRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteNetworkModelRelationshipMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getP2pSrTePolicy(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetP2pSrTePolicyMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void listP2pSrTePolicies(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListP2pSrTePoliciesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void createP2pSrTePolicy(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateP2pSrTePolicyMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateP2pSrTePolicy(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateP2pSrTePolicyMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteP2pSrTePolicy(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteP2pSrTePolicyMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getP2pSrTePolicyCandidatePath(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyCandidatePathRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetP2pSrTePolicyCandidatePathMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void listP2pSrTePolicyCandidatePaths(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListP2pSrTePolicyCandidatePathsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void createP2pSrTePolicyCandidatePath(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyCandidatePathRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateP2pSrTePolicyCandidatePathMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateP2pSrTePolicyCandidatePath(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyCandidatePathRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateP2pSrTePolicyCandidatePathMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteP2pSrTePolicyCandidatePath(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyCandidatePathRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteP2pSrTePolicyCandidatePathMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getDowntime(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDowntimeRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetDowntimeMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void listDowntimes(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListDowntimesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void createDowntime(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDowntimeRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateDowntimeMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateDowntime(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDowntimeRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateDowntimeMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteDowntime(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDowntimeRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteDowntimeMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getProtectionAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetProtectionAssociationGroupRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetProtectionAssociationGroupMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void listProtectionAssociationGroups(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListProtectionAssociationGroupsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void createProtectionAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateProtectionAssociationGroupRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateProtectionAssociationGroupMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateProtectionAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateProtectionAssociationGroupRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateProtectionAssociationGroupMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteProtectionAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteProtectionAssociationGroupRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteProtectionAssociationGroupMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getDisjointAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDisjointAssociationGroupRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetDisjointAssociationGroupMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void listDisjointAssociationGroups(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListDisjointAssociationGroupsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void createDisjointAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDisjointAssociationGroupRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateDisjointAssociationGroupMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateDisjointAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDisjointAssociationGroupRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateDisjointAssociationGroupMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteDisjointAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDisjointAssociationGroupRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteDisjointAssociationGroupMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getSimulation(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetSimulationRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetSimulationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void listSimulations(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListSimulationsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void createSimulation(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateSimulationRequest request,
        io.grpc.stub.StreamObserver<com.google.longrunning.Operation> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateSimulationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteSimulation(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteSimulationRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteSimulationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getAnalysis(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetAnalysisRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetAnalysisMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void listAnalyses(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListAnalysesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void createAnalysis(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateAnalysisRequest request,
        io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateAnalysisMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteAnalysis(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteAnalysisRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteAnalysisMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service SimulationService.
   * <pre>
   * Simulation API.
   * The resources managed by this API are:
   * * Scenarios, which define a system to be simulated.
   *   * Network model entities, which represent entities in a network.
   *   * Network model relationships, which represent relationships between
   *     entities in a network.
   *   * P2pSrTePolicies, which represent point-to-point SR-TE policies in the
   *     network.
   *     * P2pSrTePolicyCandidatePaths, which represent requests to establish
   *       candidate paths in service of SR-TE policies.
   *   * Downtimes, which represent downtimes of entities in the scenario.
   *   * ProtectionAssociationGroups, which indicate which paths through the
   *     network are to serve as protection to others.
   *   * DisjointAssociationGroups, which indicate which paths are to traverse
   *     disjoint paths through the network.
   * * Simulations, which represent simulations of a scenario over a time
   *   interval.
   *   * Analyses, statistical analyses of a simulation's results.
   * A simulation may be set-up, run, and analyzed via the following process:
   * 1. Create a scenario, giving the scenario a name and description.
   * 2. Define the scenario by creating the scenario's network model entities and
   *    relationships, point-to-point SR-TE policies and candidate paths,
   *    downtimes, protection association groups, and disjoint association groups.
   * 3. Create a simulation, referencing the scenario by name and specifying a
   *    time interval to be simulated. Spacetime will populate the simulation with
   *    the results of the simulation.
   * 4. Create an analysis, specifying analysis interval and granularity.
   *    Spacetime will populate the analysis with the results of the statistical
   *    analysis of the simulation results.
   * </pre>
   */
  public static final class SimulationServiceBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<SimulationServiceBlockingStub> {
    private SimulationServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected SimulationServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new SimulationServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario getScenario(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetScenarioRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetScenarioMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosResponse listScenarios(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListScenariosMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario createScenario(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateScenarioRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateScenarioMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario updateScenario(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateScenarioRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateScenarioMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty deleteScenario(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteScenarioRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteScenarioMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario copyScenario(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CopyScenarioRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCopyScenarioMethod(), getCallOptions(), request);
    }

    /**
     */
    public org.outernetcouncil.nmts.v1.proto.Nmts.Entity getNetworkModelEntity(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelEntityRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetNetworkModelEntityMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesResponse listNetworkModelEntities(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListNetworkModelEntitiesMethod(), getCallOptions(), request);
    }

    /**
     */
    public org.outernetcouncil.nmts.v1.proto.Nmts.Entity createNetworkModelEntity(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelEntityRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateNetworkModelEntityMethod(), getCallOptions(), request);
    }

    /**
     */
    public org.outernetcouncil.nmts.v1.proto.Nmts.Entity updateNetworkModelEntity(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateNetworkModelEntityRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateNetworkModelEntityMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty deleteNetworkModelEntity(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelEntityRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteNetworkModelEntityMethod(), getCallOptions(), request);
    }

    /**
     */
    public org.outernetcouncil.nmts.v1.proto.Nmts.Relationship getNetworkModelRelationship(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelRelationshipRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetNetworkModelRelationshipMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsResponse listNetworkModelRelationships(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListNetworkModelRelationshipsMethod(), getCallOptions(), request);
    }

    /**
     */
    public org.outernetcouncil.nmts.v1.proto.Nmts.Relationship createNetworkModelRelationship(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelRelationshipRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateNetworkModelRelationshipMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty deleteNetworkModelRelationship(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelRelationshipRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteNetworkModelRelationshipMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy getP2pSrTePolicy(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetP2pSrTePolicyMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesResponse listP2pSrTePolicies(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListP2pSrTePoliciesMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy createP2pSrTePolicy(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateP2pSrTePolicyMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy updateP2pSrTePolicy(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateP2pSrTePolicyMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty deleteP2pSrTePolicy(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteP2pSrTePolicyMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath getP2pSrTePolicyCandidatePath(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyCandidatePathRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetP2pSrTePolicyCandidatePathMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsResponse listP2pSrTePolicyCandidatePaths(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListP2pSrTePolicyCandidatePathsMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath createP2pSrTePolicyCandidatePath(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyCandidatePathRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateP2pSrTePolicyCandidatePathMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath updateP2pSrTePolicyCandidatePath(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyCandidatePathRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateP2pSrTePolicyCandidatePathMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty deleteP2pSrTePolicyCandidatePath(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyCandidatePathRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteP2pSrTePolicyCandidatePathMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime getDowntime(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDowntimeRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetDowntimeMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesResponse listDowntimes(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListDowntimesMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime createDowntime(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDowntimeRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateDowntimeMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime updateDowntime(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDowntimeRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateDowntimeMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty deleteDowntime(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDowntimeRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteDowntimeMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup getProtectionAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetProtectionAssociationGroupRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetProtectionAssociationGroupMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsResponse listProtectionAssociationGroups(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListProtectionAssociationGroupsMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup createProtectionAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateProtectionAssociationGroupRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateProtectionAssociationGroupMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup updateProtectionAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateProtectionAssociationGroupRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateProtectionAssociationGroupMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty deleteProtectionAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteProtectionAssociationGroupRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteProtectionAssociationGroupMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup getDisjointAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDisjointAssociationGroupRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetDisjointAssociationGroupMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsResponse listDisjointAssociationGroups(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListDisjointAssociationGroupsMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup createDisjointAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDisjointAssociationGroupRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateDisjointAssociationGroupMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup updateDisjointAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDisjointAssociationGroupRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateDisjointAssociationGroupMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty deleteDisjointAssociationGroup(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDisjointAssociationGroupRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteDisjointAssociationGroupMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation getSimulation(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetSimulationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetSimulationMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsResponse listSimulations(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListSimulationsMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.longrunning.Operation createSimulation(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateSimulationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateSimulationMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty deleteSimulation(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteSimulationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteSimulationMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis getAnalysis(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetAnalysisRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetAnalysisMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesResponse listAnalyses(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListAnalysesMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis createAnalysis(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateAnalysisRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateAnalysisMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.protobuf.Empty deleteAnalysis(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteAnalysisRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteAnalysisMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service SimulationService.
   * <pre>
   * Simulation API.
   * The resources managed by this API are:
   * * Scenarios, which define a system to be simulated.
   *   * Network model entities, which represent entities in a network.
   *   * Network model relationships, which represent relationships between
   *     entities in a network.
   *   * P2pSrTePolicies, which represent point-to-point SR-TE policies in the
   *     network.
   *     * P2pSrTePolicyCandidatePaths, which represent requests to establish
   *       candidate paths in service of SR-TE policies.
   *   * Downtimes, which represent downtimes of entities in the scenario.
   *   * ProtectionAssociationGroups, which indicate which paths through the
   *     network are to serve as protection to others.
   *   * DisjointAssociationGroups, which indicate which paths are to traverse
   *     disjoint paths through the network.
   * * Simulations, which represent simulations of a scenario over a time
   *   interval.
   *   * Analyses, statistical analyses of a simulation's results.
   * A simulation may be set-up, run, and analyzed via the following process:
   * 1. Create a scenario, giving the scenario a name and description.
   * 2. Define the scenario by creating the scenario's network model entities and
   *    relationships, point-to-point SR-TE policies and candidate paths,
   *    downtimes, protection association groups, and disjoint association groups.
   * 3. Create a simulation, referencing the scenario by name and specifying a
   *    time interval to be simulated. Spacetime will populate the simulation with
   *    the results of the simulation.
   * 4. Create an analysis, specifying analysis interval and granularity.
   *    Spacetime will populate the analysis with the results of the statistical
   *    analysis of the simulation results.
   * </pre>
   */
  public static final class SimulationServiceFutureStub
      extends io.grpc.stub.AbstractFutureStub<SimulationServiceFutureStub> {
    private SimulationServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected SimulationServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new SimulationServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> getScenario(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetScenarioRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetScenarioMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosResponse> listScenarios(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListScenariosMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> createScenario(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateScenarioRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateScenarioMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> updateScenario(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateScenarioRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateScenarioMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> deleteScenario(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteScenarioRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteScenarioMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> copyScenario(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CopyScenarioRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCopyScenarioMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<org.outernetcouncil.nmts.v1.proto.Nmts.Entity> getNetworkModelEntity(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelEntityRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetNetworkModelEntityMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesResponse> listNetworkModelEntities(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListNetworkModelEntitiesMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<org.outernetcouncil.nmts.v1.proto.Nmts.Entity> createNetworkModelEntity(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelEntityRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateNetworkModelEntityMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<org.outernetcouncil.nmts.v1.proto.Nmts.Entity> updateNetworkModelEntity(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateNetworkModelEntityRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateNetworkModelEntityMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> deleteNetworkModelEntity(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelEntityRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteNetworkModelEntityMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<org.outernetcouncil.nmts.v1.proto.Nmts.Relationship> getNetworkModelRelationship(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelRelationshipRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetNetworkModelRelationshipMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsResponse> listNetworkModelRelationships(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListNetworkModelRelationshipsMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<org.outernetcouncil.nmts.v1.proto.Nmts.Relationship> createNetworkModelRelationship(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelRelationshipRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateNetworkModelRelationshipMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> deleteNetworkModelRelationship(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelRelationshipRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteNetworkModelRelationshipMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy> getP2pSrTePolicy(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetP2pSrTePolicyMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesResponse> listP2pSrTePolicies(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListP2pSrTePoliciesMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy> createP2pSrTePolicy(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateP2pSrTePolicyMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy> updateP2pSrTePolicy(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateP2pSrTePolicyMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> deleteP2pSrTePolicy(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteP2pSrTePolicyMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath> getP2pSrTePolicyCandidatePath(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyCandidatePathRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetP2pSrTePolicyCandidatePathMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsResponse> listP2pSrTePolicyCandidatePaths(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListP2pSrTePolicyCandidatePathsMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath> createP2pSrTePolicyCandidatePath(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyCandidatePathRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateP2pSrTePolicyCandidatePathMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath> updateP2pSrTePolicyCandidatePath(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyCandidatePathRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateP2pSrTePolicyCandidatePathMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> deleteP2pSrTePolicyCandidatePath(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyCandidatePathRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteP2pSrTePolicyCandidatePathMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime> getDowntime(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDowntimeRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetDowntimeMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesResponse> listDowntimes(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListDowntimesMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime> createDowntime(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDowntimeRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateDowntimeMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime> updateDowntime(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDowntimeRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateDowntimeMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> deleteDowntime(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDowntimeRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteDowntimeMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup> getProtectionAssociationGroup(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetProtectionAssociationGroupRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetProtectionAssociationGroupMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsResponse> listProtectionAssociationGroups(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListProtectionAssociationGroupsMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup> createProtectionAssociationGroup(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateProtectionAssociationGroupRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateProtectionAssociationGroupMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup> updateProtectionAssociationGroup(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateProtectionAssociationGroupRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateProtectionAssociationGroupMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> deleteProtectionAssociationGroup(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteProtectionAssociationGroupRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteProtectionAssociationGroupMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup> getDisjointAssociationGroup(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDisjointAssociationGroupRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetDisjointAssociationGroupMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsResponse> listDisjointAssociationGroups(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListDisjointAssociationGroupsMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup> createDisjointAssociationGroup(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDisjointAssociationGroupRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateDisjointAssociationGroupMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup> updateDisjointAssociationGroup(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDisjointAssociationGroupRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateDisjointAssociationGroupMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> deleteDisjointAssociationGroup(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDisjointAssociationGroupRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteDisjointAssociationGroupMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation> getSimulation(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetSimulationRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetSimulationMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsResponse> listSimulations(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListSimulationsMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.longrunning.Operation> createSimulation(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateSimulationRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateSimulationMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> deleteSimulation(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteSimulationRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteSimulationMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis> getAnalysis(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetAnalysisRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetAnalysisMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesResponse> listAnalyses(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListAnalysesMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis> createAnalysis(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateAnalysisRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateAnalysisMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> deleteAnalysis(
        com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteAnalysisRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteAnalysisMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_GET_SCENARIO = 0;
  private static final int METHODID_LIST_SCENARIOS = 1;
  private static final int METHODID_CREATE_SCENARIO = 2;
  private static final int METHODID_UPDATE_SCENARIO = 3;
  private static final int METHODID_DELETE_SCENARIO = 4;
  private static final int METHODID_COPY_SCENARIO = 5;
  private static final int METHODID_GET_NETWORK_MODEL_ENTITY = 6;
  private static final int METHODID_LIST_NETWORK_MODEL_ENTITIES = 7;
  private static final int METHODID_CREATE_NETWORK_MODEL_ENTITY = 8;
  private static final int METHODID_UPDATE_NETWORK_MODEL_ENTITY = 9;
  private static final int METHODID_DELETE_NETWORK_MODEL_ENTITY = 10;
  private static final int METHODID_GET_NETWORK_MODEL_RELATIONSHIP = 11;
  private static final int METHODID_LIST_NETWORK_MODEL_RELATIONSHIPS = 12;
  private static final int METHODID_CREATE_NETWORK_MODEL_RELATIONSHIP = 13;
  private static final int METHODID_DELETE_NETWORK_MODEL_RELATIONSHIP = 14;
  private static final int METHODID_GET_P2P_SR_TE_POLICY = 15;
  private static final int METHODID_LIST_P2P_SR_TE_POLICIES = 16;
  private static final int METHODID_CREATE_P2P_SR_TE_POLICY = 17;
  private static final int METHODID_UPDATE_P2P_SR_TE_POLICY = 18;
  private static final int METHODID_DELETE_P2P_SR_TE_POLICY = 19;
  private static final int METHODID_GET_P2P_SR_TE_POLICY_CANDIDATE_PATH = 20;
  private static final int METHODID_LIST_P2P_SR_TE_POLICY_CANDIDATE_PATHS = 21;
  private static final int METHODID_CREATE_P2P_SR_TE_POLICY_CANDIDATE_PATH = 22;
  private static final int METHODID_UPDATE_P2P_SR_TE_POLICY_CANDIDATE_PATH = 23;
  private static final int METHODID_DELETE_P2P_SR_TE_POLICY_CANDIDATE_PATH = 24;
  private static final int METHODID_GET_DOWNTIME = 25;
  private static final int METHODID_LIST_DOWNTIMES = 26;
  private static final int METHODID_CREATE_DOWNTIME = 27;
  private static final int METHODID_UPDATE_DOWNTIME = 28;
  private static final int METHODID_DELETE_DOWNTIME = 29;
  private static final int METHODID_GET_PROTECTION_ASSOCIATION_GROUP = 30;
  private static final int METHODID_LIST_PROTECTION_ASSOCIATION_GROUPS = 31;
  private static final int METHODID_CREATE_PROTECTION_ASSOCIATION_GROUP = 32;
  private static final int METHODID_UPDATE_PROTECTION_ASSOCIATION_GROUP = 33;
  private static final int METHODID_DELETE_PROTECTION_ASSOCIATION_GROUP = 34;
  private static final int METHODID_GET_DISJOINT_ASSOCIATION_GROUP = 35;
  private static final int METHODID_LIST_DISJOINT_ASSOCIATION_GROUPS = 36;
  private static final int METHODID_CREATE_DISJOINT_ASSOCIATION_GROUP = 37;
  private static final int METHODID_UPDATE_DISJOINT_ASSOCIATION_GROUP = 38;
  private static final int METHODID_DELETE_DISJOINT_ASSOCIATION_GROUP = 39;
  private static final int METHODID_GET_SIMULATION = 40;
  private static final int METHODID_LIST_SIMULATIONS = 41;
  private static final int METHODID_CREATE_SIMULATION = 42;
  private static final int METHODID_DELETE_SIMULATION = 43;
  private static final int METHODID_GET_ANALYSIS = 44;
  private static final int METHODID_LIST_ANALYSES = 45;
  private static final int METHODID_CREATE_ANALYSIS = 46;
  private static final int METHODID_DELETE_ANALYSIS = 47;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_GET_SCENARIO:
          serviceImpl.getScenario((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetScenarioRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario>) responseObserver);
          break;
        case METHODID_LIST_SCENARIOS:
          serviceImpl.listScenarios((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosResponse>) responseObserver);
          break;
        case METHODID_CREATE_SCENARIO:
          serviceImpl.createScenario((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateScenarioRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario>) responseObserver);
          break;
        case METHODID_UPDATE_SCENARIO:
          serviceImpl.updateScenario((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateScenarioRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario>) responseObserver);
          break;
        case METHODID_DELETE_SCENARIO:
          serviceImpl.deleteScenario((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteScenarioRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_COPY_SCENARIO:
          serviceImpl.copyScenario((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CopyScenarioRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario>) responseObserver);
          break;
        case METHODID_GET_NETWORK_MODEL_ENTITY:
          serviceImpl.getNetworkModelEntity((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelEntityRequest) request,
              (io.grpc.stub.StreamObserver<org.outernetcouncil.nmts.v1.proto.Nmts.Entity>) responseObserver);
          break;
        case METHODID_LIST_NETWORK_MODEL_ENTITIES:
          serviceImpl.listNetworkModelEntities((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesResponse>) responseObserver);
          break;
        case METHODID_CREATE_NETWORK_MODEL_ENTITY:
          serviceImpl.createNetworkModelEntity((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelEntityRequest) request,
              (io.grpc.stub.StreamObserver<org.outernetcouncil.nmts.v1.proto.Nmts.Entity>) responseObserver);
          break;
        case METHODID_UPDATE_NETWORK_MODEL_ENTITY:
          serviceImpl.updateNetworkModelEntity((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateNetworkModelEntityRequest) request,
              (io.grpc.stub.StreamObserver<org.outernetcouncil.nmts.v1.proto.Nmts.Entity>) responseObserver);
          break;
        case METHODID_DELETE_NETWORK_MODEL_ENTITY:
          serviceImpl.deleteNetworkModelEntity((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelEntityRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_GET_NETWORK_MODEL_RELATIONSHIP:
          serviceImpl.getNetworkModelRelationship((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelRelationshipRequest) request,
              (io.grpc.stub.StreamObserver<org.outernetcouncil.nmts.v1.proto.Nmts.Relationship>) responseObserver);
          break;
        case METHODID_LIST_NETWORK_MODEL_RELATIONSHIPS:
          serviceImpl.listNetworkModelRelationships((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsResponse>) responseObserver);
          break;
        case METHODID_CREATE_NETWORK_MODEL_RELATIONSHIP:
          serviceImpl.createNetworkModelRelationship((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelRelationshipRequest) request,
              (io.grpc.stub.StreamObserver<org.outernetcouncil.nmts.v1.proto.Nmts.Relationship>) responseObserver);
          break;
        case METHODID_DELETE_NETWORK_MODEL_RELATIONSHIP:
          serviceImpl.deleteNetworkModelRelationship((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelRelationshipRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_GET_P2P_SR_TE_POLICY:
          serviceImpl.getP2pSrTePolicy((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy>) responseObserver);
          break;
        case METHODID_LIST_P2P_SR_TE_POLICIES:
          serviceImpl.listP2pSrTePolicies((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesResponse>) responseObserver);
          break;
        case METHODID_CREATE_P2P_SR_TE_POLICY:
          serviceImpl.createP2pSrTePolicy((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy>) responseObserver);
          break;
        case METHODID_UPDATE_P2P_SR_TE_POLICY:
          serviceImpl.updateP2pSrTePolicy((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy>) responseObserver);
          break;
        case METHODID_DELETE_P2P_SR_TE_POLICY:
          serviceImpl.deleteP2pSrTePolicy((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_GET_P2P_SR_TE_POLICY_CANDIDATE_PATH:
          serviceImpl.getP2pSrTePolicyCandidatePath((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyCandidatePathRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath>) responseObserver);
          break;
        case METHODID_LIST_P2P_SR_TE_POLICY_CANDIDATE_PATHS:
          serviceImpl.listP2pSrTePolicyCandidatePaths((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsResponse>) responseObserver);
          break;
        case METHODID_CREATE_P2P_SR_TE_POLICY_CANDIDATE_PATH:
          serviceImpl.createP2pSrTePolicyCandidatePath((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyCandidatePathRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath>) responseObserver);
          break;
        case METHODID_UPDATE_P2P_SR_TE_POLICY_CANDIDATE_PATH:
          serviceImpl.updateP2pSrTePolicyCandidatePath((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyCandidatePathRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath>) responseObserver);
          break;
        case METHODID_DELETE_P2P_SR_TE_POLICY_CANDIDATE_PATH:
          serviceImpl.deleteP2pSrTePolicyCandidatePath((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyCandidatePathRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_GET_DOWNTIME:
          serviceImpl.getDowntime((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDowntimeRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime>) responseObserver);
          break;
        case METHODID_LIST_DOWNTIMES:
          serviceImpl.listDowntimes((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesResponse>) responseObserver);
          break;
        case METHODID_CREATE_DOWNTIME:
          serviceImpl.createDowntime((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDowntimeRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime>) responseObserver);
          break;
        case METHODID_UPDATE_DOWNTIME:
          serviceImpl.updateDowntime((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDowntimeRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime>) responseObserver);
          break;
        case METHODID_DELETE_DOWNTIME:
          serviceImpl.deleteDowntime((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDowntimeRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_GET_PROTECTION_ASSOCIATION_GROUP:
          serviceImpl.getProtectionAssociationGroup((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetProtectionAssociationGroupRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup>) responseObserver);
          break;
        case METHODID_LIST_PROTECTION_ASSOCIATION_GROUPS:
          serviceImpl.listProtectionAssociationGroups((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsResponse>) responseObserver);
          break;
        case METHODID_CREATE_PROTECTION_ASSOCIATION_GROUP:
          serviceImpl.createProtectionAssociationGroup((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateProtectionAssociationGroupRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup>) responseObserver);
          break;
        case METHODID_UPDATE_PROTECTION_ASSOCIATION_GROUP:
          serviceImpl.updateProtectionAssociationGroup((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateProtectionAssociationGroupRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup>) responseObserver);
          break;
        case METHODID_DELETE_PROTECTION_ASSOCIATION_GROUP:
          serviceImpl.deleteProtectionAssociationGroup((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteProtectionAssociationGroupRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_GET_DISJOINT_ASSOCIATION_GROUP:
          serviceImpl.getDisjointAssociationGroup((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDisjointAssociationGroupRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup>) responseObserver);
          break;
        case METHODID_LIST_DISJOINT_ASSOCIATION_GROUPS:
          serviceImpl.listDisjointAssociationGroups((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsResponse>) responseObserver);
          break;
        case METHODID_CREATE_DISJOINT_ASSOCIATION_GROUP:
          serviceImpl.createDisjointAssociationGroup((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDisjointAssociationGroupRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup>) responseObserver);
          break;
        case METHODID_UPDATE_DISJOINT_ASSOCIATION_GROUP:
          serviceImpl.updateDisjointAssociationGroup((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDisjointAssociationGroupRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup>) responseObserver);
          break;
        case METHODID_DELETE_DISJOINT_ASSOCIATION_GROUP:
          serviceImpl.deleteDisjointAssociationGroup((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDisjointAssociationGroupRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_GET_SIMULATION:
          serviceImpl.getSimulation((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetSimulationRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation>) responseObserver);
          break;
        case METHODID_LIST_SIMULATIONS:
          serviceImpl.listSimulations((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsResponse>) responseObserver);
          break;
        case METHODID_CREATE_SIMULATION:
          serviceImpl.createSimulation((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateSimulationRequest) request,
              (io.grpc.stub.StreamObserver<com.google.longrunning.Operation>) responseObserver);
          break;
        case METHODID_DELETE_SIMULATION:
          serviceImpl.deleteSimulation((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteSimulationRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_GET_ANALYSIS:
          serviceImpl.getAnalysis((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetAnalysisRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis>) responseObserver);
          break;
        case METHODID_LIST_ANALYSES:
          serviceImpl.listAnalyses((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesResponse>) responseObserver);
          break;
        case METHODID_CREATE_ANALYSIS:
          serviceImpl.createAnalysis((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateAnalysisRequest) request,
              (io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis>) responseObserver);
          break;
        case METHODID_DELETE_ANALYSIS:
          serviceImpl.deleteAnalysis((com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteAnalysisRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getGetScenarioMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetScenarioRequest,
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario>(
                service, METHODID_GET_SCENARIO)))
        .addMethod(
          getListScenariosMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosRequest,
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosResponse>(
                service, METHODID_LIST_SCENARIOS)))
        .addMethod(
          getCreateScenarioMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateScenarioRequest,
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario>(
                service, METHODID_CREATE_SCENARIO)))
        .addMethod(
          getUpdateScenarioMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateScenarioRequest,
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario>(
                service, METHODID_UPDATE_SCENARIO)))
        .addMethod(
          getDeleteScenarioMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteScenarioRequest,
              com.google.protobuf.Empty>(
                service, METHODID_DELETE_SCENARIO)))
        .addMethod(
          getCopyScenarioMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CopyScenarioRequest,
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario>(
                service, METHODID_COPY_SCENARIO)))
        .addMethod(
          getGetNetworkModelEntityMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelEntityRequest,
              org.outernetcouncil.nmts.v1.proto.Nmts.Entity>(
                service, METHODID_GET_NETWORK_MODEL_ENTITY)))
        .addMethod(
          getListNetworkModelEntitiesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesRequest,
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelEntitiesResponse>(
                service, METHODID_LIST_NETWORK_MODEL_ENTITIES)))
        .addMethod(
          getCreateNetworkModelEntityMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelEntityRequest,
              org.outernetcouncil.nmts.v1.proto.Nmts.Entity>(
                service, METHODID_CREATE_NETWORK_MODEL_ENTITY)))
        .addMethod(
          getUpdateNetworkModelEntityMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateNetworkModelEntityRequest,
              org.outernetcouncil.nmts.v1.proto.Nmts.Entity>(
                service, METHODID_UPDATE_NETWORK_MODEL_ENTITY)))
        .addMethod(
          getDeleteNetworkModelEntityMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelEntityRequest,
              com.google.protobuf.Empty>(
                service, METHODID_DELETE_NETWORK_MODEL_ENTITY)))
        .addMethod(
          getGetNetworkModelRelationshipMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetNetworkModelRelationshipRequest,
              org.outernetcouncil.nmts.v1.proto.Nmts.Relationship>(
                service, METHODID_GET_NETWORK_MODEL_RELATIONSHIP)))
        .addMethod(
          getListNetworkModelRelationshipsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsRequest,
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListNetworkModelRelationshipsResponse>(
                service, METHODID_LIST_NETWORK_MODEL_RELATIONSHIPS)))
        .addMethod(
          getCreateNetworkModelRelationshipMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateNetworkModelRelationshipRequest,
              org.outernetcouncil.nmts.v1.proto.Nmts.Relationship>(
                service, METHODID_CREATE_NETWORK_MODEL_RELATIONSHIP)))
        .addMethod(
          getDeleteNetworkModelRelationshipMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteNetworkModelRelationshipRequest,
              com.google.protobuf.Empty>(
                service, METHODID_DELETE_NETWORK_MODEL_RELATIONSHIP)))
        .addMethod(
          getGetP2pSrTePolicyMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyRequest,
              com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy>(
                service, METHODID_GET_P2P_SR_TE_POLICY)))
        .addMethod(
          getListP2pSrTePoliciesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesRequest,
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePoliciesResponse>(
                service, METHODID_LIST_P2P_SR_TE_POLICIES)))
        .addMethod(
          getCreateP2pSrTePolicyMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyRequest,
              com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy>(
                service, METHODID_CREATE_P2P_SR_TE_POLICY)))
        .addMethod(
          getUpdateP2pSrTePolicyMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyRequest,
              com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicy>(
                service, METHODID_UPDATE_P2P_SR_TE_POLICY)))
        .addMethod(
          getDeleteP2pSrTePolicyMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyRequest,
              com.google.protobuf.Empty>(
                service, METHODID_DELETE_P2P_SR_TE_POLICY)))
        .addMethod(
          getGetP2pSrTePolicyCandidatePathMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetP2pSrTePolicyCandidatePathRequest,
              com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath>(
                service, METHODID_GET_P2P_SR_TE_POLICY_CANDIDATE_PATH)))
        .addMethod(
          getListP2pSrTePolicyCandidatePathsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsRequest,
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListP2pSrTePolicyCandidatePathsResponse>(
                service, METHODID_LIST_P2P_SR_TE_POLICY_CANDIDATE_PATHS)))
        .addMethod(
          getCreateP2pSrTePolicyCandidatePathMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateP2pSrTePolicyCandidatePathRequest,
              com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath>(
                service, METHODID_CREATE_P2P_SR_TE_POLICY_CANDIDATE_PATH)))
        .addMethod(
          getUpdateP2pSrTePolicyCandidatePathMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateP2pSrTePolicyCandidatePathRequest,
              com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath>(
                service, METHODID_UPDATE_P2P_SR_TE_POLICY_CANDIDATE_PATH)))
        .addMethod(
          getDeleteP2pSrTePolicyCandidatePathMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteP2pSrTePolicyCandidatePathRequest,
              com.google.protobuf.Empty>(
                service, METHODID_DELETE_P2P_SR_TE_POLICY_CANDIDATE_PATH)))
        .addMethod(
          getGetDowntimeMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDowntimeRequest,
              com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime>(
                service, METHODID_GET_DOWNTIME)))
        .addMethod(
          getListDowntimesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesRequest,
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDowntimesResponse>(
                service, METHODID_LIST_DOWNTIMES)))
        .addMethod(
          getCreateDowntimeMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDowntimeRequest,
              com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime>(
                service, METHODID_CREATE_DOWNTIME)))
        .addMethod(
          getUpdateDowntimeMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDowntimeRequest,
              com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.Downtime>(
                service, METHODID_UPDATE_DOWNTIME)))
        .addMethod(
          getDeleteDowntimeMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDowntimeRequest,
              com.google.protobuf.Empty>(
                service, METHODID_DELETE_DOWNTIME)))
        .addMethod(
          getGetProtectionAssociationGroupMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetProtectionAssociationGroupRequest,
              com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup>(
                service, METHODID_GET_PROTECTION_ASSOCIATION_GROUP)))
        .addMethod(
          getListProtectionAssociationGroupsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsRequest,
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListProtectionAssociationGroupsResponse>(
                service, METHODID_LIST_PROTECTION_ASSOCIATION_GROUPS)))
        .addMethod(
          getCreateProtectionAssociationGroupMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateProtectionAssociationGroupRequest,
              com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup>(
                service, METHODID_CREATE_PROTECTION_ASSOCIATION_GROUP)))
        .addMethod(
          getUpdateProtectionAssociationGroupMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateProtectionAssociationGroupRequest,
              com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.ProtectionAssociationGroup>(
                service, METHODID_UPDATE_PROTECTION_ASSOCIATION_GROUP)))
        .addMethod(
          getDeleteProtectionAssociationGroupMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteProtectionAssociationGroupRequest,
              com.google.protobuf.Empty>(
                service, METHODID_DELETE_PROTECTION_ASSOCIATION_GROUP)))
        .addMethod(
          getGetDisjointAssociationGroupMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetDisjointAssociationGroupRequest,
              com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup>(
                service, METHODID_GET_DISJOINT_ASSOCIATION_GROUP)))
        .addMethod(
          getListDisjointAssociationGroupsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsRequest,
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListDisjointAssociationGroupsResponse>(
                service, METHODID_LIST_DISJOINT_ASSOCIATION_GROUPS)))
        .addMethod(
          getCreateDisjointAssociationGroupMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateDisjointAssociationGroupRequest,
              com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup>(
                service, METHODID_CREATE_DISJOINT_ASSOCIATION_GROUP)))
        .addMethod(
          getUpdateDisjointAssociationGroupMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.UpdateDisjointAssociationGroupRequest,
              com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.DisjointAssociationGroup>(
                service, METHODID_UPDATE_DISJOINT_ASSOCIATION_GROUP)))
        .addMethod(
          getDeleteDisjointAssociationGroupMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteDisjointAssociationGroupRequest,
              com.google.protobuf.Empty>(
                service, METHODID_DELETE_DISJOINT_ASSOCIATION_GROUP)))
        .addMethod(
          getGetSimulationMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetSimulationRequest,
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation>(
                service, METHODID_GET_SIMULATION)))
        .addMethod(
          getListSimulationsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsRequest,
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsResponse>(
                service, METHODID_LIST_SIMULATIONS)))
        .addMethod(
          getCreateSimulationMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateSimulationRequest,
              com.google.longrunning.Operation>(
                service, METHODID_CREATE_SIMULATION)))
        .addMethod(
          getDeleteSimulationMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteSimulationRequest,
              com.google.protobuf.Empty>(
                service, METHODID_DELETE_SIMULATION)))
        .addMethod(
          getGetAnalysisMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetAnalysisRequest,
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis>(
                service, METHODID_GET_ANALYSIS)))
        .addMethod(
          getListAnalysesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesRequest,
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListAnalysesResponse>(
                service, METHODID_LIST_ANALYSES)))
        .addMethod(
          getCreateAnalysisMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateAnalysisRequest,
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis>(
                service, METHODID_CREATE_ANALYSIS)))
        .addMethod(
          getDeleteAnalysisMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteAnalysisRequest,
              com.google.protobuf.Empty>(
                service, METHODID_DELETE_ANALYSIS)))
        .build();
  }

  private static abstract class SimulationServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    SimulationServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("SimulationService");
    }
  }

  private static final class SimulationServiceFileDescriptorSupplier
      extends SimulationServiceBaseDescriptorSupplier {
    SimulationServiceFileDescriptorSupplier() {}
  }

  private static final class SimulationServiceMethodDescriptorSupplier
      extends SimulationServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    SimulationServiceMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (SimulationServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new SimulationServiceFileDescriptorSupplier())
              .addMethod(getGetScenarioMethod())
              .addMethod(getListScenariosMethod())
              .addMethod(getCreateScenarioMethod())
              .addMethod(getUpdateScenarioMethod())
              .addMethod(getDeleteScenarioMethod())
              .addMethod(getCopyScenarioMethod())
              .addMethod(getGetNetworkModelEntityMethod())
              .addMethod(getListNetworkModelEntitiesMethod())
              .addMethod(getCreateNetworkModelEntityMethod())
              .addMethod(getUpdateNetworkModelEntityMethod())
              .addMethod(getDeleteNetworkModelEntityMethod())
              .addMethod(getGetNetworkModelRelationshipMethod())
              .addMethod(getListNetworkModelRelationshipsMethod())
              .addMethod(getCreateNetworkModelRelationshipMethod())
              .addMethod(getDeleteNetworkModelRelationshipMethod())
              .addMethod(getGetP2pSrTePolicyMethod())
              .addMethod(getListP2pSrTePoliciesMethod())
              .addMethod(getCreateP2pSrTePolicyMethod())
              .addMethod(getUpdateP2pSrTePolicyMethod())
              .addMethod(getDeleteP2pSrTePolicyMethod())
              .addMethod(getGetP2pSrTePolicyCandidatePathMethod())
              .addMethod(getListP2pSrTePolicyCandidatePathsMethod())
              .addMethod(getCreateP2pSrTePolicyCandidatePathMethod())
              .addMethod(getUpdateP2pSrTePolicyCandidatePathMethod())
              .addMethod(getDeleteP2pSrTePolicyCandidatePathMethod())
              .addMethod(getGetDowntimeMethod())
              .addMethod(getListDowntimesMethod())
              .addMethod(getCreateDowntimeMethod())
              .addMethod(getUpdateDowntimeMethod())
              .addMethod(getDeleteDowntimeMethod())
              .addMethod(getGetProtectionAssociationGroupMethod())
              .addMethod(getListProtectionAssociationGroupsMethod())
              .addMethod(getCreateProtectionAssociationGroupMethod())
              .addMethod(getUpdateProtectionAssociationGroupMethod())
              .addMethod(getDeleteProtectionAssociationGroupMethod())
              .addMethod(getGetDisjointAssociationGroupMethod())
              .addMethod(getListDisjointAssociationGroupsMethod())
              .addMethod(getCreateDisjointAssociationGroupMethod())
              .addMethod(getUpdateDisjointAssociationGroupMethod())
              .addMethod(getDeleteDisjointAssociationGroupMethod())
              .addMethod(getGetSimulationMethod())
              .addMethod(getListSimulationsMethod())
              .addMethod(getCreateSimulationMethod())
              .addMethod(getDeleteSimulationMethod())
              .addMethod(getGetAnalysisMethod())
              .addMethod(getListAnalysesMethod())
              .addMethod(getCreateAnalysisMethod())
              .addMethod(getDeleteAnalysisMethod())
              .build();
        }
      }
    }
    return result;
  }
}
