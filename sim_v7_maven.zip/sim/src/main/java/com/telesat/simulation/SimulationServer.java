package com.telesat.simulation;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.HashMap;
import java.time.Instant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.inprocess.InProcessServerBuilder;

import com.aalyria.spacetime.simulation.v1alpha.SimulationServiceGrpc;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

class SimulationServer
{
    //public static final int DATA_COLLECTION_INTERVAL_MS = 10;

    private static final Logger logger = LoggerFactory.getLogger(SimulationServer.class);
    
    private Server server;
    private final int port;

    private SimulationServerConfiguration config;

    /* NOTE: The meaning and usage of 'scenarioId' is not clear at API definition. 
     *       For example, while creation and copy requests are based on 'scenario_id'
     *       information, get, update and delete requests are based on 'name'.
     *       So, we created two map for both possible key types. 
     */
    private HashMap<String, ScenarioDelegation> scenariosForId = new HashMap<>();
    private HashMap<String, ScenarioDelegation> scenariosForName = new HashMap<>();

    /* NOTE: Simulations are stored as server-based while they could be scenario based.
             It is because, for examle GetSimulation service provides only simulation name
             while no scenario name is included
     */
    private HashMap<String, SimulationDelegation> simulationsForId = new HashMap<>();
    private HashMap<String, SimulationDelegation> simulationsForName = new HashMap<>();

    /* NOTE: Analyses are stored as server based while it could be scenario and/or simulation based.
             Each Analysis instance has scenario-name as a parent and during the creation it
             is connected to a simulation. 'analysis-id' is provided during creation but not used
             by other operations. 'name' is included in Analysis object as consisting scenario
             (scenarios/{scenario}/analyses/{analysis}). 
             So, for now we consider two maps for 'analysis-id' and 'name' keys.
    */
    private HashMap<String, AnalysisDelegation> analysesForId = new HashMap<>();
    private HashMap<String, AnalysisDelegation> analysesForName = new HashMap<>();

    private final ScheduledExecutorService executor = Executors.newScheduledThreadPool(2);

    public SimulationServer(int port) {
        this.port = port;
    }

    public SimulationOuterClass.Scenario getScenarioForId(String scenarioId) {
        ScenarioDelegation sc = this.scenariosForId.get(scenarioId);
        return (sc == null) ? null : sc.getScenario();
    }

    public SimulationOuterClass.Scenario getScenarioForName(String scenarioName) {
        ScenarioDelegation sc = this.scenariosForName.get(scenarioName);
        return (sc == null) ? null : sc.getScenario();
    }

    public void setScenario(String scenarioId, SimulationOuterClass.Scenario scenario) {
        ScenarioDelegation sc = new ScenarioDelegation(scenarioId, scenario);
        this.scenariosForId.put(scenarioId, sc);
        this.scenariosForName.put(scenario.getName(), sc);
    }

    public SimulationOuterClass.Simulation getSimulationForId(String simulationId) {
        SimulationDelegation simd = this.simulationsForId.get(simulationId);
        return (simd == null) ? null : simd.getSimulation(); 
    }

    public SimulationOuterClass.Simulation getSimulationForName(String simulationName) {
        SimulationDelegation simd = this.simulationsForName.get(simulationName);
        return (simd == null) ? null : simd.getSimulation(); 
    }

    void setSimulation(String simulationId, SimulationOuterClass.Simulation simulation) {
        SimulationDelegation simd = this.simulationsForId.get(simulationId);

        if (simd == null) {
            simd = new SimulationDelegation(simulationId, simulation);
            this.simulationsForId.put(simulationId, simd);
        } else {
            simd.setSimulation(simulation);
        }

        String fsimname = simulation.getName();
        String[] parts = fsimname.split("/");
        String simname = parts[parts.length - 1];

        this.simulationsForName.put(simname, simd);
    }


    public SimulationOuterClass.Analysis getAnalysisForId(String analysisId) {
        AnalysisDelegation adel = this.analysesForId.get(analysisId);
        return (adel == null) ? null : adel.getAnalysis();
    }

    public SimulationOuterClass.Analysis getAnalysisForName(String name) {
        AnalysisDelegation adel = this.analysesForName.get(name);
        return (adel == null) ? null : adel.getAnalysis();
    }

    /* Returns the reference of delegated Analysis instance which could be rebuilt from provided 'analysis' instance 
       as including obtained 'AnalysisSegment' list. */
    public SimulationOuterClass.Analysis setAnalysis(String parent, String analysisId, SimulationOuterClass.Analysis analysis) {

        String fsimname = parent;
        String[] parts = fsimname.split("/");
        if (parts.length > 2) {
            logger.info("setAnalysis: Name format of analysis parent is possibly unexpected: '{}'", fsimname);
        }
        String parentSimulation = parts[parts.length - 1];
        //AnalysisDelegation del = new AnalysisDelegation(parentSimulation, analysisId, analysis, SimulationServer.logger);
        AnalysisDelegation del = new AnalysisDelegation(parentSimulation, analysisId, analysis, this.config, SimulationServer.logger);
        this.analysesForId.put(analysisId, del);

        /* name is the resource name of the analysis. Its format: scenarios/{scenario}/analyses/{analysis}. */
        String faname = analysis.getName();
        parts = faname.split("/");
        if (parts.length > 4) {
            logger.info("setAnalysis: Name format of analysis is possibly unexpected: '{}'", faname);
        }
        /* We do not use 'scenario' at the moment */
        String aname = parts[parts.length - 1];
        this.analysesForName.put(aname, del);

        return del.getAnalysis();
    }
    
    /**
     * Start the gRPC server
     */
    public void start() throws IOException {
        server = ServerBuilder.forPort(port)
                .addService(new SimulationServiceImpl(this))
                .build()
                .start();
        
        logger.info("Simulation server started, listening on port {}", port);
        
        // Add shutdown hook
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            logger.info("Shutting down gRPC server...");
            try {
                SimulationServer.this.stop();
            } 
            catch (InterruptedException e) {
                logger.error("Error shutting down server", e);
                Thread.currentThread().interrupt();
            }
        }));
    }

    /**
     * Start the server in-process (no TCP port). Useful for tests and local runs.
     */
    public void startInProcess(String inProcessName) throws IOException {
        server = InProcessServerBuilder.forName(inProcessName)
                .directExecutor()
                .addService(new SimulationServiceImpl(this))
                .build()
                .start();

        logger.info("Simulation in-process server started with name '{}'", inProcessName);

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            logger.info("Shutting down in-process gRPC server...");
            try {
                SimulationServer.this.stop();
            } catch (InterruptedException e) {
                logger.error("Error shutting down in-process server", e);
                Thread.currentThread().interrupt();
            }
        }));
    }

    /**
     * Stop the gRPC server
     */
    public void stop() throws InterruptedException {
        if (server != null) {
            server.shutdown().awaitTermination(30, TimeUnit.SECONDS);
        }
    }
    
    /**
     * Block until the server is terminated
     */
    public void blockUntilShutdown() throws InterruptedException {
        if (server != null) {
            server.awaitTermination();
        }
    }


    /**
     * Implementation of the SimulationService
     */
    static class SimulationServiceImpl extends SimulationServiceGrpc.SimulationServiceImplBase {

        SimulationServiceImpl(SimulationServer server) {
            this.server = server;
        }

        private SimulationServer server;
        private static final Logger logger = LoggerFactory.getLogger(SimulationServiceImpl.class);

        @Override
        public void createScenario(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateScenarioRequest request,
                                   io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> responseObserver) 
        {
            // Receiver create-scenario request. Extract the information from the request for appropriate action
            String scenarioId = request.getScenarioId();
            logger.info("Received CreateScenarioRequest for id: '{}' and name: '{}' with description: '{}'", 
                         scenarioId, request.getScenario().getName(), request.getScenario().getDescription());

            SimulationOuterClass.Scenario sc = server.getScenarioForId(scenarioId);
            if (sc != null) {
                logger.warn("There is already created scenario with id '{}'", scenarioId);
                // NOTE: No definition for error cases, we just return a Scenario message with empty 'name' to indicate the problem
                // TODO: Another approach might be applied to return found scenario
                SimulationOuterClass.Scenario response = SimulationOuterClass.Scenario.newBuilder()
                                                                                      .setName("")
                                                                                      .build();
                responseObserver.onNext(response);
                responseObserver.onCompleted();                               
                return;
            }
            /* No previously created scenario is found. Create new one. It is also be our response
             * Note that originator determines the scenario name and description, so we may copy as received
             */

            SimulationOuterClass.Scenario response = SimulationOuterClass.Scenario.newBuilder(request.getScenario())
                                                                                  .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();                               
            
            /* Save into server's map */
            server.setScenario(scenarioId, response);
            logger.info("Sent success response for scenario with id: '{}' and name: '{}'", scenarioId, response.getName());
        }

        @Override
        public void getScenario(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetScenarioRequest request,
                                io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> responseObserver) 
        {
            logger.info("Received GetScenarioRequest for name: '{}'", request.getName());

            /* Expected 'name' as in the form of 'scenarios/{scenario}' */
            String fscname = request.getName();
            String[] parts = fscname.split("/");
            if (parts.length > 2) {
                logger.info("Name format of get-scenario is possibly unexpected: '{}'", fscname);
            }
            String scname = parts[parts.length - 1];
            /* It is not clear that 'name' shall indicate the scenario-id or name.
             * We consider name as first assumption
             */
            SimulationOuterClass.Scenario sc = server.getScenarioForName(scname);
            if (sc == null) {
                /* Try to use 'name' as 'id' */
                logger.info("No scenario with name: '{}', try it to find by assuming scenario-id", scname);
                sc = server.getScenarioForId(scname);
                if (sc == null) {
                    logger.warn("No scenario in the system with name '{}'", scname);
                    // NOTE: No definition for error cases, we just return a Scenario message with empty 'name' to indicate the problem
                    SimulationOuterClass.Scenario response = SimulationOuterClass.Scenario.newBuilder()
                                                                                          .setName("")
                                                                                          .build();
                    responseObserver.onNext(response);
                    responseObserver.onCompleted();                               
                    return;
                }
                else {
                    logger.info("Scenario for 'get' is found in scenarioId map with id: '{}'", scname);
                }
            }
            /* Found previously created scenario. Send it through response. 
               TODO: Do we need to create a 'response' or just send by using found 'sc' instance?
             */
            SimulationOuterClass.Scenario response = SimulationOuterClass.Scenario.newBuilder(sc)
                                                                                  .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();                               
            
            logger.info("GetScenario: Sent success response for scenario with name: '{}'", response.getName());
        }

        @Override
        public void createSimulation(
        SimulationOuterClass.CreateSimulationRequest request,
        io.grpc.stub.StreamObserver<com.google.longrunning.Operation> responseObserver) {

            String simId = request.getSimulationId();
            logger.info("CreateSimulation (async) simId={}", simId);

            // ---- Scenario resolve ----
            String fscname = request.getSimulation().getScenario();
            String[] parts = fscname.split("/");
            if (parts.length > 2) {
                logger.info("createSimulation: Scenario name format is possibly unexpected: '{}'", fscname);
            }
            String scname = parts[parts.length - 1];

            SimulationOuterClass.Scenario sc = server.getScenarioForName(scname);
            String operationName = "operations/" + simId;

            if (sc == null) {
                sc = server.getScenarioForId(scname);
                if (sc == null) {
                    logger.warn("createSimulation: No scenario found with name or id '{}'", scname);

                    com.google.rpc.Status status = com.google.rpc.Status.newBuilder()
                            .setCode(com.google.rpc.Code.UNAVAILABLE_VALUE)
                            .setMessage("No scenario found with name/id: " + scname)
                            .build();

                    com.google.longrunning.Operation op = com.google.longrunning.Operation.newBuilder()
                            .setName(operationName)
                            .setDone(true)
                            .setError(status)
                            .build();

                    responseObserver.onNext(op);
                    responseObserver.onCompleted();
                    return;
                } else {
                    logger.info("createSimulation: Scenario found by id '{}'", scname);
                }
            }

            // ---- If delegation already exists and op exists, return it (idempotency) ----
            SimulationDelegation existingDelegation = server.simulationsForId.get(simId);
            if (existingDelegation != null) {
                com.google.longrunning.Operation existingOp = existingDelegation.getOperation(operationName);
                if (existingOp != null) {
                    logger.info("createSimulation: returning existing operation for simId={}", simId);
                    responseObserver.onNext(existingOp);
                    responseObserver.onCompleted();
                    return;
                }
            }

            // ---- SIMULATION OBJ -> RUNNING ----
            SimulationOuterClass.Simulation sim = request.getSimulation().toBuilder()
                    .setState(SimulationOuterClass.Simulation.State.RUNNING)
                    .setCreateTime(com.google.protobuf.Timestamp.newBuilder()
                            .setSeconds(Instant.now().getEpochSecond())
                            .build())
                    .build();

            // Important: setSimulation should NOT recreate delegation if it already exists
            server.setSimulation(simId, sim);

            // Delegation now guaranteed
            SimulationDelegation simd = server.simulationsForId.get(simId);
            if (simd == null) {
                // Defensive: should never happen if setSimulation is correct
                com.google.rpc.Status status = com.google.rpc.Status.newBuilder()
                        .setCode(com.google.rpc.Code.INTERNAL_VALUE)
                        .setMessage("SimulationDelegation was not created for simId: " + simId)
                        .build();

                com.google.longrunning.Operation op = com.google.longrunning.Operation.newBuilder()
                        .setName(operationName)
                        .setDone(true)
                        .setError(status)
                        .build();

                responseObserver.onNext(op);
                responseObserver.onCompleted();
                return;
            }

            // ---- LRO initial operation (store INSIDE delegation) ----
            SimulationOuterClass.CreateSimulationMetadata metadata =
                    SimulationOuterClass.CreateSimulationMetadata.newBuilder()
                            .setProgressPercent(0.0)
                            .build();

            com.google.longrunning.Operation op = com.google.longrunning.Operation.newBuilder()
                    .setName(operationName)
                    .setDone(false)
                    .setMetadata(com.google.protobuf.Any.pack(metadata))
                    .build();

            simd.putOperation(operationName, op);

            responseObserver.onNext(op);
            responseObserver.onCompleted();

            // ---- ASYNC background execution ----
            server.executor.submit(() -> runSimulationAsync(simId));
        }

        private void runSimulationAsync(String simId) {
            String operationName = "operations/" + simId;

            SimulationDelegation simd = server.simulationsForId.get(simId);
            if (simd == null) {
                logger.error("runSimulationAsync: No delegation found for simId={}", simId);
                return;
            }

            try {
                for (int i = 1; i <= 10; i++) {
                    Thread.sleep(200);

                    double progress = i * 10.0; // 10,20,...,100 daha mantıklı

                    SimulationOuterClass.CreateSimulationMetadata metadata =
                            SimulationOuterClass.CreateSimulationMetadata.newBuilder()
                                    .setProgressPercent(progress)
                                    .build();

                    com.google.longrunning.Operation updated =
                            com.google.longrunning.Operation.newBuilder()
                                    .setName(operationName)
                                    .setDone(false)
                                    .setMetadata(com.google.protobuf.Any.pack(metadata))
                                    .build();

                    simd.putOperation(operationName, updated);
                }

                // ---- DONE ----
                SimulationOuterClass.Simulation current = server.getSimulationForId(simId);
                if (current == null) {
                    throw new IllegalStateException("Simulation not found for simId=" + simId);
                }

                SimulationOuterClass.Simulation finalSim =
                        current.toBuilder()
                                .setState(SimulationOuterClass.Simulation.State.SUCCEEDED)
                                .build();

                server.setSimulation(simId, finalSim);

                com.google.longrunning.Operation doneOp =
                        com.google.longrunning.Operation.newBuilder()
                                .setName(operationName)
                                .setDone(true)
                                .setResponse(com.google.protobuf.Any.pack(finalSim))
                                .build();

                simd.putOperation(operationName, doneOp);

                logger.info("Simulation {} DONE", simId);

            } catch (Exception e) {
                com.google.rpc.Status status =
                        com.google.rpc.Status.newBuilder()
                                .setCode(com.google.rpc.Code.INTERNAL_VALUE)
                                .setMessage(e.getMessage() == null ? "runSimulationAsync failed" : e.getMessage())
                                .build();

                com.google.longrunning.Operation failed =
                        com.google.longrunning.Operation.newBuilder()
                                .setName(operationName)
                                .setDone(true)
                                .setError(status)
                                .build();

                simd.putOperation(operationName, failed);
                logger.error("runSimulationAsync failed for simId={}", simId, e);
            }
        }


        @Override
        public void getSimulation(
                com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetSimulationRequest request,
                io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation> responseObserver) {

            logger.info("Received Get-Simulation request with simulation-name: '{}'", request.getName());

            // Expected 'name' to be in the form of 'simulations/{simulation}'
            String fsimname = request.getName();
            String[] parts = fsimname.split("/");
            if (parts.length > 2) {
                logger.info("getSimulation: Name format is possibly unexpected: '{}'", fsimname);
            }
            String simname = parts[parts.length - 1];

            // Find simulation by name/id
            SimulationOuterClass.Simulation sim = server.getSimulationForName(simname);
            if (sim == null) {
                logger.info("getSimulation: No simulation is found with name: '{}'", simname);
                sim = server.getSimulationForId(simname);
                if (sim == null) {
                    responseObserver.onError(
                            io.grpc.Status.NOT_FOUND
                                    .withDescription("Simulation not found: " + request.getName())
                                    .asRuntimeException()
                    );
                    return;
                }
            }

            // Get delegation (try by id first, then by name)
            SimulationDelegation simd = server.simulationsForId.get(simname);
            if (simd == null) {
                simd = server.simulationsForName.get(simname);
            }

            String operationName = (simd == null)
                    ? ("operations/" + simname)              // fallback
                    : ("operations/" + simd.getSimulationId());

            com.google.longrunning.Operation op = (simd == null) ? null : simd.getOperation(operationName);

            // If operation finished with a response, prefer that as the latest simulation state
            if (op != null && op.getDone() && op.hasResponse()) {
                try {
                    SimulationOuterClass.Simulation finalSim =
                            op.getResponse().unpack(SimulationOuterClass.Simulation.class);

                    // IMPORTANT: setSimulation expects simulationId, NOT operationName
                    server.setSimulation(simname, finalSim);
                    sim = finalSim;

                } catch (Exception e) {
                    logger.error("getSimulation: Failed to unpack simulation from operation", e);
                }
            }

            SimulationOuterClass.Simulation response =
                    SimulationOuterClass.Simulation.newBuilder(sim).build();

            responseObserver.onNext(response);
            responseObserver.onCompleted();

            logger.info("getSimulation: Sent success response for simulation '{}'", response.getName());
        }


        @Override
        public void createAnalysis(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateAnalysisRequest request,
                                   io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis> responseObserver) {
            logger.info("createAnalysis: Received Create-Analysis request for parent: '{}' and analysis-id: '{} with interval: '{}_{} - {}_{} and resolution: '{}_{}'",
                        request.getParent(), request.getAnalysisId(), 
                        request.getAnalysis().getInterval().getStartTime().getSeconds(), request.getAnalysis().getInterval().getStartTime().getNanos(),
                        request.getAnalysis().getInterval().getEndTime().getSeconds(), request.getAnalysis().getInterval().getEndTime().getNanos(),
                        request.getAnalysis().getResolution().getSeconds(), request.getAnalysis().getResolution().getNanos());

            /* TODO: Perform corresponding checks and create Analysis instance to save locally and return it as the response */

            SimulationOuterClass.Analysis response = server.setAnalysis(request.getParent(), request.getAnalysisId(), request.getAnalysis());

            responseObserver.onNext(response);
            responseObserver.onCompleted();
        }

        // public SimulationOuterClass.P2pSrTePolicyCandidatePathStats.Builder obtainP2pSrTePolicyCandidatePathStats() {
        //     SimulationOuterClass.P2pSrTePolicyCandidatePathStats.Builder stats = SimulationOuterClass.P2pSrTePolicyCandidatePathStats.newBuilder();

        //     stats.setPath("test-path");

        //     DataGenerator dgCIR = new DataGenerator(27000, 28000, 100);
        //     stats.setCirAvgBps(dgCIR.getAverage());
        //     stats.setCirStddevBps(dgCIR.getStdDev());
        //     stats.setCirMinBps(dgCIR.getMinValue());
        //     stats.setCirMaxBps(dgCIR.getMaxValue());
        //     stats.setCirPercentile(0);

        //     DataGenerator dgEIR = new DataGenerator(29000, 30000, 100);
        //     stats.setEirAvgBps(dgEIR.getAverage());
        //     stats.setEirStddevBps(dgEIR.getStdDev());
        //     stats.setEirMinBps(dgEIR.getMinValue());
        //     stats.setEirMaxBps(dgEIR.getMaxValue());
        //     stats.setEirPercentile(0);

        //     stats.setFrameDelayAvg(com.google.protobuf.Duration.newBuilder().setSeconds(0).setNanos(0));
        //     stats.setFrameDelayStddev(com.google.protobuf.Duration.newBuilder().setSeconds(0).setNanos(0));
        //     stats.setFrameDelayMin(com.google.protobuf.Duration.newBuilder().setSeconds(0).setNanos(0));
        //     stats.setFrameDelayMax(com.google.protobuf.Duration.newBuilder().setSeconds(0).setNanos(0));
        //     stats.setFrameDelayPercentile(0);

        //     stats.setIfdvAvg(com.google.protobuf.Duration.newBuilder().setSeconds(0).setNanos(0));
        //     stats.setIfdvStddev(com.google.protobuf.Duration.newBuilder().setSeconds(0).setNanos(0));
        //     stats.setIfdvMin(com.google.protobuf.Duration.newBuilder().setSeconds(0).setNanos(0));
        //     stats.setIfdvMax(com.google.protobuf.Duration.newBuilder().setSeconds(0).setNanos(0));
        //     stats.setIfdvPercentile(0);

        //     return stats;
        // }

        @Override
        public void getAnalysis(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetAnalysisRequest request,
                                io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis> responseObserver) {
            logger.info("getAnalysis: Requested analysis with name: '{}'", request.getName());

            /* name is in the form of simulations/{simulation}/analyses/{analysis}. */
            String fanname = request.getName();
            String[] parts = fanname.split("/");
            if (parts.length > 4) {
                logger.info("getAnalysis: Name format is possibly unexpected: '{}'", fanname);
            }
            String aname = parts[parts.length - 1];

            SimulationOuterClass.Analysis analysis = server.getAnalysisForName(aname);
            if (analysis == null) {
                logger.warn("getAnalysis: Cannot find Analysis instance for name: '{}'", aname);
                /* Return an empty Analysis (?!) */
                SimulationOuterClass.Analysis response = SimulationOuterClass.Analysis.newBuilder()
                                                                                      .build();
                responseObserver.onNext(response);
                responseObserver.onCompleted();
                return;
            }
            SimulationOuterClass.Analysis response = SimulationOuterClass.Analysis.newBuilder(analysis)
                                                                                  .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
        }

    }

    public void readConfiguration(String confFileName) {
        this.config = new SimulationServerConfiguration(confFileName);
        this.config.parseForJson();
    }


    public static void main(String[] args) throws IOException, InterruptedException {
        int port = 50051;
        String inProcessName = null;

        String confFileName = "config/sim_server_config.json";

        for (int i = 0; i < args.length; i++) {
            if ("--inprocess".equals(args[i]) && i + 1 < args.length) {
                inProcessName = args[i + 1];
                i++;
            } 
            else if (!args[i].startsWith("--")) {
                // First non-flag argument as port for backward compatibility
                port = Integer.parseInt(args[i]);
            }
        }

        SimulationServer server = new SimulationServer(port);
        server.readConfiguration(confFileName);

        if (inProcessName != null) {
            server.startInProcess(inProcessName);
        } 
        else {
            server.start();
        }
        server.blockUntilShutdown();
    }
}
