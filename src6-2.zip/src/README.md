# Quarkus gRPC Simulation Service

Bu proje Quarkus framework kullanılarak geliştirilmiş bir gRPC servisidir.

## Gereksinimler

- Java 21
- Maven 3.8+
- Docker (opsiyonel, container image oluşturmak için)

## Proje Yapısı

```
src/
├── java/                    # Java kaynak kodları
│   └── com/telesat/
├── resources/               # Kaynak dosyalar (application.properties vb.)
├── proto/                   # Protocol Buffer tanımları
└── docker/                  # Docker dosyaları
```

## Çalıştırma

### Development Mode

```bash
./mvnw quarkus:dev
```

veya Maven wrapper yoksa:

```bash
mvn quarkus:dev
```

### Production Build

```bash
./mvnw clean package
```

### Native Build

```bash
./mvnw clean package -Pnative
```

## Docker

### JVM Image

```bash
./mvnw clean package
docker build -f docker/Dockerfile.jvm -t simtest-jvm .
docker run -i --rm -p 8080:8080 simtest-jvm
```

### Native Image

```bash
./mvnw clean package -Pnative
docker build -f docker/Dockerfile.native -t simtest-native .
docker run -i --rm -p 8080:8080 simtest-native
```

## Portlar

- HTTP: 8080
- gRPC: 9000

## Server çalışıyor mu nasıl kontrol edilir?

1. **Tarayıcı:** http://localhost:8080 aç; sayfa veya hata dönüyorsa server ayakta demektir.
2. **Health endpoint (PowerShell):**
   ```powershell
   Invoke-WebRequest -Uri http://localhost:8080/q/health -UseBasicParsing | Select-Object StatusCode, Content
   ```
   veya `curl http://localhost:8080/q/health`
3. **Portlar dinleniyor mu:**
   ```powershell
   netstat -ano | findstr "8080 9000"
   ```
   Hem 8080 hem 9000 LISTENING görünüyorsa server çalışıyordur.

## SimulationClient çalıştırma

Server’ın çalıştığından emin ol (yukarıdaki kontroller). Gerekirse önce `mvn compile`. Sonra proje kökünde:

```bash
mvn exec:java@SimulationClient
```

Farklı hedef (host:port) için:

```bash
mvn exec:java@SimulationClient -Dexec.args="localhost:9000 --config config/sim_config.json"
```

Windows’ta JAVA_HOME gerekirse:

```powershell
$env:JAVA_HOME = "C:\Program Files\Java\jdk-21"
mvn exec:java@SimulationClient
```

## VS Code / Cursor’da çalıştırma

1. **Server:** `Ctrl+Shift+P` → “Tasks: Run Task” → **“Quarkus: Server (quarkus:dev)”**  
   veya Terminal menüsü → “Run Task…” → aynı task.  
   Server ayakta kalır; durdurmak için o terminalde `Ctrl+C`.

2. **Client:** Yeni bir terminal açıp aynı şekilde “Run Task” → **“SimulationClient: Client”** seç.  
   Önce server’ın çalıştığından emin ol (http://localhost:8080 veya port kontrolü).

JAVA_HOME farklıysa `.vscode/tasks.json` içindeki `JAVA_HOME` değerini kendi JDK yoluna göre güncelle.

## Yapılandırma

Uygulama ayarları `src/main/resources/application.properties` dosyasında bulunur.
