package com.telesat.client;

import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass;
import com.aalyria.spacetime.simulation.v1alpha.SimulationServiceGrpc;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

public class TestClient {
    public static void main(String[] args) {

        ManagedChannel channel = ManagedChannelBuilder
            .forAddress("localhost", 9000)
            .usePlaintext()
            .build();

        SimulationServiceGrpc.SimulationServiceBlockingStub stub =
            SimulationServiceGrpc.newBlockingStub(channel);

        SimulationOuterClass.GetSimulationRequest req = 
            SimulationOuterClass.GetSimulationRequest.newBuilder()
                .setName("simulations/test")
                .build();
        
        SimulationOuterClass.Simulation response = stub.getSimulation(req);

        System.out.println("response: " + response);

        channel.shutdownNow();
    }
}