package com.telesat.services.simulation;

import java.time.Instant;

import jakarta.inject.Inject;

import org.jboss.logging.Logger;

import io.quarkus.grpc.GrpcService;
import io.grpc.Status;
import io.grpc.stub.StreamObserver;

import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass;
import com.aalyria.spacetime.simulation.v1alpha.SimulationServiceGrpc;
import com.google.longrunning.Operation;
import com.google.protobuf.Any;
import com.google.protobuf.Timestamp;
import com.google.rpc.Code;

/**
 * Quarkus gRPC service implementation.
 *
 * Note: We only implement the subset of RPCs currently used by the client/demo.
 * All other RPCs remain UNIMPLEMENTED by default.
 */
@GrpcService
public class SimulationGrpcService extends SimulationServiceGrpc.SimulationServiceImplBase {

    private static final Logger logger = Logger.getLogger(SimulationGrpcService.class);

    @Inject
    SimulationServer server;

    @Override
    public void createScenario(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateScenarioRequest request,
                               io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> responseObserver) 
    {
        // Receiver create-scenario request. Extract the information from the request for appropriate action
        String scenarioId = request.getScenarioId();
        logger.infof("Received CreateScenarioRequest for id: %s and name: %s with description: %s", 
                     scenarioId, request.getScenario().getName(), request.getScenario().getDescription());

        SimulationOuterClass.Scenario sc = server.getScenarioForId(scenarioId);
        if (sc != null) {
            logger.warnf("There is already created scenario with id %s", scenarioId);
            // NOTE: No definition for error cases, we just return a Scenario message with empty 'name' to indicate the problem
            // TODO: Another approach might be applied to return found scenario
            SimulationOuterClass.Scenario response = SimulationOuterClass.Scenario.newBuilder()
                                                                                  .setName("")
                                                                                  .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();                               
            return;
        }
        /* No previously created scenario is found. Create new one. It is also be our response
         * Note that originator determines the scenario name and description, so we may copy as received
         */

        SimulationOuterClass.Scenario response = SimulationOuterClass.Scenario.newBuilder(request.getScenario())
                                                                              .build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();                               
            
        /* Save into server's map */
        server.setScenario(scenarioId, response);
        logger.infof("Sent success response for scenario with id: %s and name: %s", scenarioId, response.getName());
    }

    @Override
    public void getScenario(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetScenarioRequest request,
                            io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario> responseObserver) 
    {
        logger.infof("Received GetScenarioRequest for name: %s", request.getName());

        /* Expected 'name' as in the form of 'scenarios/{scenario}' */
        String fscname = request.getName();
        String[] parts = fscname.split("/");
        if (parts.length > 2) {
            logger.infof("Name format of get-scenario is possibly unexpected: %s", fscname);
        }
        String scname = parts[parts.length - 1];
        /* It is not clear that 'name' shall indicate the scenario-id or name.
         * We consider name as first assumption
         */
        SimulationOuterClass.Scenario sc = server.getScenarioForName(scname);
        if (sc == null) {
            /* Try to use 'name' as 'id' */
            logger.infof("No scenario with name: %s, try it to find by assuming scenario-id", scname);
            sc = server.getScenarioForId(scname);
            if (sc == null) {
                logger.warnf("No scenario in the system with name %s", scname);
                // NOTE: No definition for error cases, we just return a Scenario message with empty 'name' to indicate the problem
                SimulationOuterClass.Scenario response = SimulationOuterClass.Scenario.newBuilder()
                                                                                      .setName("")
                                                                                      .build();
                responseObserver.onNext(response);
                responseObserver.onCompleted();                               
                return;
            }
            else {
                logger.infof("Scenario for 'get' is found in scenarioId map with id: %s", scname);
            }
        }
        /* Found previously created scenario. Send it through response. 
           TODO: Do we need to create a 'response' or just send by using found 'sc' instance?
         */
        SimulationOuterClass.Scenario response = SimulationOuterClass.Scenario.newBuilder(sc)
                                                                              .build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();                               
            
        logger.infof("GetScenario: Sent success response for scenario with name: %s", response.getName());
    }

    @Override
    public void createSimulation(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateSimulationRequest request,
                                     io.grpc.stub.StreamObserver<com.google.longrunning.Operation> responseObserver) {

        logger.infof("Received Create-Simulation request with simulation-id: %s and name: %s for scenario: %s",
                        request.getSimulationId(), request.getSimulation().getName(), request.getSimulation().getScenario());
            
        logger.infof("Simulation start-time: %s_%s, end-time: %s_%s",
                        request.getSimulation().getInterval().getStartTime().getSeconds(),
                        request.getSimulation().getInterval().getStartTime().getNanos(),
                        request.getSimulation().getInterval().getEndTime().getSeconds(),
                        request.getSimulation().getInterval().getEndTime().getNanos());

            /* Expected 'scenario' inside of Simulation is in the form of 'scenarios/{scenario}' */
        String fscname = request.getSimulation().getScenario();
        String[] parts = fscname.split("/");
        if (parts.length > 2) {
            logger.infof("createSimulation: Name format of-scenario is possibly unexpected: %s", fscname);
        }
        String scname = parts[parts.length - 1];
            /* It is not clear that 'name' shall indicate the scenario-id or name.
             * We consider name as first assumption
             */
        SimulationOuterClass.Scenario sc = server.getScenarioForName(scname);
        if (sc == null) {
                /* Try to use 'name' as 'id' */
            logger.infof("createSimulation: No scenario with name: %s, try it to find by assuming scenario-id", scname);
            sc = server.getScenarioForId(scname);
            if (sc == null) {
                logger.warnf("createSimulation: No scenario in the system with name %s", scname);
                    // Return error 
                com.google.rpc.Status status = com.google.rpc.Status.newBuilder()
                                                                    .setCode(com.google.rpc.Code.UNAVAILABLE_VALUE)
                                                                    .setMessage("No scenario found with name: " + scname)
                                                                    .build();
                com.google.longrunning.Operation response = com.google.longrunning.Operation.newBuilder()
                                                                                            .setName(request.getSimulationId())
                                                                                            .setDone(true)
                                                                                            .setError(status)
                                                                                            .build();
                responseObserver.onNext(response);
                responseObserver.onCompleted();                               
                return;
            }
            else {
                logger.infof("createSimulation: Scenario is found in scenarioId map with id: %s", scname);
            }
        }
            // We have corresponding scenario, check if there is already created simulation with same id
        SimulationOuterClass.Simulation tsim = server.getSimulationForId(request.getSimulationId());
        if (tsim != null) {
                /* There is previously created simulation with same id */
            logger.errorf("There is previously created simulation with id: %s", request.getSimulationId());
                /* Return an unsuccess operation */
            com.google.rpc.Status status = com.google.rpc.Status.newBuilder()
                                                                    .setCode(com.google.rpc.Code.ALREADY_EXISTS_VALUE)
                                                                    .setMessage("Already there is a simulation with id: " + request.getSimulationId())
                                                                    .build();
                /* NOTE: We consider Create-Simulation request may be used to get progress-percent info 
                         for already created simulations (because, it seems that, there is no other way 
                         to get this info. So, return success operation as response including metadata
                 */
            double progressPercent = this.server.getSimulationProgressPercent(request.getSimulationId());
            SimulationOuterClass.CreateSimulationMetadata metadata = SimulationOuterClass.CreateSimulationMetadata.newBuilder()
                                                                                                                      .setProgressPercent(progressPercent)
                                                                                                                      .build();
            com.google.longrunning.Operation response = com.google.longrunning.Operation.newBuilder()
                                                                                            .setName(request.getSimulationId())
                                                                                            .setDone(true)
                                                                                            .setError(status)
                                                                                            .setMetadata(com.google.protobuf.Any.pack(metadata))
                                                                                            .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();                               
            return;
        }
            /* No previously created simulation is found. Create new one to store. 
             */
        com.google.protobuf.Timestamp ts = com.google.protobuf.Timestamp.newBuilder().setSeconds(System.currentTimeMillis()).build();
        SimulationOuterClass.Simulation.State st = SimulationOuterClass.Simulation.State.RUNNING;
        SimulationOuterClass.Simulation sim = request.getSimulation().toBuilder().setState(st).setCreateTime(ts).build();
        server.setSimulation(request.getSimulationId(), sim);

            /* Return success operation as response including metadata
             */
        SimulationOuterClass.CreateSimulationMetadata metadata = SimulationOuterClass.CreateSimulationMetadata.newBuilder()
                                                                                                                  .setProgressPercent(0.0)
                                                                                                                  .build();
        com.google.longrunning.Operation response = com.google.longrunning.Operation.newBuilder()
                                                                                        .setName(request.getSimulationId())
                                                                                        .setDone(false)
                                                                                        .setMetadata(com.google.protobuf.Any.pack(metadata))
                                                                                        .build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();                               
            
        logger.infof("Sent success response for simulation creation with id: %s and name: %s", request.getSimulationId(), sim.getName());
    }

    @Override
    public void getSimulation(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetSimulationRequest request,
                                  io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation> responseObserver) {
            
        logger.infof("Received Get-Simulation request with simulation-name: %s", request.getName());

        /* Expected 'name' to be in the form of 'simulations/{simulation}' */
        String fsimname = request.getName();
        String[] parts = fsimname.split("/");
        if (parts.length > 2) {
            logger.infof("getSimulation: Name format is possibly unexpected: %s", fsimname);
        }
        String simname = parts[parts.length - 1];

        SimulationOuterClass.Simulation sim = server.getSimulationForName(simname);
        if (sim == null) {
            logger.infof("getSimulation: No simulation is found with name: %s", simname);
            /* Not sure the information included in 'name' of the request, such that if it indicates 
               a simulation-name of simularion-id. So, try it to find in the map for simulation-id */
            sim = server.getSimulationForId(simname);
            if (sim == null) {
                logger.errorf("getSimulation: No simulation found in simulation-id map too, with: '{}'", simname);
                /* TODO: No error cases are defined in API. Return an empty Simulation instnace */
                return;
            }
        }
        /* Found previously created simulation. Send it through response.
        TODO: Do we need to create a 'response' or just send by using found 'sim' instance? 
         */
        SimulationOuterClass.Simulation response = SimulationOuterClass.Simulation.newBuilder(sim)
                                                                                      .build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();                               
            
        logger.infof("getSimulation: Sent success response for simulation with name: %s", response.getName());
    }

    @Override
    public void createAnalysis(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateAnalysisRequest request,
                                   io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis> responseObserver) {
        logger.infof("createAnalysis: Received Create-Analysis request for parent: %s and analysis-id: '%s with interval: '%s_%s - %s_%s and resolution: '%s_%s'",
                    request.getParent(), request.getAnalysisId(), 
                    request.getAnalysis().getInterval().getStartTime().getSeconds(), request.getAnalysis().getInterval().getStartTime().getNanos(),
                    request.getAnalysis().getInterval().getEndTime().getSeconds(), request.getAnalysis().getInterval().getEndTime().getNanos(),
                    request.getAnalysis().getResolution().getSeconds(), request.getAnalysis().getResolution().getNanos());

        /* TODO: Perform corresponding checks and create Analysis instance to save locally and return it as the response */

        SimulationOuterClass.Analysis response = server.setAnalysis(request.getParent(), request.getAnalysisId(), request.getAnalysis());

        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void getAnalysis(com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetAnalysisRequest request,
                            io.grpc.stub.StreamObserver<com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Analysis> responseObserver) {
        logger.infof("getAnalysis: Requested analysis with name: %s", request.getName());

        /* name is in the form of simulations/{simulation}/analyses/{analysis}. */
        String fanname = request.getName();
        String[] parts = fanname.split("/");
        if (parts.length > 4) {
            logger.infof("getAnalysis: Name format is possibly unexpected: %s", fanname);
        }
        String aname = parts[parts.length - 1];

        SimulationOuterClass.Analysis analysis = server.getAnalysisForName(aname);
        if (analysis == null) {
            logger.warnf("getAnalysis: Cannot find Analysis instance for name: %s", aname);
            /* Return an empty Analysis (?!) */
            SimulationOuterClass.Analysis response = SimulationOuterClass.Analysis.newBuilder()
                                                                                  .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
            return;
        }
        SimulationOuterClass.Analysis response = SimulationOuterClass.Analysis.newBuilder(analysis)
                                                                              .build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }


}
