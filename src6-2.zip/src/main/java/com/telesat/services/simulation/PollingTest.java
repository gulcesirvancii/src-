package com.telesat.services.simulation;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass;

public class PollingTest {

    //private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
    //private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(10);

    Integer[] counters;
    int currNum = 0;

    List<SimulationDelegation> simulations = new ArrayList<>();

    public String printArray(Integer[] arr, int num) {
        StringBuilder sb = new StringBuilder();
        sb.append('[');
        for (int i = 0; i < num; i++) {
            sb.append(arr[i]);
            if ((i + 1) < num) {
                sb.append(", ");
            }
        }
        sb.append(']');
        return sb.toString();
    }

    public SimulationOuterClass.Simulation getSimulation(String name) {
        int idx = name.indexOf("-");
        String num = name.substring(idx+1, name.length());
        Integer ctr = Integer.valueOf(num);
        System.out.println("num is " + num + " ctr is " + ctr);

        // if (counters.get(ctr) == null) {
        //     counters.add(0);
        //     System.out.println("Setting value to index: " + ctr + " -- " + counters);
        // }
        // else {
        //     Integer temp = counters.get(ctr);
        //     temp += 1; 
        //     System.out.println("Increased value in index: " + ctr + " to: " + temp + " -- " + counters);
        // }

        // if (counters[ctr] == null) {
        //     counters[ctr] = 0;
        //     currNum++;
        //     System.out.println("Setting value to index: " + ctr + " currNum: " + currNum + " -- " + printArray(counters, currNum));
        // }
        // else {
        //     counters[ctr]++;
        //     System.out.println("Increased value in index: " + ctr + " -- " + printArray(counters, currNum));
        // }
        counters[ctr]--;
        System.out.println("Decreased value in index: " + ctr + " -- " + printArray(counters, currNum));

        return SimulationOuterClass.Simulation.newBuilder().setName("test-sim::" + name)
                                                           .setState((counters[ctr] <= 0) ? SimulationOuterClass.Simulation.State.SUCCEEDED 
                                                                                          : SimulationOuterClass.Simulation.State.RUNNING)
                                                           .build();
    }

    // private void pollSimulationUntilDone(String simulationName) {

    //     System.out.println("pollSimulationUntilDone: Polling the status of simulation: " + simulationName + " time: " + LocalDateTime.now());

    //     Runnable pollTask = () -> {
    //         try {
    //             SimulationOuterClass.Simulation sim = getSimulation(simulationName);

    //             if (sim.getState() == SimulationOuterClass.Simulation.State.SUCCEEDED) {

    //                 System.out.println("Simulation DONE: " + sim.getName());
    //                 scheduler.shutdown();

    //             } 
    //             else {
    //                 System.out.println("Simulation '" + simulationName + "' still running, state=" + sim.getState() 
    //                                    + " time: " + LocalDateTime.now() + " -- " + Thread.currentThread().threadId() 
    //                                    + "(" + Thread.activeCount() + ")");
    //             }

    //         } 
    //         catch (Exception e) {
    //             System.out.println("Polling failed: " + e.getMessage());
    //         }
    //     };

    //     //scheduler.scheduleAtFixedRate(pollTask, 0, 3, TimeUnit.SECONDS);
    //     scheduler.scheduleWithFixedDelay(pollTask, 0, 3, TimeUnit.SECONDS);
    // }

    private void simulationIsDone(String simulationName) {
        System.out.println("Simulation " + simulationName + " is done...");
    }

    private void pollSimulationUntilDone(String simulationName, ScheduledExecutorService scheduler) {

        System.out.println("pollSimulationUntilDone: Polling the status of simulation: " + simulationName + " time: " + LocalDateTime.now());

        Runnable pollTask = () -> {
            try {
                SimulationOuterClass.Simulation sim = getSimulation(simulationName);

                if (sim.getState() == SimulationOuterClass.Simulation.State.SUCCEEDED) {

                    simulationIsDone(simulationName);
                    System.out.println("Simulation DONE: " + sim.getName());
                    scheduler.shutdown();

                } 
                else {
                    System.out.println("Simulation '" + simulationName + "' still running, state=" + sim.getState() 
                                       + " time: " + LocalDateTime.now() + " -- " + Thread.currentThread().threadId() 
                                       + "(" + Thread.activeCount() + ")");
                }

            } 
            catch (Exception e) {
                System.out.println("Polling failed: " + e.getMessage());
            }
        };

        //scheduler.scheduleAtFixedRate(pollTask, 0, 3, TimeUnit.SECONDS);
        scheduler.scheduleWithFixedDelay(pollTask, 0, 3, TimeUnit.SECONDS);

    //     public void beepForAnHour() {
    //  Runnable beeper = () -> System.out.println("beep");
    //  ScheduledFuture<?> beeperHandle =
    //    scheduler.scheduleAtFixedRate(beeper, 10, 10, SECONDS);
    //  Runnable canceller = () -> beeperHandle.cancel(false);
    //  scheduler.schedule(canceller, 1, HOURS);
    }

    private void hitForSimulation(String name) {
        int idx = name.indexOf("-");
        String num = name.substring(idx+1, name.length());
        Integer ctr = Integer.valueOf(num);
        System.out.println("num is " + num + " ctr is " + ctr);

        counters[ctr]--;
        System.out.println("Hit for simulation in index: " + ctr + " -- " + printArray(counters, currNum));
    }

    private void setSimulationCompleted(String simulationName) {
        for (int i = 0; i < this.simulations.size(); i++) {
            if (this.simulations.get(i).getSimulation().getName().equals(simulationName)) {
                SimulationOuterClass.Simulation sim = this.simulations.get(i).getSimulation();
                
                SimulationOuterClass.Simulation newsim = SimulationOuterClass.Simulation.newBuilder(sim)
                                                                                        .setState(SimulationOuterClass.Simulation.State.SUCCEEDED)
                                                                                        .build();
                this.simulations.get(i).setSimulation(newsim);
                break;                                                                                    
            }
        }
    }

    private SimulationOuterClass.Simulation.State getSimulationState(String simulationName) {
        for (int i = 0; i < this.simulations.size(); i++) {
            if (this.simulations.get(i).getSimulation().getName().equals(simulationName)) {
                return this.simulations.get(i).getSimulation().getState();
            }
        }
        return SimulationOuterClass.Simulation.State.UNRECOGNIZED;
    }

    private void ownSimulationForDuration(String simulationName, ScheduledExecutorService sch, long delayInSec) {

        Runnable owningTask = () -> {
            try {
                System.out.println("Owning task is executing for simulation: " + simulationName);
                //hitForSimulation(simulationName);
                SimulationOuterClass.Simulation.State simstate = getSimulationState(simulationName);
                if (simstate == SimulationOuterClass.Simulation.State.SUCCEEDED) {
                    simulationIsDone(simulationName);
                    System.out.println("Simulation DONE: " + simulationName);
                    sch.shutdown();
                }
                else {
                    System.out.println("Simulation '" + simulationName + "' still running, state=" + simstate 
                                       + " time: " + LocalDateTime.now() + " -- " + Thread.currentThread().threadId() 
                                       + "(" + Thread.activeCount() + ")");
                }
                hitForSimulation(simulationName);
            }
            catch (Exception e) {
                System.out.println("Owning failed: " + e.getMessage());
            }
        };

        /*final ScheduledFuture<?> simfuture =*/ sch.scheduleWithFixedDelay(owningTask, 0, 1, TimeUnit.SECONDS);

        Runnable canceller = () -> {
            // simfuture.cancel(false);
            // boolean cancelled = simfuture.cancel(true); // Attempt to cancel the 'owning' task
            // System.out.println("Cancellation attempt result: " + cancelled + " for simulation: " + simulationName);
            // sch.shutdown(); // Shutdown the scheduler after cancellation
            /* Instead of "cancelling" try to set simulation as SUCCEEDED */
            System.out.println("Setting completed for simulation: " + simulationName);
            setSimulationCompleted(simulationName);
        };
        sch.schedule(canceller, delayInSec, TimeUnit.SECONDS);
    }

    private void createSimulations(int count) {
        for (int i = 0; i < count; i++) {
            String simname = "sim1-"+ Integer.toString(i);
            String simid = simname + UUID.randomUUID();
            SimulationOuterClass.Simulation sim = SimulationOuterClass.Simulation.newBuilder()
                                                                                 .setName(simname)
                                                                                 .build();
            SimulationDelegation simdlg = new SimulationDelegation(simid, sim);
            this.simulations.addLast(simdlg);
        }
    }

    private void testApproach_1() throws Exception {
        //PollingTest test = new PollingTest();

        this.counters = new Integer[10];
        int i = 0;
        this.counters[this.currNum++] = 13;
        this.pollSimulationUntilDone("sim1-"+ Integer.toString(i++), Executors.newSingleThreadScheduledExecutor());
        Thread.sleep(1000);
        this.counters[this.currNum++] = 17;
        this.pollSimulationUntilDone("sim1-"+ Integer.toString(i++), Executors.newSingleThreadScheduledExecutor());
        Thread.sleep(1000);
        this.counters[this.currNum++] = 9;
        this.pollSimulationUntilDone("sim1-"+ Integer.toString(i++), Executors.newSingleThreadScheduledExecutor());
        Thread.sleep(1000);
        this.counters[this.currNum++] = 20;
        this.pollSimulationUntilDone("sim1-"+ Integer.toString(i++), Executors.newSingleThreadScheduledExecutor());
        Thread.sleep(1000);
        this.counters[this.currNum++] = 15;
        this.pollSimulationUntilDone("sim1-"+ Integer.toString(i++), Executors.newSingleThreadScheduledExecutor());
    }

    private void testApproach_2() {
        this.counters = new Integer[10];
        int numberOfSimulations = 6;

        this.createSimulations(numberOfSimulations);
        
        Random rnd = new Random();
        /* Obtain random durations for simulations */
        for (int i = 0; i < numberOfSimulations; i++) {
            this.counters[this.currNum++] = rnd.nextInt(10, 30);
        }
        
        System.out.println(Arrays.toString(this.counters));

        for (int i = 0; i < numberOfSimulations; i++) {
            this.ownSimulationForDuration(this.simulations.get(i).getSimulation().getName(), Executors.newSingleThreadScheduledExecutor(), this.counters[i]);
        }

    }

    public static void main(String[] args) throws Exception {
        PollingTest test = new PollingTest();

        //test.testApproach_1();
        test.testApproach_2();

        // /* Create server side tasks that owning simulation state */
        // for (int i = 0; i < numberOfSimulations; i++) {

        // }

        // /* Create client side tasks for state query */
        // for (int i = 0; i < numberOfSimulations; i++) {
        //     test.counters[test.currNum++] = rnd.nextInt(10, 30);
        //     test.pollSimulationUntilDone("sim1-"+ Integer.toString(i), Executors.newSingleThreadScheduledExecutor());
        //     Thread.sleep(1000);
        // }

        
    }
}
