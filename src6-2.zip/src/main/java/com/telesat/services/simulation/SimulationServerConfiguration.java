package com.telesat.services.simulation;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class SimulationServerConfiguration {
 
    String configFileName;

    public SimulationServerConfiguration(String configFileName) {
        this.configFileName = configFileName;
    }

    LinkedHashMap<String, ServerAnalysisConfig> analysisConfigs = new LinkedHashMap<>();
    
    class ServerAnalysisConfig {
        String name;
        String simulation;

        long cirMinBps;
        long cirMaxBps;
        long eirMinBps;
        long eirMaxBps;

        long frameDelayMinUs;
        long frameDelayMaxUs;
        long ifdvMinUs;
        long ifdvMaxUs;

        int pathCount;

        long samplingPeriodMs;

        public ServerAnalysisConfig(JsonElement jelm) {
            JsonObject obj = jelm.getAsJsonObject();
            Set<Entry<String, JsonElement>> entries = obj.entrySet();
            for (Entry<String, JsonElement> entry : entries) {
                String key = entry.getKey();
                switch (key) {
                    case "name":
                        this.name = entry.getValue().getAsString();
                        break;
                    case "simulation":
                        this.simulation = entry.getValue().getAsString();
                        break;
                    case "cir-min-bps":
                        this.cirMinBps = entry.getValue().getAsLong();
                        break;
                    case "cir-max-bps":
                        this.cirMaxBps = entry.getValue().getAsLong();
                        break; 
                    case "eir-min-bps":
                        this.eirMinBps = entry.getValue().getAsLong();
                        break;
                    case "eir-max-bps":
                        this.eirMaxBps = entry.getValue().getAsLong();
                        break;    
                    case "frame-delay-min-us": 
                        this.frameDelayMinUs = entry.getValue().getAsLong();
                        break;
                    case "frame-delay-max-us": 
                        this.frameDelayMaxUs = entry.getValue().getAsLong();
                        break;
                    case "ifdv-min-us": 
                        this.ifdvMinUs = entry.getValue().getAsLong();
                        break;
                    case "ifdv-max-us": 
                        this.ifdvMaxUs = entry.getValue().getAsLong();
                        break;
                    case "path-count":
                        this.pathCount = entry.getValue().getAsInt();
                        break;
                    case "sampling-period-ms":
                        this.samplingPeriodMs = entry.getValue().getAsLong();
                        break;
                    default:
                        System.err.println("Unhandled parameters for server-analysis: " + key);
                }
            }
        }

        public String getName() {
            return this.name;
        }

        public String getSimulation() {
            return this.simulation;
        }

        public long getCirMinBps() {
            return this.cirMinBps;
        }

        public long getCirMaxBps() {
            return this.cirMaxBps;
        }

        public long getEirMinBps() {
            return this.eirMinBps;
        }

        public long getEirMaxBps() {
            return this.eirMaxBps;
        }

        public long getFrameDelayMinUs() {
            return this.frameDelayMinUs;
        }

        public long getFrameDelayMaxUs() {
            return this.frameDelayMaxUs;
        }

        public long getIfdvMinUs() {
            return this.ifdvMinUs;
        }

        public long getIfdvMaxUs() {
            return this.ifdvMaxUs;
        }

        public int getPathCount() {
            return this.pathCount;
        }

        public long getSamplingPeriodMs() {
            return this.samplingPeriodMs;
        }
    }

    void parseForJson() {
        Path path = Paths.get(this.configFileName);

        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {

            //JsonParser parser = new JsonParser();
            JsonElement tree = JsonParser.parseReader(reader);

            JsonObject obj = tree.getAsJsonObject();
            System.out.println(obj);
            Set<String> keys = obj.keySet();
            for (String key : keys) {
                System.out.println(key);
                JsonElement element = obj.get(key);
                if (element.isJsonArray()) {
                    JsonArray earray = element.getAsJsonArray();
                    for (JsonElement aelm : earray) {
                        switch (key) {
                            case "analyses":
                                System.out.println("Analyses element: " + aelm);
                                ServerAnalysisConfig anconf = new ServerAnalysisConfig(aelm);
                                this.analysisConfigs.put(anconf.getName(), anconf);
                                break;

                            default:
                                System.err.println("Unhandled key: " + key);
                        }
                    }
                }
                // else no-array element
            }
        }
        catch (FileNotFoundException ex) {
            System.err.println("parseForJson: Configuration file '" + this.configFileName + "' not found.");
            ex.printStackTrace();
        }
        catch (IOException ex) {
            System.err.println("parseForJson: Error reading configuration file.");
            ex.printStackTrace();
        }

        for (ServerAnalysisConfig anconf : this.analysisConfigs.values()) {
            System.out.println(anconf);
        }
    }

    public long getAnalysisCirMinBps(String anlName) {
        ServerAnalysisConfig anconf = this.analysisConfigs.get(anlName);
        if (anconf == null) {
            System.err.println("getAnalysisCirMinBps: No analysis with name: " + anlName);
            return 0;
        }
        return anconf.getCirMinBps();
    }

    public long getAnalysisCirMaxBps(String anlName) {
        ServerAnalysisConfig anconf = this.analysisConfigs.get(anlName);
        if (anconf == null) {
            System.err.println("getAnalysisCirMaxBps: No analysis with name: " + anlName);
            return 0;
        }
        return anconf.getCirMaxBps();
    }

    public long getAnalysisEirMinBps(String anlName) {
        ServerAnalysisConfig anconf = this.analysisConfigs.get(anlName);
        if (anconf == null) {
            System.err.println("getAnalysisEirMinBps: No analysis with name: " + anlName);
            return 0;
        }
        return anconf.getEirMinBps();
    }

    public long getAnalysisEirMaxBps(String anlName) {
        ServerAnalysisConfig anconf = this.analysisConfigs.get(anlName);
        if (anconf == null) {
            System.err.println("getAnalysisEirMaxBps: No analysis with name: " + anlName);
            return 0;
        }
        return anconf.getEirMaxBps();
    }

    public long getAnalysisFrameDelayMinUs(String anlName) {
        ServerAnalysisConfig anconf = this.analysisConfigs.get(anlName);
        if (anconf == null) {
            System.err.println("getAnalysisFrameDelayMinUs: No analysis with name: " + anlName);
            return 0;
        }
        return anconf.getFrameDelayMinUs();
    }

    public long getAnalysisFrameDelayMaxUs(String anlName) {
        ServerAnalysisConfig anconf = this.analysisConfigs.get(anlName);
        if (anconf == null) {
            System.err.println("getAnalysisFrameDelayMaxUs: No analysis with name: " + anlName);
            return 0;
        }
        return anconf.getFrameDelayMaxUs();
    }

    public long getAnalysisIfdvMinUs(String anlName) {
        ServerAnalysisConfig anconf = this.analysisConfigs.get(anlName);
        if (anconf == null) {
            System.err.println("getAnalysisIfdvMinUs: No analysis with name: " + anlName);
            return 0;
        }
        return anconf.getIfdvMinUs();
    }

    public long getAnalysisIfdvMaxUs(String anlName) {
        ServerAnalysisConfig anconf = this.analysisConfigs.get(anlName);
        if (anconf == null) {
            System.err.println("getAnalysisIfdvMaxUs: No analysis with name: " + anlName);
            return 0;
        }
        return anconf.getIfdvMaxUs();
    }

    
    public int getAnalysisPathCount(String anlName) {
        ServerAnalysisConfig anconf = this.analysisConfigs.get(anlName);
        if (anconf == null) {
            System.err.println("getAnalysisPathCount: No analysis with name: " + anlName);
            return 0;
        }
        return anconf.getPathCount();
    }

    public long getAnalysisSamplingPeriodMs(String anlName) {
        ServerAnalysisConfig anconf = this.analysisConfigs.get(anlName);
        if (anconf == null) {
            System.err.println("getAnalysisSamplingPeriodMs: No analysis with name: " + anlName);
            return 0;
        }
        return anconf.getSamplingPeriodMs();
    }

}
