package com.telesat.services.simulation;

import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass;

/* Delegating class for Spacetime Simulation */
public class SimulationDelegation
{
    SimulationOuterClass.Simulation delegatedSimulation;

    String simulationId;

    com.google.longrunning.Operation currentOperation;

    /* Just to keep the progress percent for prototype behavior */
    double progessPercent;

    /* Assumed duration in seconds that takes on running.
       (it is assumed that it could be different simulation's given interval-duration) */
    double assumedDurationSec;

    /* Relative start time to be able to calculate remaining time */
    long startTimeInMs;

    public SimulationDelegation(String id, SimulationOuterClass.Simulation simulation) {
        this.simulationId = id;
        this.delegatedSimulation = simulation;
        this.currentOperation = null;
        this.progessPercent = 0;
        this.assumedDurationSec = 0;
        this.startTimeInMs = System.currentTimeMillis();
    }

    public SimulationDelegation(String id, SimulationOuterClass.Simulation simulation, 
                                com.google.longrunning.Operation op, double progPercent) {
        this.simulationId = id;
        this.delegatedSimulation = simulation;
        this.currentOperation = op;
        this.progessPercent = progPercent;
        this.assumedDurationSec = 0;
        this.startTimeInMs = System.currentTimeMillis();
    }

    public SimulationOuterClass.Simulation getSimulation() {
        return this.delegatedSimulation;
    }
        
    public void setSimulation(SimulationOuterClass.Simulation sim) {
        this.delegatedSimulation = sim;
    }

    public String getSimulationId() {
        return this.simulationId;
    }

    public double getProgressPercent() {
        return this.progessPercent;
    }

    public void setProgressPercent(double value) {
        this.progessPercent = value;
    }

    public double calculateProgressPercent() {
        double passed = (double)(System.currentTimeMillis() - this.startTimeInMs) / 1000;
        double remaining = this.assumedDurationSec - passed;
        //double percent = ((passed * SimulationServer.SCHEDULER_TICK_SEC) / this.assumedDurationSec) * 100;
        double percent = (passed / this.assumedDurationSec) * 100;

        System.out.println("Simulation: " + this.delegatedSimulation.getName() + " dur: " + this.assumedDurationSec +
                           " passed: " + passed + " remaining: " + remaining + " percent: " + percent);
        return percent;
    }

    public void setAssumedDurationInSec(double dur) {
        this.assumedDurationSec = dur;
    }

    public com.google.longrunning.Operation getCurrentOperation() {
        return this.currentOperation;
    }

    public void setCurrentOperation(com.google.longrunning.Operation op) {
        this.currentOperation = op;
    }
}
