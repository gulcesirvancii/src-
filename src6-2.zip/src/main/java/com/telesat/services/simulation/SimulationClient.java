package com.telesat.services.simulation;

import java.util.Scanner;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;
import java.util.LinkedHashMap;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;
import io.grpc.Grpc;
import io.grpc.InsecureChannelCredentials;
import io.grpc.StatusRuntimeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aalyria.spacetime.simulation.v1alpha.SimulationServiceGrpc;
import com.google.longrunning.Operation;
import com.google.protobuf.InvalidProtocolBufferException;
import com.telesat.services.feasibility.CIR_Calc;
import com.telesat.services.feasibility.ThroughputAvailabilityPair;
import com.telesat.services.provisioning.ProvisioningResources;
import com.telesat.services.provisioning.SimulationProvisioning;
import com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass;

public class SimulationClient {
    private static final Logger logger = LoggerFactory.getLogger(SimulationClient.class);
    
    private final ManagedChannel channel;
    private final SimulationServiceGrpc.SimulationServiceBlockingStub blockingStub;
    private final SimulationServiceGrpc.SimulationServiceStub asyncStub;
    
    private SimulationConfiguration conf;
    private SimulationProvisioning  prov;
    
    Map<String, ScenarioDelegation> scenariosWithId = new LinkedHashMap<>();
    Map<String, ScenarioDelegation> scenariosWithName = new LinkedHashMap<>();

    Map<String, SimulationDelegation> simulationsWithId = new LinkedHashMap<>();
    Map<String, SimulationDelegation> simulationsWithName = new LinkedHashMap<>();

    //private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();

    /* To keep path based CIR-average stats provided through Analysis.
       The key is the path-name. 
       LinkedHasMap is used to have insertion-ordered data which is 
       effective on iteration (iteration order) 
       NOTE: We use ArrayList to store values wit assumption that a path
             may not be included in some AnalysisSegment, so if we use
             Double[], some values may have zero value. But, in this way
             we skip some possible 'no-value' cases (!?)
    */ 
    Map<String, ArrayList<Double>> pathStats = new LinkedHashMap<>();

    /* To be used for ending the client. 
       No need with a 'menu' based implementation. */
    AtomicInteger runningJobs; 

    /* selected simulation polling method */
    int simPollingMethod;
    /* Constants for simulation polling methods */
    static final int SIMPOLL_METHOD_ONEBYONE  = 0;
    static final int SIMPOLL_METHOD_RUNNABLE  = 1;
    static final int SIMPOLL_METHOD_SCHEDULER = 2;

    /**
     * Construct client connecting to the server at {@code host:port}.
     */
    public SimulationClient(String host, int port) {
        this(ManagedChannelBuilder.forAddress(host, port)
                // Channels are secure by default (via SSL/TLS). For the example we disable TLS to avoid
                // needing certificates.
                .usePlaintext()
                .build());
    }

    
    /**
     * Construct client for accessing SimulationService using the existing channel.
     */
    SimulationClient(ManagedChannel channel) {
        this.channel = channel;
        blockingStub = SimulationServiceGrpc.newBlockingStub(channel);
        asyncStub = SimulationServiceGrpc.newStub(channel);
    }
    
    /**
     * Shutdown the channel
     */
    public void shutdown() throws InterruptedException {
        channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
    }
    
    public int createScenario(String scenarioId, String scenarioName, String description) {
        logger.info("Creating scenario: '{}' with name: '{}' with desription: '{}'", 
                    scenarioId, scenarioName, description);

        SimulationOuterClass.Scenario sc = SimulationOuterClass.Scenario.newBuilder()
                                                                        .setName(scenarioName)
                                                                        .setDescription(description)
                                                                        .build();
        SimulationOuterClass.CreateScenarioRequest request = SimulationOuterClass.CreateScenarioRequest.newBuilder()
                                                                                                       .setScenarioId(scenarioId)
                                                                                                       .setScenario(sc)
                                                                                                       .build();
        
        try {
            SimulationOuterClass.Scenario response = blockingStub.createScenario(request);
            logger.info("CreateScenario response: scenario-name='{}', description='{}'", 
                        response.getName(), response.getDescription());
        } 
        catch (StatusRuntimeException e) {
            logger.error("RPC failed: {}", e.getStatus());
            return 1;
        }

        return 0;
    } 

    /* Creates a scenario instance at server side for 'scenarioName' with 'description' in 
       blocking operation mode. It returns the instance of scenario responded by the server
     */
    public SimulationOuterClass.Scenario createScenarioInstance(String scenarioId, String scenarioName, String description) {

        logger.info("Creating scenario: '{}' with name: '{}' with desription: '{}'", 
                    scenarioId, scenarioName, description);

        SimulationOuterClass.Scenario sc = SimulationOuterClass.Scenario.newBuilder()
                                                                        .setName(scenarioName)
                                                                        .setDescription(description)
                                                                        .build();
        SimulationOuterClass.CreateScenarioRequest request = SimulationOuterClass.CreateScenarioRequest.newBuilder()
                                                                                                       .setScenarioId(scenarioId)
                                                                                                       .setScenario(sc)
                                                                                                       .build();
        SimulationOuterClass.Scenario response = null;
        try {
            response = blockingStub.createScenario(request);
            logger.info("CreateScenario response: scenario-name='{}', description='{}'", 
                        response.getName(), response.getDescription());
        } 
        catch (StatusRuntimeException e) {
            logger.error("RPC failed: {}", e.getStatus());
            return null;
        }

        return response;
    } 

    /* proto format of GetScenario:
     * message GetScenarioRequest {
     *   // Required. The name of the scenario to retrieve.
     *   // Format: scenarios/{scenario}
     *   string name = 1;
     * }
     * We consider 'scenarioName' is not int the for above, so it will be prefixed with 'scenarios/'
     */
    public SimulationOuterClass.Scenario getScenario(String scenarioName) {
        logger.info("Get scenario with name: '{}'", scenarioName);

        String formedScName = "scenarios/" + scenarioName;
        SimulationOuterClass.GetScenarioRequest request = SimulationOuterClass.GetScenarioRequest.newBuilder()
                                                                                                 .setName(formedScName)
                                                                                                 .build();
        try {
            SimulationOuterClass.Scenario response = blockingStub.getScenario(request);
            logger.info("GetScenario response: scenario-name='{}', description='{}'", 
                        response.getName(), response.getDescription());
            return response;
        } 
        catch (StatusRuntimeException e) {
            logger.error("RPC failed: {}", e.getStatus());
            /* Return an empty Scenario instance */
            return SimulationOuterClass.Scenario.newBuilder().setName("").build();
        }
    }

    /* Creates Simulation instance with specified attributes, 
     * which is ready for sending create-simulation request to the server.
     * 'startSeconds' and 'startNanos', 'endSeconds' and 'endTime' shall indicate timestamps for the 'interval'
     * */
    public SimulationOuterClass.Simulation createLocalSimulationInstance(String simulationName, long startSeconds, 
                                                                         int startNanos, long endSeconds, int endNanos) {

        logger.info("Create simulation with simulation-name: '{}', start-seconds: '{}', start-nanos: '{}', end-seconds: '{}', end-nanos: '{}'",
                    simulationName, startSeconds, startNanos, endSeconds, endNanos);

        com.google.protobuf.Timestamp stimestamp = com.google.protobuf.Timestamp.newBuilder().setSeconds(startSeconds).setNanos(startNanos).build();
        com.google.protobuf.Timestamp etimestamp = com.google.protobuf.Timestamp.newBuilder().setSeconds(endSeconds).setNanos(endNanos).build();
        
        String simname = "simulations/" + simulationName;
        com.google.type.Interval interval = com.google.type.Interval.newBuilder().setStartTime(stimestamp).setEndTime(etimestamp).build();
        /* 'scenario' attribute will be assigned when this simuation is attached to a scenario */
        return SimulationOuterClass.Simulation.newBuilder().setName(simname).setInterval(interval).build();
    }

    /* Sends a create-smimulation request to the server for creation a simulation for the scenario specified with 'scenarioName' */
    public com.google.longrunning.Operation createSimulationForScenario(String scenarioName, String simulationId, SimulationOuterClass.Simulation simulation) {

        logger.info("Create simulation with scenario-name: '{}', simulation-id: '{}', name: '{}', start-time: '{}', end-time: '{}'",
                    scenarioName, simulationId, simulation.getName(), 
                    simulation.getInterval().getStartTime().getSeconds() + "_" + simulation.getInterval().getStartTime().getNanos(),
                    simulation.getInterval().getEndTime().getSeconds() + "_" + simulation.getInterval().getEndTime().getNanos());

        String snname = "scenarios/" + scenarioName;
        /* TODO: This method (update fields of a built message) may not be good way for realtime performance purposes. 
                 We may choose another approach. 
         */
        SimulationOuterClass.Simulation upsim = simulation.toBuilder().setScenario(snname).build(); 
        SimulationOuterClass.CreateSimulationRequest request = SimulationOuterClass.CreateSimulationRequest.newBuilder()
                                                                                                           .setSimulationId(simulationId)
                                                                                                           .setSimulation(upsim)
                                                                                                           .build();
        try {
            com.google.longrunning.Operation response = blockingStub.createSimulation(request);
            logger.info("Response to CreateSimulationRequest: operation-name='{}', is-done:='{}', code='{}'", 
                        response.getName(), response.getDone(), response.getError().getCode());
            return response;
        } 
        catch (StatusRuntimeException e) {
            logger.error("RPC failed: {}", e.getStatus());
            /* Return an errored operation. */
            com.google.rpc.Status status = com.google.rpc.Status.newBuilder()
                                                                .setCode(com.google.rpc.Code.DEADLINE_EXCEEDED_VALUE)
                                                                .setMessage("Runtime exception: " + e.getMessage())
                                                                .build();
            return com.google.longrunning.Operation.newBuilder().setName("").setDone(true).setError(status).build();
        }
    }

    /* Creates a simulation instance in local through date provided in 'config' and sends CreateSimulation request 
       to the server. Upon successfull long-operation response, it creates delegation instance for simulation  */
    public SimulationDelegation createSimulationFromConfig(SimulationConfiguration.SimulationConfig config) {

        Instant simSt = config.getStartTimeAsInstant();
        Instant simEt = config.getEndTimeAsInstant();
        String simulationName = config.getName();
        SimulationOuterClass.Simulation sim  = createLocalSimulationInstance(simulationName, 
                                                                             simSt.getEpochSecond(), simSt.getNano(), 
                                                                             simEt.getEpochSecond(), simEt.getNano());
        String scenarioName = config.getScenario();
        String simulationId = simulationName + "--" + UUID.randomUUID();
        com.google.longrunning.Operation op1 = createSimulationForScenario(scenarioName, simulationId, sim);
        logger.info("Result of simulation creation -- operation-nmae: '{}', is-done: '{}'",
                    op1.getName(), op1.getDone());
        double progressPercent = 0;
        try {
            if ((op1.hasMetadata()) && (op1.getMetadata().is(SimulationOuterClass.CreateSimulationMetadata.class))) {
                SimulationOuterClass.CreateSimulationMetadata metadata = op1.getMetadata().unpack(SimulationOuterClass.CreateSimulationMetadata.class);
                progressPercent = metadata.getProgressPercent();
                logger.info("Received percentage of processing through metadata: '{}%'", progressPercent);
            }
        }
        catch (InvalidProtocolBufferException ex) {
            logger.error("Exception occurred on proccessing metadata {}", ex.getMessage());
            return null;
        }
        SimulationDelegation simdlg = new SimulationDelegation(simulationId, sim, op1, progressPercent);
        
        return simdlg;
    }

    /* Although it is not clear that 'name' attribute shall be based on simulation-id used during creation or name attribute
       of the simulation, we consider it as name attribute */
    public SimulationOuterClass.Simulation getSimulation(String simulationName) {
        logger.info("Get simulation with name: '{}'", simulationName);

        String formedSimName = "simulations/" + simulationName;
        SimulationOuterClass.GetSimulationRequest request = SimulationOuterClass.GetSimulationRequest.newBuilder()
                                                                                                     .setName(formedSimName)
                                                                                                     .build();
        try {
            SimulationOuterClass.Simulation response = blockingStub.getSimulation(request);
            logger.info("getSimulation response: simulation-name='{}', scenario-name='{}', state='{}', " +
                        "create-timestamp='{}', interval=(start='{}_{}', end='{}_{})", 
                        response.getName(), response.getScenario(), response.getState(), response.getCreateTime(), 
                        response.getInterval().getStartTime().getSeconds(), response.getInterval().getStartTime().getNanos(),
                        response.getInterval().getEndTime().getSeconds(), response.getInterval().getEndTime().getNanos());
            return response;
        } 
        catch (StatusRuntimeException e) {
            logger.error("RPC failed: {}", e.getStatus());
            /* Return an empty Scenario instance */
            return SimulationOuterClass.Simulation.newBuilder().setName("").build();
        }

    }

    /* Creates an Analysis instance for local usage, from client side point of view */
    public SimulationOuterClass.Analysis constructAnalysis(String scenarioName, String analysisName, 
                                                            com.google.type.Interval interval, com.google.protobuf.Duration resolution) {

        logger.info("Constructing Analysis object for scenario: '{}' with name: '{}' for start: '{}_{}' and end: '{}_{}' interval with resolution: '{}_{}'",
                    scenarioName, analysisName, interval.getStartTime().getSeconds(), interval.getStartTime().getNanos(),
                    interval.getEndTime().getSeconds(), interval.getEndTime().getNanos(),
                    resolution.getSeconds(), resolution.getNanos());

        // name shall be in the form of 'scenarios/{scenario}/analyses/{analysis}'
        String name = "scenarios/" + scenarioName + "/analyses/" + analysisName;
        return SimulationOuterClass.Analysis.newBuilder()
                                            .setName(name)
                                            .setInterval(interval)
                                            .setResolution(resolution)
                                            .build();
    }

    /* 'parent' shall be in the form of 'simulations/{simulation}' as indicating the simulation in which this analysis will be created. */
    public SimulationOuterClass.Analysis createAnalysis(String simulation, String id, SimulationOuterClass.Analysis analysis) {

        logger.info("Create analysis with id: '{}' and name: '{}' for simulation: '{}' with interval: '{}_{}-{}_{}' and resolution: '{}_{}'",
                    id, analysis.getName(), simulation, 
                    analysis.getInterval().getStartTime().getSeconds(), analysis.getInterval().getStartTime().getNanos(), 
                    analysis.getInterval().getEndTime().getSeconds(), analysis.getInterval().getEndTime().getNanos(),
                    analysis.getResolution().getSeconds(), analysis.getResolution().getNanos());

        /* 'parent' of the request shall be in the form of 'simulations/{simulation}' */
        String parent = "simulations/" + simulation;
        SimulationOuterClass.CreateAnalysisRequest request = SimulationOuterClass.CreateAnalysisRequest.newBuilder()
                                                                                                       .setParent(parent)
                                                                                                       .setAnalysisId(id)
                                                                                                       .setAnalysis(analysis)
                                                                                                       .build();

        try {
            SimulationOuterClass.Analysis response = blockingStub.createAnalysis(request);
            logger.info("Got response for 'createAnalysis with name: '{}' ", response.getName());
            return response;
        }
        catch (StatusRuntimeException e) {
            logger.error("createAnalysis: RPC failed: {}", e.getStatus());
            /* Return an empty Scenario instance */
            return null; 
        }
    }

    public SimulationOuterClass.Analysis getAnalysis(String analysisName, String parentSimulation) {
        logger.info("getAnalysis: Get request for analysis: '{}' for parent simulation: '{}'", analysisName, parentSimulation);

        /* 'name' of the request shall be in the form of 'simulations/{simulation}/analyses/{analysis}' */
        String name = "simulations/" + parentSimulation + "/analyses/" + analysisName;
        SimulationOuterClass.GetAnalysisRequest request = SimulationOuterClass.GetAnalysisRequest.newBuilder()
                                                                                                 .setName(name)
                                                                                                 .build();
        try {
            SimulationOuterClass.Analysis response = blockingStub.getAnalysis(request);
            logger.info("Got response for 'getAnalysis with name: '{}' ", response.getName());
            return response;
        }
        catch (StatusRuntimeException e) {
            logger.error("getAnalysis: RPC failed: {}", e.getStatus());
            /* Return an empty Scenario instance */
            return null; 
        }
    }

    @SuppressWarnings("unused")
    public void putIntoPathData(String pathName, int asegmentIdx, int pathIdx, double value) {
       ArrayList<Double> vals = this.pathStats.computeIfAbsent(pathName, k -> new ArrayList<Double>());
       vals.add(value);
    }

    /* Logs details of analysis and to process on provided anaysis data as collecting CIR average values into 'pathStats' per path */
    public void detailsOfAnalysis(SimulationOuterClass.Analysis analysis) {
        List<SimulationOuterClass.AnalysisSegment> analysisList = analysis.getSegmentsList();
        int anSegmentCount = (analysisList != null) ? analysisList.size() : 0;
        logger.info("detailsOfAnaysis: Successfully created Analysis with name: '{}', analysis-segment count: '{}'", analysis.getName(), anSegmentCount);
        for (int i = 0; i < anSegmentCount; i++) {
            SimulationOuterClass.AnalysisSegment aSegment = analysisList.get(i);
            List<SimulationOuterClass.P2pSrTePolicyCandidatePathStats> paths = aSegment.getP2PSrTePolcyCandidatePathStatsList();
            logger.info("detailsOfAnalysis: Number of paths: '{}'", paths.size());
            for (int j = 0; j < paths.size(); j++) {
                SimulationOuterClass.P2pSrTePolicyCandidatePathStats stats = paths.get(j);
                putIntoPathData(stats.getPath(), i, j, stats.getCirAvgBps());
                logger.info("detailsOfAnalysis: path({}) stats [{}, {}] -- \n" +
                            "    CIR.average: '{}', CIR.stddev: '{}', CIR.min: '{}', CIR.max: '{}', CIR.percentile: '{}'\n" +
                            "    EIR.average: '{}', EIR.stddev: '{}', EIR.min: '{}', EIR.max: '{}', EIR.percentile: '{}'\n" +
                            "    FD.average: '{}_{}', FD.stddev: '{}_{}', FD.min: '{}_{}', FD.max: '{}_{}', FD.percentile: '{}'\n" +
                            "    IFDV.average: '{}_{}', IFDV.stddev: '{}_{}', IFDV.min: '{}_{}', IFDV.max: '{}_{}', IFDV.percentile: '{}'\n",
                            stats.getPath(), i, j,
                            String.format("%.3f", stats.getCirAvgBps()), String.format("%.3f", stats.getCirStddevBps()), 
                            String.format("%.3f", stats.getCirMinBps()), String.format("%.3f", stats.getCirMaxBps()), String.format("%.3f", stats.getCirPercentile()),
                            String.format("%.3f", stats.getEirAvgBps()), String.format("%.3f", stats.getEirStddevBps()), 
                            String.format("%.3f", stats.getEirMinBps()), String.format("%.3f", stats.getEirMaxBps()), String.format("%.3f", stats.getEirPercentile()),
                            stats.getFrameDelayAvg().getSeconds(), stats.getFrameDelayAvg().getNanos(), 
                            stats.getFrameDelayStddev().getSeconds(), stats.getFrameDelayStddev().getNanos(),
                            stats.getFrameDelayMin().getSeconds(), stats.getFrameDelayMin().getNanos(),
                            stats.getFrameDelayMax().getSeconds(), stats.getFrameDelayMax().getNanos(),
                            stats.getFrameDelayPercentile(),
                            stats.getIfdvAvg().getSeconds(), stats.getIfdvAvg().getNanos(), 
                            stats.getIfdvStddev().getSeconds(), stats.getIfdvStddev().getNanos(),
                            stats.getIfdvMin().getSeconds(), stats.getIfdvMin().getNanos(),
                            stats.getIfdvMax().getSeconds(), stats.getIfdvMax().getNanos(),
                            stats.getIfdvPercentile());
            }
        }
        /* Dump collected CIR averages per path */
        System.out.println("Collected path data:\n" + this.pathStats);
    }

    public long determineSlaCirValue(String analysisName, String simulationName) {
        /* Returns SLA-CIR value configured for analysis or simulation. 
           Configuration for analysis has priority over the one of simulation */
        long slaCir = this.conf.getAnalysisSlaCir(analysisName);
        if (slaCir == 0) {
            slaCir = this.conf.getSimulationSlaCir(simulationName);
        }
        if (slaCir == 0) {
            logger.error("determineSlaCir: No SLA-CIR value configured either analysis: '{}' or simulation: '{}'", analysisName, simulationName);
        }
        return slaCir;
    }

    public ThroughputAvailabilityPair[] determineThroughputAvailabilityPairs(String analysisName, String simulationName) {
        /* Returns TA-pairt configured for analysis or simulation. 
           Configuration for analysis has priority over the one of simulation */
        ThroughputAvailabilityPair[] taPairs = this.conf.getAnalysisTAPairs(analysisName);
        if (taPairs.length == 0) {
            taPairs = this.conf.getSimulationTAPairs(simulationName);
        }
        if (taPairs.length == 0) {
            logger.error("determineThroughputAvailabilityPairs: No SLA-CIR value configured either analysis: '{}' or simulation: '{}'", 
                         analysisName, simulationName);
        }
        StringBuilder logstr = new StringBuilder();
        double total = 0.0;
        for (int i = 0; i < taPairs.length; i++) {
            logstr.append("[").append(Integer.toString(i)).append("]: ").append(taPairs[i]).append("\n");
            total += taPairs[i].getThroughput();
        }
        logger.info("Total: {}\n {}", total, logstr);
        return taPairs;
    }

    /**
     * Run a complete simulation workflow
     * @throws InterruptedException 
     * @throws InvalidProtocolBufferException 
     */
    public void runSimulationWorkflow() throws InterruptedException, InvalidProtocolBufferException {
        String scenarioId = "test-scenario-1:" + System.currentTimeMillis();
        String scenarioName = "test-scenario-1";
        String scenarioDescription = "Test for Spacetime scenario API.";

        String simulationName = "test-simulation-1";
        String simulationId = simulationName + ":" + System.currentTimeMillis();

        logger.info("=== Starting Simulation Workflow ===");
        
        // 1. Create scenario
        createScenario(scenarioId, scenarioName, scenarioDescription);
        Thread.sleep(1000);
        // Second try to create
        createScenario(scenarioId, scenarioName, scenarioDescription);
        
        // Get scenario
        SimulationOuterClass.Scenario gsc = getScenario(scenarioName);
        logger.info("Got scenario for name: '{}' -- scenario-name: '{}', description: '{}'",
                    scenarioName, gsc.getName(), gsc.getDescription());

        // 3. Create Simulation
        /* TODO: 'seconds' and 'nanos' for time values shall be provided through DateTime objects for both start-time and end-time */
        // If we compute Timestamp from`System.currentTimeMillis()`.
        long millis = System.currentTimeMillis();
        long seconds = millis/ 1000;
        int nanos = (int)((millis % 1000) * 1000000);
        logger.info("Timestamps by using currentTimeMillis: seconds: '{}', nanos: '{}'", seconds, nanos);
        // If we compute Timestamp from `Instant.now()`.
        Instant now = Instant.now();
        seconds = now.getEpochSecond();
        nanos = now.getNano();
        logger.info("Timestamps by using Instant.now(): seconds: '{}', nanos: '{}'", seconds, nanos);
        /* Create simulation  */
        Instant simSt = this.conf.getSimulationStartTimeAsInstant(simulationName);
        Instant simEt = this.conf.getSimulationEndTimeAsInstant(simulationName);
        SimulationOuterClass.Simulation sim  = createLocalSimulationInstance(simulationName, 
                                                                             simSt.getEpochSecond(), simSt.getNano(), 
                                                                             simEt.getEpochSecond(), simEt.getNano());
                                                    
        com.google.longrunning.Operation op1 = createSimulationForScenario(scenarioName, simulationId, sim);
        logger.info("Result of simulation creation -- operation-nmae: '{}', is-done: '{}'",
                    op1.getName(), op1.getDone());
        if ((op1.hasMetadata()) && (op1.getMetadata().is(SimulationOuterClass.CreateSimulationMetadata.class))) {
            SimulationOuterClass.CreateSimulationMetadata metadata = op1.getMetadata().unpack(SimulationOuterClass.CreateSimulationMetadata.class);
            logger.info("Received percentage of processing through metadata: '{}%'", metadata.getProgressPercent());
        }

        // 3a. Re-create simulation (to test progress-percent increase)
        op1 = createSimulationForScenario(scenarioName, simulationId, sim);
        logger.info("(2) Result of simulation creation -- operation-name: '{}', is-done: '{}'",
                    op1.getName(), op1.getDone());
        if ((op1.hasMetadata()) && (op1.getMetadata().is(SimulationOuterClass.CreateSimulationMetadata.class))) {
            SimulationOuterClass.CreateSimulationMetadata metadata = op1.getMetadata().unpack(SimulationOuterClass.CreateSimulationMetadata.class);
            logger.info("(2): Received percentage of processing through metadata: '{}%'", metadata.getProgressPercent());
        }

        // 3b. Re-create simulation (to test progress-percent increase)
        op1 = createSimulationForScenario(scenarioName, simulationId, sim);
        logger.info("(3) Result of simulation creation -- operation-name: '{}', is-done: '{}'",
                    op1.getName(), op1.getDone());
        if ((op1.hasMetadata()) && (op1.getMetadata().is(SimulationOuterClass.CreateSimulationMetadata.class))) {
            SimulationOuterClass.CreateSimulationMetadata metadata = op1.getMetadata().unpack(SimulationOuterClass.CreateSimulationMetadata.class);
            logger.info("(3): Received percentage of processing through metadata: '{}%'", metadata.getProgressPercent());
        }

        // Get Simulation
        SimulationOuterClass.Simulation gsim  = getSimulation(simulationName);
        logger.info("Received simulation due to 'getSimulation' with name: '{}'", gsim.getName());

        // Create anaysis
        String analysisName = "test-analysis-1.1";
        /* TODO: Interval and resolution parameters shall be built through DateTime objects */
        /* Use time interval determined for simulation */
        Instant anlSt = this.conf.getAnalysisStartTimeAsInstant(analysisName);
        Instant anlEt = this.conf.getAnalysisEndTimeAsInstant(analysisName);
        com.google.protobuf.Timestamp istt = com.google.protobuf.Timestamp.newBuilder().setSeconds(anlSt.getEpochSecond()).setNanos(anlSt.getNano()).build();
        com.google.protobuf.Timestamp iett = com.google.protobuf.Timestamp.newBuilder().setSeconds(anlEt.getEpochSecond()).setNanos(anlEt.getNano()).build();

        com.google.type.Interval anInterval = com.google.type.Interval.newBuilder().setStartTime(istt).setEndTime(iett).build();

        Duration anlResDur = this.conf.getAnalysisResolutionAsDuration(analysisName); 
        com.google.protobuf.Duration anResolution = com.google.protobuf.Duration.newBuilder().setSeconds(anlResDur.getSeconds())
                                                                                             .setNanos(anlResDur.getNano()).build();
        SimulationOuterClass.Analysis anInstance = constructAnalysis(scenarioName, analysisName, anInterval, anResolution);

        String analysisId = analysisName + ":" + System.currentTimeMillis();
        SimulationOuterClass.Analysis analysis = createAnalysis(simulationName, analysisId, anInstance);
        if (analysis == null) {
            logger.warn("Cannot create an Analysis successfully with name: '{}' for simulation: '{}' of scenario: '{}'",
                        analysisName, simulationName, scenarioName);
        }
        else {
            List<SimulationOuterClass.AnalysisSegment> analysisList = analysis.getSegmentsList();
            int anSegmentCount = (analysisList != null) ? analysisList.size() : 0;
            logger.info("Successfully created Analysis with name: '{}', analysis-segment count: '{}'", analysisName, anSegmentCount);
            detailsOfAnalysis(analysis);
            long slaCIR = determineSlaCirValue(analysisName, simulationName);
            ThroughputAvailabilityPair[] taPairs =  determineThroughputAvailabilityPairs(analysisName, simulationName);
            for (Map.Entry<String, ArrayList<Double>> entry : this.pathStats.entrySet()) {
                logger.info("Calculation CIR for path: '{}' -- {}", entry.getKey(), entry.getValue());
                /* We need to convert the data to primitive double[] */
                double[] tputs = java.util.Arrays.stream(entry.getValue().toArray(new Double[0]))
                                          .mapToDouble(Double::doubleValue)
                                          .toArray();

                boolean feasibility = CIR_Calc.CalculateCIRFeasibility(tputs, 0, tputs.length, false, taPairs,
                                                                       95.0, 99.0, slaCIR);
                logger.info("Path <{}> is {}", entry.getKey(), ((feasibility) ? "feasible" : "infeasible"));
            }
        }

        
        long diff = anInterval.getEndTime().getSeconds() - anInterval.getStartTime().getSeconds();
        logger.info("Diff: '{}'", diff);

        // Get Analysis
        SimulationOuterClass.Analysis ganalysis = getAnalysis(analysisName, simulationName);
        if (ganalysis == null) {
            logger.warn("Cannot get an Analysis successfully with name: '{}' for simulation: '{}'",
                        analysisName, simulationName);
        }
        else {
            logger.info("Successfully get Analysis with name: '{}'", ganalysis.getName());
        }

        logger.info("=== Simulation Workflow Complete ===");
    }

    public void readConfiguration(String confFileName) {
        this.conf = new SimulationConfiguration(confFileName);
        this.conf.parseForJson();
    }

    private void simulationIsCompleted(String simulationName) {
        /* Simulation is completed at server side. Try to get analyses and process them */
        logger.info("-------------- Processing anayses for simulation '{}' ------------------", simulationName);
        for (Map.Entry<String, SimulationConfiguration.AnalysisConfig> entry : this.conf.getAnalyses()) {
            if (simulationName.equals(entry.getValue().getSimulation())) {
                /* Analysis configured for the simulation */
                logger.info("Requesting analysis results for analysis '{}' of simulation '{}'", entry.getValue().name, simulationName);
                String analysisName = entry.getValue().name;
                SimulationDelegation simdlg = this.simulationsWithName.get(simulationName);
                
                String scenarioName = this.conf.getSimulationScenarioName(simulationName);
                Instant anlSt = this.conf.getAnalysisStartTimeAsInstant(analysisName);
                Instant anlEt = this.conf.getAnalysisEndTimeAsInstant(analysisName);
                com.google.protobuf.Timestamp istt = com.google.protobuf.Timestamp.newBuilder()
                                                                                  .setSeconds(anlSt.getEpochSecond())
                                                                                  .setNanos(anlSt.getNano())
                                                                                  .build();
                com.google.protobuf.Timestamp iett = com.google.protobuf.Timestamp.newBuilder()
                                                                                  .setSeconds(anlEt.getEpochSecond())
                                                                                  .setNanos(anlEt.getNano())
                                                                                  .build();

                com.google.type.Interval anInterval = com.google.type.Interval.newBuilder()
                                                                              .setStartTime(istt)
                                                                              .setEndTime(iett)
                                                                              .build();

                Duration anlResDur = this.conf.getAnalysisResolutionAsDuration(analysisName); 
                com.google.protobuf.Duration anResolution = com.google.protobuf.Duration.newBuilder()
                                                                                        .setSeconds(anlResDur.getSeconds())
                                                                                        .setNanos(anlResDur.getNano())
                                                                                        .build();
                SimulationOuterClass.Analysis anInstance = constructAnalysis(scenarioName, analysisName, anInterval, anResolution);

                String analysisId = analysisName + ":" + System.currentTimeMillis();
                SimulationOuterClass.Analysis analysis = createAnalysis(simulationName, analysisId, anInstance);
                if (analysis == null) {
                    logger.warn("Cannot create an Analysis successfully with name: '{}' for simulation: '{}' of scenario: '{}'",
                                analysisName, simulationName, scenarioName);
                }
                else {
                    List<SimulationOuterClass.AnalysisSegment> analysisList = analysis.getSegmentsList();
                    int anSegmentCount = (analysisList != null) ? analysisList.size() : 0;
                    logger.info("Successfully created Analysis with name: '{}', analysis-segment count: '{}'", analysisName, anSegmentCount);
                    detailsOfAnalysis(analysis);
                    long slaCIR = determineSlaCirValue(analysisName, simulationName);
                    ThroughputAvailabilityPair[] taPairs =  determineThroughputAvailabilityPairs(analysisName, simulationName);
                    for (Map.Entry<String, ArrayList<Double>> pentry : this.pathStats.entrySet()) {
                        logger.info("Calculation CIR for path: '{}' -- {}", pentry.getKey(), pentry.getValue());
                        /* We need to convert the data to primitive double[] */
                        double[] tputs = java.util.Arrays.stream(pentry.getValue().toArray(new Double[0]))
                                                         .mapToDouble(Double::doubleValue)
                                                         .toArray();

                        boolean feasibility = CIR_Calc.CalculateCIRFeasibility(tputs, 0, tputs.length, false, taPairs,
                                                                           95.0, 99.0, slaCIR);
                        logger.info("Path <{}> is {}", pentry.getKey(), ((feasibility) ? "feasible" : "infeasible"));
                    }
                }

            }
        }
    }

    private void pollSimulationUntilDone(String simulationName, ScheduledExecutorService scheduler) {

        System.out.println("pollSimulationUntilDone: Polling the status of simulation: " + simulationName + " time: " + LocalDateTime.now());

        Runnable pollTask = () -> {
            try {
                SimulationOuterClass.Simulation sim = getSimulation(simulationName);

                if (sim.getState() == SimulationOuterClass.Simulation.State.SUCCEEDED) {
                    logger.info("Simulation '{}' is DONE...", simulationName);
                    simulationIsCompleted(simulationName);
                    logger.info("ENDING: Polling-Task-{} running for simulation '{}' and running jobs: {}", 
                                Thread.currentThread().threadId(), simulationName, runningJobs.decrementAndGet());
                    scheduler.shutdown();

                } 
                else {
                    System.out.println("Simulation '" + simulationName + "' still running, state=" + sim.getState() 
                                       + " time: " + LocalDateTime.now() + " -- " + Thread.currentThread().threadId() 
                                       + "(" + Thread.activeCount() + ")");
                }

            } 
            catch (Exception e) {
                System.out.println("Polling failed: " + e.getMessage());
            }
        };

        logger.info("STARTING: Polling-Task-{} running for simulation '{}' and running jobs: {}", 
                    Thread.currentThread().threadId(), simulationName, runningJobs.incrementAndGet());
        //scheduler.scheduleAtFixedRate(pollTask, 0, 3, TimeUnit.SECONDS);
        scheduler.scheduleWithFixedDelay(pollTask, 0, 3, TimeUnit.SECONDS);
    }

    private class SimulationStatusPolling implements Runnable {

        String simname;

        SimulationStatusPolling(String sname) {
            this.simname = sname;
        }

        @Override
        public void run() {
            int runningCount = runningJobs.incrementAndGet();
            logger.info("STARTING: Thread-{} running for simulation '{}' and running jobs: {}", 
                        Thread.currentThread().threadId(), simname, runningCount);
            int i = 0;
            while(true) {
                try {
                    SimulationOuterClass.Simulation sim = getSimulation(simname);
                    logger.info("SimulationStatusPolling({}): State of sim: '{}' is '{}'", i++, simname, sim.getState());
                    if (sim.getState() == SimulationOuterClass.Simulation.State.SUCCEEDED) {
                        logger.info("Simulation '{}' is DONE...", simname);
                        simulationIsCompleted(simname);
                        logger.info("ENDING: Thread-{} running for simulation '{}' and running jobs: {}", 
                                    Thread.currentThread().threadId(), simname, runningJobs.decrementAndGet());
                        break;
                    } 
                    else {
                        logger.info("Simulation '{}' still running, state= '{}' time: {} -- {}({})", simname, sim.getState(),
                                    LocalDateTime.now(), Thread.currentThread().threadId(), Thread.activeCount());
                        Thread.sleep(2000);
                    }
                }
                catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    logger.warn("Exception on runnable gor simulation '{}' -- {}", simname, ex.getMessage());
                }
            }
        }
    }

    public void runConfiguredFlow() throws InterruptedException {
        dumpScenarioConfigAndProvisioning();

        /* Create scenarios */
        logger.info("-------------- Creating scenarios ------------------");
        for (Map.Entry<String, SimulationConfiguration.ScenarioConfig> entry : this.conf.getScenarios()) {
            logger.info("Creating scenario with name: '{}' and full-value: '{}'", entry.getKey(), entry.getValue());
            String scenarioId = entry.getValue().getName() + "--" + UUID.randomUUID(); 
            SimulationOuterClass.Scenario sc = createScenarioInstance(scenarioId, entry.getValue().getName(), entry.getValue().getDescription());
            if (sc != null) {
                logger.info("Scenario '{}' successfully created with ID: '{}'", sc.getName(), scenarioId);
                ScenarioDelegation scdlg = new ScenarioDelegation(scenarioId, sc);
                this.scenariosWithId.put(scenarioId, scdlg);
                this.scenariosWithName.put(sc.getName(), scdlg);
            }
            else {
                logger.info("Cannot create Scenario '{}' successfully", entry.getValue().getName());
            }
        }
        logger.info("------------- Provisioning ------------");
        logger.info("            To be completed");

        /* Creating simulations */
        boolean createAsync = false;
        for (Map.Entry<String, SimulationConfiguration.SimulationConfig> entry : this.conf.getSimulations()) {
            
            logger.info("Processing simulation with name: '{}' and full-value: '{}'", entry.getKey(), entry.getValue());

            SimulationDelegation simdlg = createSimulationFromConfig(entry.getValue());
            if (simdlg != null) {
                logger.info("Simulation(polling) '{}' is created with ID: '{}' and it is in progress with {}% current completion", 
                simdlg.getSimulation().getName(), simdlg.getSimulationId(), simdlg.getProgressPercent());
                this.simulationsWithId.put(simdlg.getSimulationId(), simdlg);
                /* Expected 'name' to be in the form of 'simulations/{simulation}' */
                String fsimname = simdlg.getSimulation().getName();
                String[] parts = fsimname.split("/");
                if (parts.length > 2) {
                    logger.info("runConfiguredFlow: Name format is possibly unexpected: '{}'", fsimname);
                }
                String simname = parts[parts.length - 1];
                this.simulationsWithName.put(/*simdlg.getSimulation().getName()*/simname, simdlg);

                switch (this.simPollingMethod) {
                    case SIMPOLL_METHOD_ONEBYONE:
                    {
                        int i = 0;
                        while (true) {
                            SimulationOuterClass.Simulation sim = getSimulation(simname);
                            logger.info("runConfiguredFlow({}): State of sim: '{}' is '{}'", i++, simname, sim.getState());
                            if (sim.getState() == SimulationOuterClass.Simulation.State.SUCCEEDED) {
                                logger.info("Simulation '{}' is DONE...", simname);
                                simulationIsCompleted(simname);
                                break;
                            } 
                            else {
                                logger.info("Simulation '{}' still running, state= '{}' time: {} -- {}({})", simname, sim.getState(),
                                            LocalDateTime.now(), Thread.currentThread().threadId(), Thread.activeCount());
                            } 
                            Thread.sleep(2000);
                        } // while
                    }
                        break;

                    case SIMPOLL_METHOD_RUNNABLE:
                    {
                        SimulationStatusPolling obj = new SimulationStatusPolling(simname);
                        Thread thread = new Thread(obj);
                        thread.start(); // Initiates the new thread
                        /* Tricky way to provide time to thread to be able to increase 'runningJobs' */
                        Thread.sleep(1000);
                    }
                        break;

                    case SIMPOLL_METHOD_SCHEDULER:
                        pollSimulationUntilDone(/*simdlg.getSimulation().getName()*/simname, Executors.newSingleThreadScheduledExecutor());
                        /* Tricky way to provide time to thread to be able to increase 'runningJobs' */
                        Thread.sleep(1000);
                        break;

                    default:
                        logger.error("Unimplemented simulation polling method: {}", this.simPollingMethod);
                        break;
                }
            }
            else {
                logger.warn("Cannot create Simulation with name: '{}'", entry.getValue().getName());
            }
            
        } // for-loop through simulation config

    }

    public void loadProvisioning(String fileWithPath) {
        this.prov = new SimulationProvisioning(fileWithPath);
        this.prov.initialize();
        this.prov.obtainSrTePolicyParams();
        prov.provisionServices();
        logger.info("Size of provisioning resources: {}", this.prov.getProvResources().size());
    }

    public void dumpScenarioConfigAndProvisioning() {
        StringBuilder sb = new StringBuilder();

        for (Map.Entry<String, SimulationConfiguration.ScenarioConfig> entry : this.conf.getScenarios()) {
            sb.append("Processing scenario with name: ").append(entry.getKey())
              .append(" and full-value: ").append(entry.getValue()).append("\n");
        }
        for (Map.Entry<String, SimulationConfiguration.SimulationConfig> entry : this.conf.getSimulations()) {
            sb.append("Processing simulation with name: ").append(entry.getKey())
              .append(" and full-value: ").append(entry.getValue()).append("\n");
        }
        for (Map.Entry<String, SimulationConfiguration.AnalysisConfig> entry : this.conf.getAnalyses()) {
            sb.append("Processing analysis with name: ").append(entry.getKey())
              .append(" and full-value: ").append(entry.getValue()).append("\n");
        }
        /* Provisioning resources */
        int pcount =0;
        List<ProvisioningResources> provResources = this.prov.getProvResources();
        for (ProvisioningResources resources : provResources) {

            Set<Entry<String, ProvisioningOuterClass.P2pSrTePolicy>> p2pSrTePolicies = resources.getP2pSrTePolicyMap().entrySet();
            sb.append("[").append(pcount++)
              .append("] ---------------------------------------------------------------------------------------\n");
            sb.append("Size of P2PSrTePolicy instances: ").append(p2pSrTePolicies.size()).append("\n");

            int idx  = 0;
            for (Entry<String, ProvisioningOuterClass.P2pSrTePolicy> policy : p2pSrTePolicies) {
                sb.append("policy[").append(idx++).append("]: ").append(policy.getKey()).append(" -- ").append(policy.getValue()).append("\n");
            }
            sb.append("-------------------------\n");
            Set<Entry<String, ProvisioningOuterClass.P2pSrTePolicyCandidatePath>> candidatePaths = resources.getP2pSrTePolicyCandidatePathMap().entrySet();
            sb.append("Size of P2PSrTePolicyCandidatePath instances: ").append(candidatePaths.size()).append("\n");

            idx  = 0;
            for (Entry<String, ProvisioningOuterClass.P2pSrTePolicyCandidatePath> candidatePath : candidatePaths) {
                sb.append("policy[").append(idx++).append("]: ").append(candidatePath.getKey()).append(" -- ").append(candidatePath.getValue()).append("\n");
            }
        }
        logger.info("Config and provisioning\n{}", sb);
    }

    /**
     * Main method to run the client
     */
    public static void main(String[] args) throws Exception {
        String host = "localhost";
        int port = 50051;
        String inProcessName = null;
        String target = null; // e.g., "localhost:50051"

        //String confFileName = "config/sim.properties";
        String confFileName = "src/main/java/com/telesat/config/sim_config.json";
        int pollingMethod = SIMPOLL_METHOD_ONEBYONE;

        //System.out.println("\n\nNumber of arguments: " + args.length + "\n\n");
        for (int i = 0; i < args.length; i++) {
            if ("--inprocess".equals(args[i]) && i + 1 < args.length) {
                inProcessName = args[i + 1];
                i++;
            } 
            else if ("--target".equals(args[i]) && i + 1 < args.length) {
                target = args[i + 1];
                i++;
            } 
            else if (i == 0 && !args[i].startsWith("--")) {
                // If the first arg contains a colon, treat it as full target
                if (args[i].contains(":")) {
                    target = args[i];
                } else {
                    host = args[i];
                }
            } 
            else if (i == 1 && !args[i].startsWith("--")) {
                port = Integer.parseInt(args[i]);
            }
            else if ("--config".equals(args[i]) && i + 1 < args.length) {
                confFileName = args[i + 1];
                i++;
            }
            else if ("--polling".equals(args[i]) && i + 1 < args.length) {
                if ("sequential".equals(args[i + 1])) {
                    pollingMethod = SIMPOLL_METHOD_ONEBYONE;
                }
                else if ("runnable".equals(args[i + 1])) {
                    pollingMethod = SIMPOLL_METHOD_RUNNABLE;
                }
                else if ("scheduler".equals(args[i + 1])) {
                    pollingMethod = SIMPOLL_METHOD_SCHEDULER;
                }
                else {
                    System.err.println("Unsupported 'polling' method. Assumed 'sequential'");
                }
                i++;
            }
        }

        SimulationClient client;
        if (target != null) {
            ManagedChannel ch = Grpc.newChannelBuilder(target, InsecureChannelCredentials.create()).build();
            client = new SimulationClient(ch);
        } 
        else {
            client = new SimulationClient(host, port);
        }
        client.readConfiguration(confFileName);
        client.loadProvisioning("data/ivv/Demand_CC231_NorthAmerica_v2.csv");

        try (Scanner scan = new Scanner(System.in)) {
            for (;;) {
                System.out.println();
                System.out.println("========== SimulationClient Menu ==========");
                System.out.println("  1 - Run full configured flow (scenarios -> simulations -> analyses)");
                System.out.println("  2 - Show config only (scenarios, simulations, analyses)");
                System.out.println("  3 - Dump config and provisioning details");
                System.out.println("  0 - Exit");
                System.out.println("============================================");
                System.out.print("Seciminiz (0-3): ");
                System.out.flush();
                String line = scan.nextLine();
                if (line == null || line.isBlank()) continue;
                line = line.trim();
                switch (line) {
                    case "1":
                        client.simPollingMethod = pollingMethod;
                        client.runningJobs = new AtomicInteger(0);
                        client.runConfiguredFlow();
                        logger.info("Current running jobs: {}", client.runningJobs.get());
                        while (client.runningJobs.get() > 0) {
                            Thread.sleep(100);
                        }
                        System.out.println("Flow tamamlandi.");
                        System.out.println("Menüye dönülüyor...");
                        System.out.flush();
                        break;
                    case "2":
                        for (Map.Entry<String, SimulationConfiguration.ScenarioConfig> e : client.conf.getScenarios()) {
                            System.out.println("[Scenario] " + e.getKey() + " -> " + e.getValue());
                        }
                        for (Map.Entry<String, SimulationConfiguration.SimulationConfig> e : client.conf.getSimulations()) {
                            System.out.println("[Simulation] " + e.getKey() + " -> " + e.getValue());
                        }
                        for (Map.Entry<String, SimulationConfiguration.AnalysisConfig> e : client.conf.getAnalyses()) {
                            System.out.println("[Analysis] " + e.getKey() + " -> " + e.getValue());
                        }
                        break;
                    case "3":
                        client.dumpScenarioConfigAndProvisioning();
                        break;
                    case "0":
                        logger.info("Shutting down the program...");
                        client.shutdown();
                        return;
                    default:
                        System.out.println("Gecersiz secim. 0-3 arasi girin.");
                }
            }
        } finally {
            logger.info("Shutting down the program...");
            client.shutdown();
        }
    }
}