package com.telesat.services.feasibility;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class CIR_Calc {

    public static CIR_Calc cc_instance = new CIR_Calc();

    public static double minCIR(double[] prefCIRs, double[] coeffs) {
        double minVal = Double.MAX_VALUE;

        for (int i =0; i < prefCIRs.length; i++) {
            double cval = coeffs[i] * prefCIRs[i];
            if (cval < minVal) {
                minVal = cval;
            }
        }
        return minVal;
    }

    public static double[] sortData(final double[] data) {
        double[] sorted = new double[data.length];
        System.arraycopy(data, 0, sorted, 0, data.length);
        Arrays.sort(sorted);

        return sorted;
    }

    public static void printArray(final double[] data) {
        for (int i = 0; i < (data.length - 1); i++) { 
            System.out.printf("%5.4f, ", data[i]);
        } 
        System.out.printf("%5.4f%n", data[data.length-1]);
    }

    class SortTAPairsByAvailability implements Comparator<ThroughputAvailabilityPair> 
    { 
        /* For sorting in ascending order of availability */
        public int compare(ThroughputAvailabilityPair a, ThroughputAvailabilityPair b) 
        { 
            int smaller = ((a.availability < b.availability) ? -1 : 0);
            return (a.availability > b.availability) ? 1 : smaller;
        } 
    } 

    public static ThroughputAvailabilityPair[] sortTAPairs(ThroughputAvailabilityPair[] pairs) {

        /* A shallow copy of pairs for sorting */
        ThroughputAvailabilityPair[] spairs = new ThroughputAvailabilityPair[pairs.length];
        System.arraycopy(pairs, 0, spairs, 0, pairs.length);

        /* To be able to use Collections' sort utility, we have to have a list representation */
        ArrayList<ThroughputAvailabilityPair> lta = new ArrayList<>();
        Collections.addAll(lta, pairs);

        Collections.sort(lta, cc_instance.new SortTAPairsByAvailability());
        spairs = lta.toArray(spairs);

        return spairs;
    }

    public static double CalculateCIR(final double[] tputs, final int begin, final int length, final boolean isSorted, 
                                      ThroughputAvailabilityPair[] taPairs, final double level, final double enforceLevel) 
                                      throws IllegalArgumentException {

        /* Check for validity of proportion-availability data  */
        /* Total of throughput values shall be <= 1.0 */
        double tpTotal = 0;
        for (int i = 0; i < taPairs.length; i++) {
            System.out.println("taPairs.tp[" + i + "]: " + taPairs[i].getThroughput() + ", tpTotal: " + tpTotal);
            tpTotal += taPairs[i].getThroughput();
        }
        System.out.println("tpTotal: " + tpTotal);
        
        if (tpTotal > 1.0) {
            System.err.println("Total of throughputs cannot exceeds 1.0: " + tpTotal);
            throw new IllegalArgumentException("Total of throughputs cannot exceeds 1.0: " + tpTotal);
        }
        double EPSILON = 1e-9; // We use 'epsilon' method to deal with double precision problem of Java
        if ((1.0 - tpTotal) > EPSILON) {
            /* Level will also be the availability of the throughput remaining from the array, if its total is < 1.0. */
            double remaining = 1.0 - tpTotal;
            /* Add this information as a proportion of throughput into pa_pairs */
            ThroughputAvailabilityPair newPair = new ThroughputAvailabilityPair(remaining, level);
            ThroughputAvailabilityPair[] tempPairs = new ThroughputAvailabilityPair[taPairs.length + 1];
            System.arraycopy(taPairs, 0, tempPairs, 0, taPairs.length);
            tempPairs[taPairs.length] = newPair;
            taPairs = tempPairs;
            System.out.println("Remaining part: " +  remaining + " is considered for CIR level: " + level);
        }

        /* TODO: Implement other additional checks for validity of pa_pairs like:
         *       - Proportions shall have different values
         *       - Availabilities shall have different values
         *       - The largest proportion shall have lowest availability
         *       - ...
         */

        System.out.print("Processing for taPairs: ");
        for (int i = 0; i < taPairs.length; i++) {
            System.out.print(taPairs[i].toString() + " ");
        }
        System.out.print("\n");
        /* It is better to have taPairs sorted */
        ThroughputAvailabilityPair[] sta = sortTAPairs(taPairs);
        
        System.out.print("Sorted ta-pairs       : ");
        for (int i = 0; i < sta.length; i++) {
            System.out.print(sta[i].toString() + " ");
        }
        System.out.print("\n");
        /* Lowest shall be equal to the 'level' */
        if (level != sta[0].getAvailability()) {
            System.err.println("Definition problem: No 'level': " + level + " included in the TA-pairs set");
            throw new IllegalArgumentException("Definition problem: No 'level': " + level + " included in the TA-pairs set");
        }
        /* Hopefully ready to go through calculation steps */

        Percentile pr = new Percentile();

        /* lowest will be for CIR(level) */
        double[] prefilterCalcs = new double[sta.length];

        /* Calculation of Pre-Filter CIR(level) */

        /* Coefficients */
        double[] coefficients = new double[sta.length];
        double tempVal = 0;
        for (int i = (sta.length - 1); i >= 0; i--) {
            tempVal += sta[i].getThroughput();
            coefficients[i] = 1/tempVal;
            System.out.println("Coefficient[" + i + "]: " + coefficients[i]);
        }

        /* Calculate percentiles for all required availabilities 
         * (Actually if they are needed )
        */
        for (int i = 0; i < sta.length; i++) {
            double rank = 100 - sta[i].getAvailability(); 
            prefilterCalcs[i] = pr.evaluate(tputs, begin, length, isSorted, rank);
            System.out.println("Prefilter-CIR for availability: " + sta[i].getAvailability() + " = " + prefilterCalcs[i]);
        }

        double CIR = Double.MAX_VALUE;
        if (level < enforceLevel) {
            /* Find minimum CIR as based on coefficients */
            for (int i =0; i < prefilterCalcs.length; i++) {
                double cval = coefficients[i] * prefilterCalcs[i];
                if (cval < CIR) {
                    CIR = cval;
                }
            }
            System.out.println("Enforced CIR: " + CIR);
        }
        else {
            CIR = prefilterCalcs[0];
            System.out.println("Unenforced CIR: " + CIR);
        }
        System.out.println("CIR(" + sta[0].getAvailability() + "): " + CIR);

        return CIR;
    }

    public static boolean CalculateCIRFeasibility(final double[] tputs, final int tpBegin, 
                                                  final int tpLength, final boolean tpIsSorted, 
                                                  ThroughputAvailabilityPair[] taPairs, final double level, 
                                                  final double enforceLevel, final double SLA) {
        double calcCIR = 0;
        boolean result = false;

        try {
            calcCIR = CalculateCIR(tputs, tpBegin, tpLength, tpIsSorted, taPairs, level, enforceLevel);
            System.out.println("Calculated CIR: " + calcCIR + " while SLA-CIR: " + SLA);
        }
        catch (Exception ex) {
            System.err.println("CalculateCIR_Feasibility: Problem on processiong of CIR calculation: " + ex.getMessage());
            return result;
        }
        
        result = (calcCIR >= SLA);
        System.out.println("Feasibility result: " + result);

        return result;
    }

    public static boolean[] CalculateCIR_Feasibility(final double[] fwdTputs, final int fwdBegin, 
                                                     final int fwdLength, final boolean fwdIsSorted, 
                                                     final double[] rtnTputs, final int rtnBegin, 
                                                     final int rtnLength, final boolean rtnIsSorted, 
                                                     ThroughputAvailabilityPair[] taPairs, final double level, 
                                                     final double enforceLevel, final double fwdSLA, final double rtnSLA) {
        double cirFwd = 0;
        double cirRtn = 0;
        boolean[] result = new boolean[2]; /* expected to be initialized as 'false' for all */

        try {
            cirFwd = CalculateCIR(fwdTputs, fwdBegin, fwdLength, fwdIsSorted, taPairs, level, enforceLevel);
            System.out.println("FWD CIR: " + cirFwd);
        }
        catch (Exception ex) {
            System.err.println("Problem on processiong of FWD CIR calculation: " + ex.getMessage());
            return result;
        }
        System.out.println("---------------------");
        try {
            cirRtn = CalculateCIR(rtnTputs, rtnBegin, rtnLength, rtnIsSorted, taPairs, level, enforceLevel);
            System.out.println("RTN CIR: " + cirRtn);
        }
        catch (Exception ex) {
            System.err.println("Problem on processiong of RTN CIR calculation: " + ex.getMessage());
            return result;
        }
        System.out.println("---------------------");
        System.out.println("Feasibility check for FWD-CIR: " + cirFwd + " RTN-CIR: " + cirRtn + 
                           " against fwdSLA: " + fwdSLA + " rtnSLA: " + rtnSLA);

        if (cirFwd <= fwdSLA) result[0] = true;
        if (cirRtn <= rtnSLA) result[1] = true;

        System.out.println("Feasibility result: " + result[0] + ", " + result[1]);
        return result;
    }

    public static void main(String[] args) {

        double[] d = new double[] { 95.1772, 95.1567, 95.1937, 95.1959, 95.1442, 95.0610, 95.1591, 95.1195, 95.1065,
                                    95.0925, 95.1990, 95.1682 };

        double[] sd = sortData(d);
        printArray(d);
        printArray(sd);

        // sorted array = 95.061, 95.0925, 95.1065, 95.1195, 95.1442, 95.1567, 95.1591,
        // 95.1682, 95.1772, 95.1937, 95.1959, 95.1990

        ThroughputAvailabilityPair[] taPairs1 =  { new ThroughputAvailabilityPair(0.3, 99.0),
                                                   new ThroughputAvailabilityPair(0.5, 95.0),
                                                   new ThroughputAvailabilityPair(0.2, 99.5)
                                                 };

        ThroughputAvailabilityPair[] taPairs2 =  { new ThroughputAvailabilityPair(0.3, 99.0),
                                                   /*new ThroughputAvailabilityPair(0.5, 95.0),*/
                                                   new ThroughputAvailabilityPair(0.2, 99.5)
                                                 };
                     
        ThroughputAvailabilityPair[] taPairs3 =  { new ThroughputAvailabilityPair(0.4, 95.0),
                                                   new ThroughputAvailabilityPair(0.3, 98.0),
                                                   new ThroughputAvailabilityPair(0.2, 99.0),
                                                   new ThroughputAvailabilityPair(0.1, 99.5)
                                                 };

        ThroughputAvailabilityPair[] taPairs4 =  { new ThroughputAvailabilityPair(0.3, 98.0),
                                                   new ThroughputAvailabilityPair(0.2, 99.0),
                                                   new ThroughputAvailabilityPair(0.1, 99.5)
                                                 };

        ThroughputAvailabilityPair[] taPairs5 =  { new ThroughputAvailabilityPair(0.60, 95.0),
                                                   new ThroughputAvailabilityPair(0.25, 99.0),
                                                   new ThroughputAvailabilityPair(0.15, 99.5)
                                                 };

        ThroughputAvailabilityPair[] taPairs6 =  { /*new ThroughputAvailabilityPair(0.60, 95.0),*/
                                                   new ThroughputAvailabilityPair(0.25, 99.0),
                                                   new ThroughputAvailabilityPair(0.15, 99.5)
                                                 };
        
        /* Set PA-pairs for test */
        ThroughputAvailabilityPair[] taPairs = taPairs2;

        /* Use same data for both FWD and RTN */
        boolean[] feasible = CalculateCIR_Feasibility(d, 0, d.length, false, 
                                                      d, 0, d.length, false, 
                                                      taPairs, 95.0, 99.0, 100.0, 100.0);   
        System.out.println("Feasibility result is " + feasible[0] + ", " + feasible[1]);
    }
}
