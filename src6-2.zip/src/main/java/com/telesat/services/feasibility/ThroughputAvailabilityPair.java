package com.telesat.services.feasibility;

/**
 * 
 * ThroughputAvailabilityPair
 * Owns throughput and availability pairs to be used in CIR calculation.
 * Both values are considered as primitive doubles, such that we do not use 
 * javafx.util.Pair is not considered to prevent boxing to Double objects.
 * 
 * It is implemented as an immutable class 
 */
public class ThroughputAvailabilityPair {

    public final double throughput;
    public final double availability;

    public ThroughputAvailabilityPair(double tput, double avail) {
        this.throughput = tput;
        this.availability = avail;
    }

    /**
     * Gets the throughput value of the instance
     * 
     * @return the throughput value
     */
    public double getThroughput() {
        return this.throughput;
    }

    /**
     * Gets the availability value of the instance
     * 
     * @return the availability value
     */
    public double getAvailability() {
        return this.availability;
    }

    /**
     * Compares the instance data with 'other' for equality
     * 
     * @param other - another instance to compare
     * @return true if only both 'throughput' and 'availability' are equal. 
     */
    public boolean equals(ThroughputAvailabilityPair other) {
        System.out.print("Equality check...");
        return ((this.throughput == other.throughput) && (this.availability == other.availability));
    }

    /**
     * Returns a String representation of pair instance in the format of {@code ($throughput,$availability)}.
     *
     * @return a string describing this object, not null
     */
    @Override
    public String toString() {
        return "(" + this.getThroughput() + ", " + this.getAvailability() + ")";
    }
}
