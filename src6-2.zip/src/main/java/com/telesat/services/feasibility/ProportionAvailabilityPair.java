package com.telesat.services.feasibility;

/**
 * 
 * ProportionAvailabilityPair
 * Implements proportion and availability pairs to be used in CIR calculation.
 * Both values are considered as primitive doubles, such that we do not use 
 * javafx.util.Pair is not considered to prevent boxing to Double objects.
 * 
 * It is implemented as an immutable class 
 */
public class ProportionAvailabilityPair {
   
    public final double proportion;
    public final double availability;

    public ProportionAvailabilityPair(double prp, double avail) {
        this.proportion = prp;
        this.availability = avail;
    }

    /**
     * Gets the proportion value of the instance
     * 
     * @return the proportion value
     */
    public double getProportion() {
        return this.proportion;
    }

    /**
     * Gets the availability value of the instance
     * 
     * @return the availability value
     */
    public double getAvailability() {
        return this.availability;
    }

    /**
     * Compares the instance data with 'other' for equality
     * 
     * @param other - another instance to compare
     * @return true if only both 'proportion' and 'availability' are equal. 
     */
    public boolean equals(ProportionAvailabilityPair other) {
        return ((this.proportion == other.proportion) && (this.availability == other.availability));
    }

    /**
     * Returns a String representation of pair instance in the format of {@code ($proportion,$availability)}.
     *
     * @return a string describing this object, not null
     */
    @Override
    public String toString() {
        return "(" + this.getProportion() + ", " + this.getAvailability() + ")";
    }
}
