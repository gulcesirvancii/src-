package com.telesat.services.feasibility;

import java.util.Arrays;

public class Stats_Main {

    public static double minValue(double... values) {
        double minVal = Double.MAX_VALUE;

        for (double val : values) {
            if (val < minVal) {
                minVal = val;
            }
        }

        return minVal;
    }

    public static double[] sortData(final double[] data) {
        double[] sorted = new double[data.length];
        System.arraycopy(data, 0, sorted, 0, data.length);
        Arrays.sort(sorted);

        return sorted;
    }

    public static void printArray(final double[] data) {
        for (int i = 0; i < (data.length - 1); i++) { 
            System.out.printf("%5.4f, ", data[i]);
        } 
        System.out.printf(", %5.4f\n", data[data.length-1]);
    }

    public static void main(String[] args) throws Exception {

        double[] d = new double[] { 95.1772, 95.1567, 95.1937, 95.1959, 95.1442, 95.0610, 95.1591, 95.1195, 95.1065,
                                    95.0925, 95.1990, 95.1682 };

        double[] sd = sortData(d);
        printArray(d);
        printArray(sd);

        // sorted array = 95.061, 95.0925, 95.1065, 95.1195, 95.1442, 95.1567, 95.1591,
        // 95.1682, 95.1772, 95.1937, 95.1959, 95.1990
        Percentile pr = new Percentile();

        System.out.println("-----------------");
        System.out.println("Mean of data: " + Probability.mean(d));
        System.out.println("Variance of data: " + Probability.variance(d));
        System.out.println("Standard Deviation of data: " + Probability.standardDeviation(d));
        System.out.println("-----------------");

        double result = pr.evaluate(d, 0, d.length, false, 90);
        System.out.println("Test for NIST -- Result for 90th percentile: " + result);

        result = pr.evaluate(d, 0, d.length, false, 95);
        System.out.println("Result for 95th percentile: " + result);
        System.out.println("-----------------");

        result = pr.evaluate(d, 0, d.length, false, 20);
        System.out.println("Result for 20th percentile: " + result);

        result = pr.evaluate(d, 0, d.length, false, 30);
        System.out.println("Result for 30th percentile: " + result);

        result = pr.evaluate(d, 0, d.length, false, 50);
        System.out.println("Result for 50th percentile: " + result);

        System.out.println("------- Pre-Filter CIR ----------");
        
        /* Pass 'p' value as (100 - Level) */
        /* Level = 95.0 */
        double pfCIR95 = pr.evaluate(d, 0, d.length, false, (100-95));
        System.out.println("Result for 5th percentile: " + pfCIR95);

        /* Level = 99.0 */
        double pfCIR99 = pr.evaluate(d, 0, d.length, false, 1);
        System.out.println("Result for 1st percentile: " + pfCIR99);

        /* Level = 99.5 */
        double pfCIR99_5 = pr.evaluate(sd, 0, d.length, true, 0.5);
        System.out.println("Result for 0.5th percentile: " + pfCIR99_5);

        /* CIR is the minimum one aacording to the following formula */
        double cir95 = minValue(pfCIR95, (2 * pfCIR99), (5 * pfCIR99_5));
        System.out.println("CIR95: " + cir95);

        /* Tests with the other approach */
        System.out.println("-------- 2nd approach ---------");
        result = pr.evaluate2(d, 0, d.length, 90);
        System.out.println("Test for NIST-2 -- Result for 90th percentile: " + result);

        result = pr.evaluate2(d, 0, d.length, 95);
        System.out.println("Result for 95th percentile: " + result);
        System.out.println("-----------------");

        result = pr.evaluate2(d, 0, d.length, 20);
        System.out.println("Result for 20th percentile: " + result);

        result = pr.evaluate2(d, 0, d.length, 30);
        System.out.println("Result for 30th percentile: " + result);

        result = pr.evaluate2(d, 0, d.length, 50);
        System.out.println("Result for 50th percentile: " + result);

        System.out.println("-----------------");

        double pfCIR95_2 = pr.evaluate2(d, 0, d.length, 5);
        System.out.println("Result for 5th percentile: " + pfCIR95_2);

        double pfCIR99_2 = pr.evaluate2(d, 0, d.length, 1);
        System.out.println("Result for 1st percentile: " + pfCIR99_2);

        double pfCIR99_5_2 = pr.evaluate2(d, 0, d.length, 0.5);
        System.out.println("Result for 0.5th percentile: " + pfCIR99_5_2);

        double cir95_2 = minValue(pfCIR95_2, (2 * pfCIR99_2), (5 * pfCIR99_5_2));
        System.out.println("CIR95: " + cir95_2);
    }
}
