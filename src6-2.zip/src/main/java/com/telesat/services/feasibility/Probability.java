package com.telesat.services.feasibility;


public class Probability {

    public static double mean(final double[] values) {
        int n = values.length;
        double sum = 0;

        for (int i = 0; i < n; i++) {
            sum = sum + values[i];
        }

        return sum / n;
    }

    public static double variance(final double[] values) {
        int n = values.length;
        double mean = Probability.mean(values);
        double sd = 0;

        for (int i = 0; i < n; i++) {
            sd = sd + Math.pow((values[i] - mean), 2);
        }

        return sd / n;
    }

    public static double standardDeviation(final double[] values) {
        double sd = Probability.variance(values);

        return Math.sqrt(sd);
    }
}
