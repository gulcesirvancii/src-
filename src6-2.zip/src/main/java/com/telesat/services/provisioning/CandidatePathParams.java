package com.telesat.services.provisioning;

// Discriminator is the key use by the map in the parent Policy.
public record CandidatePathParams(String symbolicName,
                                  long   cirBps,
                                  long   eirBps) {
    
}
