package com.telesat.services.provisioning.utils;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;

import com.aalyria.spacetime.api.nbi.v1alpha.Nbi;

public class Utils {

    private Utils() {}
    
    // TODO: Confirm this assumption.
    public static final double PARABOLIC_ANTENNA_PATTERN_DEFAULT_BACKLOBE_GAIN_DB = -30;
    
    public static String formatStringForEntityId(String name) {
        return name.strip().
                    toLowerCase().
                    // Replaces any instances of ", ", such as in "Psary, Poland".
                    replace(", ", "-").
                    // Replaces any remaining instances of " ", such as in "Iron Mountain".
                    replace(" ", "-").
                    replace(",", "-").
                    replace("/", "-");

    }

    public static Nbi.Entity writeEntityToFile(Nbi.Entity entity, String baseDirPath) {
        Nbi.EntityType entityType = entity.getGroup().getType();
        System.out.println(entityType.toString());
        //System.out.println(entity + "\n" + entity.toString());
        String entityStr = entity.toString();
        System.out.println(entityStr);
         
        String filePath = "./" + baseDirPath + 
                          "/"         + 
                          entity.getGroup().getType().name().toLowerCase() +
                          "/"         +
                          entity.getId() +
                          ".txtpb";
        System.out.println(filePath);
        
        Path fpath = Paths.get(baseDirPath, entity.getGroup().getType().name().toLowerCase());
        try {
            Files.createDirectories(fpath);
            System.out.println("Directories are created at: " + fpath.toAbsolutePath());
        }
        catch (IOException ex) {
            System.out.println("Problem on creation directories for: " + fpath.toAbsolutePath());
        }
//        String file_path = baseDirPath
//                           + "/"
//                           + Nbi.EntityType. str(nbi_pb2.EntityType.Name(entity.group.type)).lower()
//        + "/"
//        + entity.id
//        + ".txtpb"
/* 
        try (FileWriter wrter = new FileWriter(filePath, true)) {
            wrter.append("entity ");
            wrter.append(entity.toString());
        }
        catch (IOException e) {
            e.printStackTrace();
        }
*/
/* 
        Path fpath = Paths.get(filePath);
        try (BufferedWriter wrter = Files.newBufferedWriter(fpath, StandardOpenOption.CREATE,
                                                                   StandardOpenOption.WRITE,
                                                                   StandardOpenOption.APPEND)) {
            wrter.write("entity ");
            wrter.write(entity.toString());
            wrter.close();
        }
        catch(IOException e) {
            e.printStackTrace();
        }
*/
/*  
        File wrter = new File(filePath);
        try {
            boolean res = wrter.createNewFile();
            if (res) {
                System.out.println("Created new file for: " + filePath);
            }
            else {
                System.out.println("File exists for: " + filePath);
            }
            if (wrter.canWrite())
            {
                System.out.println("File can be written");
            }
            
        }
        catch (IOException e) {
            e.printStackTrace();
        }                                                                   
*/
        StringBuilder outstr = new StringBuilder("entity {\n");
        //outstr += entity.toString();
        //outstr +=
        StringReader strReader = new StringReader(entity.toString());
        try (BufferedReader bufferedReader = new BufferedReader(strReader)) {
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                outstr.append("  ").append(line).append("\n");
            }
            outstr.append("}\n\n");
        } 
        catch (IOException ex) {
            System.err.println("Problem on processing entity string...");
        }

        //------------------------------------------------------
        //Path fpath = Paths.get(/*filePath*/ "./espt-m3-antenna-pattern.txtp");
        String fname = fpath + "/" + entity.getId() + ".txtpb";
        fpath = Paths.get(fname);
        try (OutputStream out = new BufferedOutputStream(Files.newOutputStream(fpath, 
                                                                               StandardOpenOption.CREATE, 
                                                                               StandardOpenOption.APPEND))) {
            /*                                                                     
            String outEntity = "entity {\n";
            outEntity = outEntity.concat(entity.toString());
            outEntity += "\n}\n";
            out.write(outEntity.getBytes());
            */
            out.write(outstr.toString().getBytes());
        }
        catch (IOException ex) {
            System.err.println(ex);
        }
                                                                   
        return entity;

    }

    public static int writeEntitiesToFile(List<Nbi.Entity> entities, String baseDirPath) {
        for (Nbi.Entity entity : entities) {
            writeEntityToFile(entity, baseDirPath);
        }
        return entities.size();
    }

}
