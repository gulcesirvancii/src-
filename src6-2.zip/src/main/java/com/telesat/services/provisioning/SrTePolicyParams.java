package com.telesat.services.provisioning;

public record SrTePolicyParams(String a,
                               String b,
                               long   fwdCir,
                               long   revCir) {
}
