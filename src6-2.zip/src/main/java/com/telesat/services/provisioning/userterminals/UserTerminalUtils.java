package com.telesat.services.provisioning.userterminals;

import com.telesat.services.provisioning.utils.Utils;

public class UserTerminalUtils {

    private UserTerminalUtils() {}
    
    /* Returns a globally unique name for the UT.

       The terminal type is not currently included because a lengthy string
       clutters the visualization of terminals in the UI.

       args:
           ut_id_number (int): The ID of the UT according to the demand model
                               CSV.
     */

    public static String getUTName(String ut_id_number) {

        return "ut-" + ut_id_number;
    }

    /*    @staticmethod
    def get_platform_definition_id(ut_name) -> str:
        """Returns the Spacetime Entity ID for the PLATFORM_DEFINITION Entity
        that represents this UT.

        args:
            ut_name (str): The globally unique name of the UT, as determined by
                get_ut_name().
        """
        return utils.format_string_for_entity_id(ut_name)
     */
    public static String getPlatformDefinitionId(String utName) {
        return Utils.formatStringForEntityId(utName);
    }
}
