package com.telesat.services.provisioning.networkbuilder;

import java.util.List;

import com.aalyria.spacetime.api.nbi.v1alpha.Nbi;

import com.telesat.services.provisioning.userterminals.UserTerminalsBuilder;
import com.telesat.services.provisioning.utils.Utils;

public class NetworkBuilder {

    public static void main(String[] args) throws Exception {
        /* TODO: To be implemented to invoke builders like 
         *       UserTerminalsBuilder
         */
        UserTerminalsBuilder utbuild = new UserTerminalsBuilder("data/poc2/DemandFile_HighDemand_Lat0.csv");
        List<Nbi.Entity> entities = utbuild.generateAntennaPatterns();
        int numOfEntries = Utils.writeEntitiesToFile(entities, "entities/test");
        System.out.println("Recorded entry number of user related antenna-patterns: " + numOfEntries);

        entities = utbuild.generateNetworkNodes();
        System.out.println("Recorded entry number of user related network-nodes: " + entities.size());
    }

}
