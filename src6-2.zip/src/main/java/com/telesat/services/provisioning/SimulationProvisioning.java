package com.telesat.services.provisioning;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.event.Level;

import com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass;
import com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass.P2pSrTePolicyCandidatePath;
import com.telesat.services.provisioning.utils.Utils;
import com.aalyria.spacetime.api.provisioning.v1alpha.Te;

/* To read and prepare data for client-side provisioning */
public class SimulationProvisioning {

    String csvFileName;

    List<String[]> demandModel;

    List<String> pops = new ArrayList<>();
    Map<String, String[]> userTerminals = new HashMap<>();

    List<SrTePolicyParams> p2pSrTeBiDi = new ArrayList<>();

    List<ProvisioningResources> provResources = new ArrayList<>();

    Logger logger = LoggerFactory.getLogger(SimulationProvisioning.class);

    private static final double PERCENT_OF_DEMAND_MODEL_TO_INCLUDE = 1.0;

    /* User demand file CSV format indexes */
    private static final int CSV_IDX_ID             = 0;
    private static final int CSV_IDX_LATITUDE       = 1;
    private static final int CSV_IDX_LONGITUDE      = 2;
    private static final int CSV_IDX_TARGET_POP     = 3;
    private static final int CSV_IDX_FWDCIR         = 4;
    private static final int CSV_IDX_RTNCIR         = 5;
    private static final int CSV_IDX_TERMINAL_COUNT = 6;
    private static final int CSV_IDX_TERMINAL_TYPE  = 7;

    private	static final String P2P_SR_TE_POLICIES_PART               = "p2pSrTePolicies";
	private	static final String P2P_SR_TE_POLICY_CANDIDATE_PATHS_PART = "candidatePaths";
	private	static final String DOWNTIMES_PART                        = "downtimes";
	private	static final String PROTECTION_ASSOCIATION_GROUPS_PART    = "protectionAssociationGroups";
	private	static final String DISJOINT_ASSOCIATION_GROUPS_PART      = "disjointAssociationGroups";

    public SimulationProvisioning(String demandModelFilePath) {
        this.csvFileName = demandModelFilePath;
    }

    public void initialize() {
        /* ID,Latitude,Longitude,TargetPoP,FWDCIR,RTNCIR,TerminalCount,TerminalType */
        List<String[]> fullDemandModel = this.parseCSV(this.csvFileName);
        if (!fullDemandModel.isEmpty()) {
            int totalNumRows = fullDemandModel.size();
            this.logger.info("SimulationProvisioning.initialize: '{}' rows from demand model file: '{}'", totalNumRows, this.csvFileName);
            // Filters the demand model to only the percentage that should be
            // included in the instance.
            int samplesToKeep = (int)Math.round(totalNumRows * (PERCENT_OF_DEMAND_MODEL_TO_INCLUDE / 100));
            this.demandModel = new ArrayList<>();
            for (int i = 0; i < samplesToKeep; i++) {
                /* '+ 1' is used to skip first line in the case of  i=0 */
                String[] demandItem = fullDemandModel.get((i * (int)Math.round((double)totalNumRows / samplesToKeep)) + 1);
                this.demandModel.add(demandItem);
                this.pops.add(nameToID(demandItem[CSV_IDX_TARGET_POP]));
                String utKey = "user-terminal-" + demandItem[CSV_IDX_ID];
                this.userTerminals.put(utKey, demandItem);
                this.logger.info("User line-{}: {} -- pop: {}, ut-key: '{}'", i, this.demandModel.getLast(), this.pops.getLast(), utKey);
            }
            this.logger.info("SimulationProvisioning.initialize: '{}' rows kept for provisioning", this.demandModel.size());
        }
    }

    public List<ProvisioningResources> getProvResources() {
        return this.provResources;
    }
    
    private List<String[]> parseCSV(String filename) {
        List<String[]> records = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                records.add(values);
            }
        }
        catch (Exception e) {
            this.logger.error("Error on openning file: '{}'", e.getMessage());
        }
        return records;
    }

    public String nameToID(String name)  {
        return Utils.formatStringForEntityId(name);
    }

    /* Derived from user-terminal processing part of function AddAssetsFromCSVData() in telesatn.go, which is  
       for model creation in actual (!). */
    public void obtainSrTePolicyParams() throws NumberFormatException {
        Comparator<String> comp = (s1, s2) -> Long.compare(Long.valueOf(this.userTerminals.get(s1)[CSV_IDX_ID]), 
                                                           Long.valueOf(this.userTerminals.get(s2)[CSV_IDX_ID]));

        String[] keys = this.userTerminals.keySet().toArray(new String[0]);
        Arrays.sort(keys, comp);
        for (String utID : keys) {
            // p2pSrTeBidi = append(p2pSrTeBidi, SrTePolicyParams{
			// a:      fmt.Sprintf("pop-%s-route-fn", nameToID(ut["TargetPoP"])),
			// b:      utID + "-route-fn",
			// fwdCir: uint64(float64(model.OneMbps) * mustFloat64(ut["FWDCIR"])),
			// revCir: uint64(float64(model.OneMbps) * mustFloat64(ut["RTNCIR"]))})

            String[] data = this.userTerminals.get(utID);
            String forA = "pop-" + data[CSV_IDX_TARGET_POP] + "-route-fn";
            String forB = utID + "-route-fn";
            long fwdCir = (long)(Float.valueOf(data[CSV_IDX_FWDCIR]) * 1000000);
            long rntCir = (long)(Float.valueOf(data[CSV_IDX_RTNCIR]) * 1000000);

            SrTePolicyParams params = new SrTePolicyParams(forA, forB, fwdCir, rntCir);
            this.p2pSrTeBiDi.add(params);
        }
    }

    List<SrTePolicyParams> getBidirectionalSrTePolicyParamsList() {
        return this.p2pSrTeBiDi;
    }

    /* Derived from  makeUnidirectionalP2PSrTePolicyParams() in telesatn.go */
    private P2PSrTePolicyParams makeUnidirectionalP2PSrTePolicyParams(String src, String dest, long cirBps) {

        CandidatePathParams candidate = new CandidatePathParams("primary", cirBps, 0);
        Map<Integer, CandidatePathParams> candidates = new HashMap<>();
        candidates.put(1, candidate);

        return new P2PSrTePolicyParams(src, dest, 1, candidates);
    }

    /* Derived from AddInternalTelesatnServices() function in telesatn.go file, which is for provisioning */
    public void provisionServices() {
        for (SrTePolicyParams param : this.p2pSrTeBiDi) {
            P2PSrTePolicyParams fwdPath = makeUnidirectionalP2PSrTePolicyParams(param.a(), param.b(), param.fwdCir());
            addP2PSrTePolicy(fwdPath);
            P2PSrTePolicyParams rtnPath = makeUnidirectionalP2PSrTePolicyParams(param.b(), param.a(), param.revCir());
            addP2PSrTePolicy(rtnPath);
        }
    }

    /* derived from validate() function for P2PSrTePolicyParams in params.go */
    public String validateP2PSrTePolicyParams(P2PSrTePolicyParams param) {
        if (param.headEnd().isEmpty() || param.endPoint().isEmpty()) {
            return "EK_ROUTE_FN Entity IDs must be non-empty";
        }
        if (param.headEnd().equals(param.endPoint())) {
            return "EK_ROUTE_FN Entity IDs must not be the same";
        }
        if (param.color() == 0) {
            return "P2P SR-TE Policy color MUST be non-zero (RFC 9256 S2.1)";
        }
        return "";
    }

    public void addP2PSrTePolicy(P2PSrTePolicyParams params) {
        String val = validateP2PSrTePolicyParams(params);
        if (!val.isEmpty()) {
            this.logger.error("addP2PSrTePolicy: Not valid parameter with error: '{}'", val);
            return;
        }
/* 	policyID := fmt.Sprintf("%s--%d--%s", params.Headend, params.Color, params.Endpoint)
	policyUUID := prb.MakeUUIDForString(policyID)
	policyResourceName := strings.Join([]string{provisioning.P2PSrTePoliciesPart, policyUUID}, "/")

	resources := &pb.ProvisioningResources{}
	resources.P2PSrTePolicies = append(resources.P2PSrTePolicies,
		&apipb.P2PSrTePolicy{
			Name:         policyResourceName,
			Headend:      params.Headend,
			Endpoint:     params.Endpoint,
			Color:        params.Color,
			SymbolicName: policyID,
		})

	if len(params.CandidatePaths) != 0 {
		keys := make([]uint32, 0, len(params.CandidatePaths))
		for k := range params.CandidatePaths {
			keys = append(keys, k)
		}

		sort.Slice(keys, func(i, j int) bool {
			return keys[i] < keys[j]
		})

		for _, discriminator := range keys {
			candidatePath := params.CandidatePaths[discriminator]
			pathId := fmt.Sprintf("%d", discriminator)
			pathResourceName := strings.Join([]string{policyResourceName, provisioning.P2PSrTePolicyCandidatePathsPart, pathId}, "/")

			resources.P2PSrTePolicyCandidatePaths = append(resources.P2PSrTePolicyCandidatePaths,
				&apipb.P2PSrTePolicyCandidatePath{
					Name:          pathResourceName,
					SymbolicName:  candidatePath.SymbolicName,
					Discriminator: discriminator,
					Metrics: &apipb.Metrics{
						CirBps: candidatePath.CirBps,
						EirBps: candidatePath.EirBps,
					},
				})
		}
	}

	prb.AddProvisioningResources(policyUUID, resources)
 */
        ProvisioningResources resource = new ProvisioningResources();

        String policyID = String.format("%s--%d--%s", params.headEnd(), params.color(), params.endPoint());
	    String policyUUID = UUID.nameUUIDFromBytes(policyID.getBytes()).toString();
	    String policyResourceName = P2P_SR_TE_POLICIES_PART + "/" + policyUUID;

        ProvisioningOuterClass.P2pSrTePolicy p2pPolicy = ProvisioningOuterClass.P2pSrTePolicy.newBuilder().setName(policyResourceName)
                                                                                                          .setHeadend(params.headEnd())
                                                                                                          .setEndpoint(params.endPoint())
                                                                                                          .setColor(params.color())
                                                                                                          .setSymbolicName(policyID)
                                                                                                          .build();
        resource.putP2pSrTePolicy(policyID, p2pPolicy);

        if (params.candidatePaths().size() > 0) {
            Integer[] keys = params.candidatePaths().keySet().toArray(new Integer[0]);
            Arrays.sort(keys);
            for (Integer key : keys) {
                CandidatePathParams cpParam = params.candidatePaths().get(key);
                String pathID = key.toString();
                String pathResourceName = P2P_SR_TE_POLICY_CANDIDATE_PATHS_PART + "/" + pathID;


                Te.Metrics metric = Te.Metrics.newBuilder()
                                              .setCirBps(cpParam.cirBps())
                                              .setEirBps(cpParam.eirBps())
                                              .build();

                ProvisioningOuterClass.P2pSrTePolicyCandidatePath candidatePath = ProvisioningOuterClass.P2pSrTePolicyCandidatePath.newBuilder()
                                                                                                        .setName(pathResourceName)
                                                                                                        .setSymbolicName(cpParam.symbolicName())
                                                                                                        .setDiscriminator(key.intValue())
                                                                                                        .setMetrics(metric)
                                                                                                        .build();
                resource.putP2pSrTePolicyCandidatePath(policyResourceName, candidatePath);
            }
        }
        this.provResources.add(resource);
    }


    /**
     * Main method for individual testing
     */
    public static void main(String[] args) throws Exception {
        String fileName = "data/ivv/Demand_CC231_NorthAmerica_v2.csv";

        SimulationProvisioning prov = new SimulationProvisioning(fileName);
        prov.initialize();

        prov.obtainSrTePolicyParams();
        int idx  = 0;
        for (SrTePolicyParams param : prov.p2pSrTeBiDi) {
            System.out.println("[" + idx + "] a: " + param.a() + " b: " + param.b() + " fwdCir: " + param.fwdCir() + " rntCir: " + param.revCir());
            idx++;
        }
        prov.provisionServices();
        prov.logger.info("Size of resources: {}", prov.provResources.size());
    }
}
