package com.telesat.services.provisioning;

import java.util.Map;

public record P2PSrTePolicyParams(String                            headEnd,
                                  String                            endPoint,
                                  int                               color,
                                  // A map of discriminator to other candidate path parameters.
                                  Map<Integer, CandidatePathParams> candidatePaths) {
    
}
