package com.telesat.services.provisioning.networkwide;

public record ParabolicAntennaConfig(String configName, 
                                     String antennaPatternId,
                                     String antennaPatternName,
                                     double txAntennaDiameterM,
                                     double rxAntennaDiameterM,
                                     double txAntennaEfficiency,
                                     double rxAntennaEfficiency,
                                     int txMaxCarrierSizeHz,
                                     int rxMaxCarrierSizeHz,
                                     double txReferenceFreqGhz,
                                     double rxReferenceFreqGhz,
                                     double fieldOfRegardOuterHalfAngleDeg,
                                     double systemNoiseTemperatureK,
                                     double txRadomeLossdB,
                                     double txFeedLossdB,
                                     double rxRadomeLossdB,
                                     double rxFeedLossdB,
                                     double oboLookupLossdB,
                                     double oboSingleCarrierLossdB,
                                     double pointingError,
                                     double txMaxPowerW,
                                     boolean isSteerable) {
                                        
}

