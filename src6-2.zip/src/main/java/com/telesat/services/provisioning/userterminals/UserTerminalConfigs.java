package com.telesat.services.provisioning.userterminals;

import com.telesat.services.provisioning.networkwide.ParabolicAntennaConfig;

public class UserTerminalConfigs {
    // Default parameters that are shared across types of parabolic user terminals.
    public static final double DEFAULT_MAX_TRANSMIT_POWER_W = 35.0;

    // User terminal type: EHPT-L-8C.
    // For reference, see row 13 of "CNOS_ground_terminal_definition_v2."
    public static final ParabolicAntennaConfig EHPT_L_8C_CONFIG = new ParabolicAntennaConfig("ehpt-l-8c-user-terminal",
                                                                                          "ehpt-l-8c-antenna-pattern",
                                                                                          "ehpt-l-8c-antenna-pattern",
                                                                                          2.40,
                                                                                          2.40,
                                                                                          0.648,
                                                                                          0.648,
                                                                                          400_000_000,
                                                                                          400_000_000,
                                                                                          29.7,
                                                                                          19.9,
                                                                                          70,
                                                                                          275,
                                                                                          -0.5,
                                                                                          -1.8,
                                                                                          -0.6,
                                                                                          0.0,
                                                                                          0,
                                                                                          0,
                                                                                          0.1,
                                                                                          // Note that maximum transmit power is provided in column "BUC Size"
                                                                                          // for the terminal type.
                                                                                          20,
                                                                                          true);

    // User terminal type: MSPT-C.
    // For reference, see row 21 of "CNOS_ground_terminal_definition_v2."
    public static final ParabolicAntennaConfig MSPT_C_CONFIG = new ParabolicAntennaConfig("mspt-c-user-terminal",
                                                                                          "mspt-c-antenna-pattern",
                                                                                          "mspt-c-antenna-pattern",
                                                                                          0.45,
                                                                                          0.45,
                                                                                          0.55,
                                                                                          0.55,
                                                                                          500_000_000,
                                                                                          500_000_000,
                                                                                          29.7,
                                                                                          19.9,
                                                                                          70,
                                                                                          275,
                                                                                          -0.3,
                                                                                          -0.8,
                                                                                          -0.4,
                                                                                          -0.8,
                                                                                          0,
                                                                                          0,
                                                                                          0.1,
                                                                                          // Note that maximum transmit power is provided in column "BUC Size"
                                                                                          // for the terminal type.
                                                                                          3,
                                                                                          true);


    // User terminal type: MSPT-M3.
    // For reference, see row 23 of "CNOS_ground_terminal_definition_v2."
    public static final ParabolicAntennaConfig MSPT_M3_CONFIG = new ParabolicAntennaConfig("mspt-m3-user-terminal",
                                                                                          "mspt-m3-antenna-pattern",
                                                                                          "mspt-m3-antenna-pattern",
                                                                                          1.03,
                                                                                          1.03,
                                                                                          0.67,
                                                                                          0.63,
                                                                                          500_000_000,
                                                                                          500_000_000,
                                                                                          29.7,
                                                                                          19.9,
                                                                                          70,
                                                                                          275,
                                                                                          -0.3,
                                                                                          -0.8,
                                                                                          -0.4,
                                                                                          -0.8,
                                                                                          0,
                                                                                          0,
                                                                                          0.1,
                                                                                          // Note that maximum transmit power is provided in column "BUC Size"
                                                                                          // for the terminal type.
                                                                                          3,
                                                                                          true);


    // User terminal type: EHPT-L-4C.
    // For reference, see row 27 of "CNOS_ground_terminal_definition_v2."
    public static final ParabolicAntennaConfig EHPT_L_4C_CONFIG = new ParabolicAntennaConfig("ehpt-l-4c-user-terminal",
                                                                                          "ehpt-l-4c-antenna-pattern",
                                                                                          "ehpt-l-4c-antenna-pattern",
                                                                                          2.40,
                                                                                          2.40,
                                                                                          0.34,
                                                                                          0.49,
                                                                                          500_000_000,
                                                                                          500_000_000,
                                                                                          28.5,
                                                                                          18.7,
                                                                                          70,
                                                                                          268,
                                                                                          -0.7,
                                                                                          -0.5,
                                                                                          -0.7,
                                                                                          -0.5,
                                                                                          0,
                                                                                          0,
                                                                                          0.1,
                                                                                          // Note that maximum transmit power is provided in column "BUC Size"
                                                                                          // for the terminal type.
                                                                                          20,
                                                                                          true);


    // User terminal type: ESPT-C.
    // For reference, see row 28 of "CNOS_ground_terminal_definition_v2."
    // In the future, this config could be created by parsing 
    // "CNOS_ground_terminal_definition_v2."
    public static final ParabolicAntennaConfig ESPT_C_CONFIG = new ParabolicAntennaConfig("espt-c-user-terminal",
                                                                                          "espt-c-antenna-pattern",
                                                                                          "espt-c-antenna-pattern",
                                                                                          0.45,
                                                                                          0.45,
                                                                                          0.54,
                                                                                          0.56,
                                                                                          500_000_000,
                                                                                          500_000_000,
                                                                                          29,
                                                                                          19,
                                                                                          70,
                                                                                          267,
                                                                                          -0.7,
                                                                                          -0.5,
                                                                                          -0.7,
                                                                                          -0.9,
                                                                                          0,
                                                                                          0,
                                                                                          0.1,
                                                                                          // TODO: Set this to the actual maximum transmit power
                                                                                          // for this user terminal.
                                                                                          3,
                                                                                          true);


    // User terminal type: ESPT-S.
    // For reference, see row 29 of "CNOS_ground_terminal_definition_v2."
    public static final ParabolicAntennaConfig ESPT_S_CONFIG = new ParabolicAntennaConfig("espt-s-user-terminal",
                                                                                          "espt-s-antenna-pattern",
                                                                                          "espt-s-antenna-pattern",
                                                                                          0.65,
                                                                                          0.65,
                                                                                          0.67,
                                                                                          0.63,
                                                                                          500_000_000,
                                                                                          500_000_000,
                                                                                          29,
                                                                                          19,
                                                                                          70,
                                                                                          275,
                                                                                          -0.7,
                                                                                          -0.5,
                                                                                          -0.7,
                                                                                          -0.5,
                                                                                          0,
                                                                                          0,
                                                                                          0.1,
                                                                                          // TODO: Set this to the actual maximum transmit power
                                                                                          // for this user terminal.
                                                                                          3,
                                                                                          true);


    // User terminal type: ESPT-M20.
    // For reference, see row 30 of "CNOS_ground_terminal_definition_v2."
    public static final ParabolicAntennaConfig ESPT_M20_CONFIG = new ParabolicAntennaConfig("espt-m20-user-terminal",
                                                                                          "espt-m20-antenna-pattern",
                                                                                          "espt-m20-antenna-pattern",
                                                                                          1.00,
                                                                                          1.00,
                                                                                          0.55,
                                                                                          0.63,
                                                                                          500_000_000,
                                                                                          500_000_000,
                                                                                          30,
                                                                                          19.9,
                                                                                          70,
                                                                                          259,
                                                                                          -0.7,
                                                                                          -0.5,
                                                                                          -0.7,
                                                                                          -0.5,
                                                                                          0,
                                                                                          0,
                                                                                          0.1,
                                                                                          // TODO: Set this to the actual maximum transmit power
                                                                                          // for this user terminal.
                                                                                          20,
                                                                                          true);

    // User terminal type: ESPT-L.
    // For reference, see row 31 of "CNOS_ground_terminal_definition_v2."
    public static final ParabolicAntennaConfig ESPT_L_CONFIG = new ParabolicAntennaConfig("espt-l-user-terminal",
                                                                                          "espt-l-antenna-pattern",
                                                                                          "espt-l-antenna-pattern",
                                                                                          2.40,
                                                                                          2.40,
                                                                                          0.34,
                                                                                          0.49,
                                                                                          500_000_000,
                                                                                          500_000_000,
                                                                                          28.5,
                                                                                          18.7,
                                                                                          70,
                                                                                          268,
                                                                                          -0.7,
                                                                                          -0.5,
                                                                                          -0.7,
                                                                                          -0.5,
                                                                                          0,
                                                                                          0,
                                                                                          0.1,
                                                                                          // TODO: Set this to the actual maximum transmit power
                                                                                          // for this user terminal.
                                                                                          20,
                                                                                          true);


    // User terminal type: ESPT-M3.
    // For reference, see row 32 of "CNOS_ground_terminal_definition_v2."
    public static final ParabolicAntennaConfig ESPT_M3_CONFIG = new ParabolicAntennaConfig("espt-m3-user-terminal",
                                                                                          "espt-m3-antenna-pattern",
                                                                                          "espt-m3-antenna-pattern",
                                                                                          1.00,
                                                                                          1.00,
                                                                                          0.68,
                                                                                          0.63,
                                                                                          500_000_000,
                                                                                          500_000_000,
                                                                                          30,
                                                                                          19.9,
                                                                                          70,
                                                                                          259,
                                                                                          -0.7,
                                                                                          -0.5,
                                                                                          -0.7,
                                                                                          -0.5,
                                                                                          0,
                                                                                          0,
                                                                                          0.1,
                                                                                          // TODO: Set this to the actual maximum transmit power
                                                                                          // for this user terminal.
                                                                                          3,
                                                                                          true);


    // User terminal type: MSPT-S.
    // For reference, see row 34 of "CNOS_ground_terminal_definition_v2."
    public static final ParabolicAntennaConfig MSPT_S_CONFIG = new ParabolicAntennaConfig("mspt-s-user-terminal",
                                                                                          "mspt-s-antenna-pattern",
                                                                                          "mspt-s-antenna-pattern",
                                                                                          0.65,
                                                                                          0.65,
                                                                                          0.648,
                                                                                          0.648,
                                                                                          500_000_000,
                                                                                          500_000_000,
                                                                                          29.7,
                                                                                          19.9,
                                                                                          70,
                                                                                          275,
                                                                                          -0.3,
                                                                                          -0.6,
                                                                                          -0.4,
                                                                                          -0.6,
                                                                                          0,
                                                                                          0,
                                                                                          0.1,
                                                                                          // TODO: Set this to the actual maximum transmit power
                                                                                          // for this user terminal.
                                                                                          3,
                                                                                          true);

    // TODO: Add configs for the other UT types.

}
