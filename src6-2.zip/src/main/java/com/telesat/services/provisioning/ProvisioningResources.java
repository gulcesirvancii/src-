package com.telesat.services.provisioning;

import java.util.HashMap;
import java.util.Map;

import  com.aalyria.spacetime.api.provisioning.v1alpha.ProvisioningOuterClass;

/* Derived from ProvisioningResources struct at 
   aalyria.com/spacetime/tools/nbictl/provisioning.go

        type ProvisioningResources struct {
	        p2pSrTePolicies             map[string]*provapipb.P2PSrTePolicy
	        p2pSrTePolicyCandidatePaths map[string]*provapipb.P2PSrTePolicyCandidatePath
	        downtimes                   map[string]*provapipb.Downtime
	        protectionAssociationGroups map[string]*provapipb.ProtectionAssociationGroup
	        disjointAssociationGroups   map[string]*provapipb.DisjointAssociationGroup
	        links                       map[string]*provapipb.Link
	        geographicRegions           map[string]*provapipb.GeographicRegion
	        emissionsLimits             map[string]*provapipb.EmissionsLimit
	        emissionsTargets            map[string]*provapipb.EmissionsTarget
        }
    
*/
public class ProvisioningResources {

    Map<String, ProvisioningOuterClass.P2pSrTePolicy>              p2pSrTePolicies;
    Map<String, ProvisioningOuterClass.P2pSrTePolicyCandidatePath> p2pSrTePolicyCandidatePaths;
    Map<String, ProvisioningOuterClass.Downtime>                   downtimes;
    Map<String, ProvisioningOuterClass.ProtectionAssociationGroup> protectionAssociationGroups;
    Map<String, ProvisioningOuterClass.DisjointAssociationGroup>   disjointAssociationGroups;
    /* TODO: The followings are to be included according to new provisioning.proto */
    //Map<String, ProvisioningOuterClass.Link>                       links;
    //Map<String, ProvisioningOuterClass.GeographicRegion>           geographicRegions;
    //Map<String, ProvisioningOuterClass.EmissionsLimit>             emissionsLimits;
    //Map<String, ProvisioningOuterClass.EmissionsTarget>            emissionsTargets;

    public ProvisioningResources() {
        /* We may use lazy allocation, but it might be better to return an empty map, instead of null */
        this.p2pSrTePolicies = new HashMap<>();
        this.p2pSrTePolicyCandidatePaths = new HashMap<>();
        this.downtimes = new HashMap<>();
        this.protectionAssociationGroups = new HashMap<>();
        this.disjointAssociationGroups = new HashMap<>();
    }

    public void putP2pSrTePolicy(String key, ProvisioningOuterClass.P2pSrTePolicy value) {
        this.p2pSrTePolicies.put(key, value);
    }

    public Map<String, ProvisioningOuterClass.P2pSrTePolicy> getP2pSrTePolicyMap() {
        return this.p2pSrTePolicies;
    }

    public void putP2pSrTePolicyCandidatePath(String key, ProvisioningOuterClass.P2pSrTePolicyCandidatePath value) {
        this.p2pSrTePolicyCandidatePaths.put(key, value);
    }

    public Map<String, ProvisioningOuterClass.P2pSrTePolicyCandidatePath> getP2pSrTePolicyCandidatePathMap() {
        return this.p2pSrTePolicyCandidatePaths;
    }

    public void putDowntime(String key, ProvisioningOuterClass.Downtime value) {
        this.downtimes.put(key, value);
    }

    public Map<String, ProvisioningOuterClass.Downtime> getDowntimeMap() {
        return this.downtimes;
    }

    public void putProtectionAssociationGroup(String key, ProvisioningOuterClass.ProtectionAssociationGroup value) {
        this.protectionAssociationGroups.put(key, value);
    }

    public Map<String, ProvisioningOuterClass.ProtectionAssociationGroup> getProtectionAssociationGroupMap() {
        return this.protectionAssociationGroups;
    }

    public void putDisjointAssociationGroup(String key, ProvisioningOuterClass.DisjointAssociationGroup value) {
        this.disjointAssociationGroups.put(key, value);
    }

    public Map<String, ProvisioningOuterClass.DisjointAssociationGroup> getDisjointAssociationGroupMap() {
        return this.disjointAssociationGroups;
    }
}
