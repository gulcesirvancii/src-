package com.telesat.services.provisioning.networkwide;

import java.util.ArrayList;
import java.util.List;

import com.aalyria.spacetime.api.nbi.v1alpha.Nbi.Entity;

public abstract class NetworkSegmentBuilder {

    public class NwSegmentBuilderConfig {
        public boolean antennaPaterns;
        public boolean bandProfiles;
        public boolean interfaceLinkReports;
        public boolean networkNodes;
        public boolean platformDefinitions;
        public boolean serviceRequests;
        public boolean nmtsElements;
    }

    /* Returns a list of ANTENNA_PATTERN entities. */
    public abstract List<Entity> generateAntennaPatterns();

    /* Returns a list of BAND_PROFILE entities. */
    public abstract List<Entity> generateBandProfiles();

    /* Returns a list of INTERFACE_LINK_REPORT entities. */
    public abstract List<Entity> generateInterfaceLinkReports();

    /* Returns a list of NETWORK_NODE entities. */
    public abstract List<Entity> generateNetworkNodes();

    /* Returns a list of PLATFORM_DEFINITION entities. */
    public abstract List<Entity> generatePlatforDefinitions();

    /* Returns a list of SERVICE_REQUEST entities. */
    public abstract List<Entity> generateServiceRequests();

    /* Returns a list of NMTS Fragment messages. */
    public abstract List<Entity> generateNmtsElements();

    /** Returns a list of Entity messages according
     *  to the EntityTypes specified by the config.
     * 
     *  @params: 
     *     config (NetworkSegmentBuilderConfig): Indicates which 
     *             entity-type should be built.
     */
    public List<Entity> build(NwSegmentBuilderConfig config) {

        List<Entity> entities = new ArrayList<>();
        
        if (config.antennaPaterns) {
            entities.addAll(this.generateAntennaPatterns());
        }
        if (config.bandProfiles) {
            entities.addAll(this.generateBandProfiles());
        }
        if (config.interfaceLinkReports) {
            entities.addAll(this.generateInterfaceLinkReports());
        }
        if (config.networkNodes) {
            entities.addAll(this.generateNetworkNodes());
        }
        if (config.platformDefinitions) {
            entities.addAll(this.generatePlatforDefinitions());
        }
        if (config.serviceRequests) {
            entities.addAll(this.generateServiceRequests());
        }
        if (config.nmtsElements) {
            entities.addAll(this.generateNmtsElements());
        }

        return entities;
    }

}
