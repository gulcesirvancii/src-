package com.telesat.services.provisioning.userterminals;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.aalyria.spacetime.api.nbi.v1alpha.Nbi.Entity;

import com.telesat.services.provisioning.networkwide.NetworkSegmentBuilder;
import com.telesat.services.provisioning.networkwide.ParabolicAntennaConfig;

public class UserTerminalsBuilder extends NetworkSegmentBuilder {

    // private enum demandColumns {
    //     _ID_COL_NAME,
    //     _LATITUDE_COL_NAME,
    //     _LONGITUDE_COL_NAME,
    //     _TARGET_POP_COL_NAME,
    //     _FWD_CIR_COL_NAME,
    //     _RTN_CIR_COL_NAME,
    //     _TERMINAL_COUNT_COL_NAME,
    //     _TERMINAL_TYPE_COL_NAME
    // };

    private static final int _ID_COL_NAME             = 0;
    private static final int _LATITUDE_COL_NAME       = 1;
    private static final int _LONGITUDE_COL_NAME      = 2;
    private static final int _TARGET_POP_COL_NAME     = 3;
    private static final int _FWD_CIR_COL_NAME        = 4;
    private static final int _RTN_CIR_COL_NAME        = 5;
    private static final int _TERMINAL_COUNT_COL_NAME = 6;
    private static final int _TERMINAL_TYPE_COL_NAME  = 7;

    // types for each column in the Demand Model CSV.
    // private String[] demandColumnNames = { new String("ID"),
    //                                        new String("Latitude"),
    //                                        new String("Longitude"),
    //                                        new String("TargetPoP"),
    //                                        new String("FWDCIR"),
    //                                        new String("RTNCIR"),
    //                                        new String("TerminalCount"),
    //                                        new String("TerminalType")
    //                                      };
    
    private String[] demandColumnNames = { "ID",
                                           "Latitude",
                                           "Longitude",
                                           "TargetPoP",
                                           "FWDCIR",
                                           "RTNCIR",
                                           "TerminalCount",
                                           "TerminalType"
                                         };
    // Types of UTs.
    static final String _UT_TYPE_EHPT_L_4C = "EHPT-L-4C";
    static final String _UT_TYPE_EHPT_L_8C = "EHPT-L-8C";
    static final String _UT_TYPE_ESPT_C    = "ESPT-C";
    static final String _UT_TYPE_ESPT_L    = "ESPT-L";
    static final String _UT_TYPE_ESPT_M20  = "ESPT-M20";
    static final String _UT_TYPE_ESPT_M3   = "ESPT-M3";
    static final String _UT_TYPE_ESPT_S    = "ESPT-S";
    static final String _UT_TYPE_MSPT_C    = "MSPT-C";
    static final String _UT_TYPE_MSPT_M3   = "MSPT_M3";
    static final String _UT_TYPE_MSPT_S    = "MSPT-S";

    static final int _DEFAULT_UT_HEIGHT = 0;
    // Types of UTs.
/*
    Map<String, ParabolicAntennaConfig> _TERMINAL_TYPE_TO_CONFIG = new HashMap<String, ParabolicAntennaConfig>() {{
        put("EHPT-L-4C", UserTerminalConfigs.EHPT_L_4C_CONFIG);
        put("EHPT-L-8C", UserTerminalConfigs.EHPT_L_8C_CONFIG);
        put("ESPT-C", UserTerminalConfigs.ESPT_C_CONFIG);
        put("ESPT-L", UserTerminalConfigs.ESPT_L_CONFIG);
        put("ESPT-M20", UserTerminalConfigs.ESPT_M20_CONFIG);
        put("ESPT-M3", UserTerminalConfigs.ESPT_M3_CONFIG);
        put("ESPT-S", UserTerminalConfigs.ESPT_S_CONFIG);
        put("MSPT-C", UserTerminalConfigs.MSPT_C_CONFIG);
        put("MSPT-M3", UserTerminalConfigs.MSPT_M3_CONFIG);
        put("MSPT-S", UserTerminalConfigs.MSPT_S_CONFIG);
    }};
*/   
    final Map<String, ParabolicAntennaConfig> _TERMINAL_TYPE_TO_CONFIG = Map.ofEntries(
        new AbstractMap.SimpleEntry<>(_UT_TYPE_EHPT_L_4C, UserTerminalConfigs.EHPT_L_4C_CONFIG),
        new AbstractMap.SimpleEntry<>(_UT_TYPE_EHPT_L_8C, UserTerminalConfigs.EHPT_L_8C_CONFIG),
        new AbstractMap.SimpleEntry<>(_UT_TYPE_ESPT_C,    UserTerminalConfigs.ESPT_C_CONFIG),
        new AbstractMap.SimpleEntry<>(_UT_TYPE_ESPT_L,    UserTerminalConfigs.ESPT_L_CONFIG),
        new AbstractMap.SimpleEntry<>(_UT_TYPE_ESPT_M20,  UserTerminalConfigs.ESPT_M20_CONFIG),
        new AbstractMap.SimpleEntry<>(_UT_TYPE_ESPT_M3,   UserTerminalConfigs.ESPT_M3_CONFIG),
        new AbstractMap.SimpleEntry<>(_UT_TYPE_ESPT_S,    UserTerminalConfigs.ESPT_S_CONFIG),
        new AbstractMap.SimpleEntry<>(_UT_TYPE_MSPT_C,    UserTerminalConfigs.MSPT_C_CONFIG),
        new AbstractMap.SimpleEntry<>(_UT_TYPE_MSPT_M3,   UserTerminalConfigs.MSPT_M3_CONFIG),
        new AbstractMap.SimpleEntry<>(_UT_TYPE_MSPT_S,    UserTerminalConfigs.MSPT_S_CONFIG)
    );

    private final double _PERCENT_OF_DEMAND_MODEL_TO_INCLUDE = 10.0;

    List<String[]> demandModel;

    public UserTerminalsBuilder(String demandModelFilePath) {
        initialize(demandModelFilePath);
    }

    private List<String[]> parseCSV(String filename) {
        List<String[]> records = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                records.add(values);
            }
        } 
        catch (Exception e) {
            System.err.println("Error on openning file: " + e.getMessage());
        }
        return records;
    }

    private void initialize(String demandModelFilePath) {
        List<String[]> fullDemandModel = this.parseCSV(demandModelFilePath);
        if (!fullDemandModel.isEmpty()) {
            int totalNumRows = fullDemandModel.size();
            System.out.println(totalNumRows + " rows parsed from demand model file: " + demandModelFilePath);
            // Filters the demand model to only the percentage that should be
            // included in the instance.
            int samplesToKeep = (int)Math.round(totalNumRows * (_PERCENT_OF_DEMAND_MODEL_TO_INCLUDE / 100));
            this.demandModel = new ArrayList<>();
            for (int i = 0; i < samplesToKeep; i++) {
                /* '+ 1' is used to skip first line in the case of  i=0 */
                this.demandModel.add(fullDemandModel.get((i * (int)Math.round((double)totalNumRows / samplesToKeep)) + 1));
            }
            System.out.println(this.demandModel.size() + " rows kept for modelling");
        }
    }

    /* Returns a list of ANTENNA_PATTERN entities. */
    public List<Entity> generateAntennaPatterns() {

/*        """Returns a Spacetime ANTENNA_PATTERN Entity for each type of antenna
        on the user terminals in the demand model.
        """
        antenna_patterns = []
        terminal_types = set()
        # Determines the list of unique terminal types that should be modeled.
        for demand_model_row in self._demand_model:
            terminal_types.add(demand_model_row[self._TERMINAL_TYPE_COL_NAME])
        # Builds the antenna pattern corresponding to each terminal type.
        for terminal_type in terminal_types:
            user_terminal_config = self._TERMINAL_TYPE_TO_CONFIG.get(terminal_type)
            if user_terminal_config is not None:
                antenna_patterns.append(
                    ParabolicUserTerminalFactory.build_antenna_pattern_for_type(
                        user_terminal_config
                    )
                )
            else:
                # TODO: Raise ValueError once all terminal types are supported.
                print("UT terminal type is not supported: " + terminal_type)

        return antenna_patterns */
        Set<String> terminalTypes = new HashSet<>();
        List<Entity> antennaPatterns = new ArrayList<>();

        // Determine the list of unique terminal types that should be modelled.
        for (String[] demandModelRow : this.demandModel) {
            terminalTypes.add(demandModelRow[_TERMINAL_TYPE_COL_NAME]);
        }
        
        // Build the antenna pattern corresponding to each terminal type.
        for (String terminalType : terminalTypes) {
            ParabolicAntennaConfig config = this._TERMINAL_TYPE_TO_CONFIG.get(terminalType);
            if (config != null) {
            //if (this._TERMINAL_TYPE_TO_CONFIG.containsKey(terminalType)) {
            //if (terminalType.equals(_UT_TYPE_ESPT_C)) {
                antennaPatterns.add(ParabolicUserTerminalFactory.buildAntennaPatternForType(config));
            }
            // TODO: Model other user terminal types.
        }

        return antennaPatterns;
        /* 
        antenna_patterns = []
        terminal_types = set()
        # Determines the list of unique terminal types that should be modeled.
        for demand_model_row in self._demand_model:
            terminal_types.add(demand_model_row[self._TERMINAL_TYPE_COL_NAME])
        # Builds the antenna pattern corresponding to each terminal type.
        for terminal_type in terminal_types:
            if terminal_type == self._UT_TYPE_ESPT_C:
                antenna_patterns.append(
                    ParabolicUserTerminalFactory.build_antenna_pattern_for_type(
                        user_terminal_configs.ESPT_C_CONFIG
                    )
                )
            # TODO: Model other user terminal types.

        return antenna_patterns
        */
    }

    /* Returns a list of BAND_PROFILE entities. */
    public List<Entity> generateBandProfiles() {
        return new ArrayList<>();
    }

    /* Returns a list of INTERFACE_LINK_REPORT entities. */
    public List<Entity> generateInterfaceLinkReports() {
        return new ArrayList<>();
    }

    /* Returns a list of NETWORK_NODE entities. */
    public List<Entity> generateNetworkNodes() {
        /*
         *         
        """Returns a list of Spacetime NETWORK_NODE entities that represent the
        user terminals in the demand model.
        """
        network_nodes = []
        # The PoP network nodes are built in
        # groundsegment/ground_segment_builder.py.
        for demand_model_row in self._demand_model:
            terminal_type = demand_model_row[self._TERMINAL_TYPE_COL_NAME]
            for _ in range(demand_model_row[self._TERMINAL_COUNT_COL_NAME]):
                user_terminal_config = self._TERMINAL_TYPE_TO_CONFIG.get(terminal_type)
                if user_terminal_config is not None:
                    network_nodes.append(
                        ParabolicUserTerminalFactory.build_network_node(
                            config=user_terminal_config,
                            ut_name=UserTerminalUtils.get_ut_name(
                                demand_model_row[self._ID_COL_NAME]
                            ),
                        )
                    )
                else:
                    # TODO: Raise ValueError once all terminal type are supported.
                    print("UT terminal type is not supported: " + terminal_type)

        return network_nodes

         */

        List<Entity> networkNodes = new ArrayList<>();
        /* The PoP network nodes are built in groundsegment/ground_segment_builder.py. */

        for (String[] demandModelRow : this.demandModel) {
            String terminalType = demandModelRow[_TERMINAL_TYPE_COL_NAME];
            String terminalCount = demandModelRow[_TERMINAL_COUNT_COL_NAME];
            System.out.println("Terminal-type: " + terminalType + " Terminal-count: " + terminalCount);
            for (int i = 0; i < Integer.valueOf(terminalCount); i++) {
                ParabolicAntennaConfig userTerminalConfig = this._TERMINAL_TYPE_TO_CONFIG.get(terminalType);
                if (userTerminalConfig != null) {
                    networkNodes.add(ParabolicUserTerminalFactory.buildNetworkNode(userTerminalConfig, 
                                                                                   UserTerminalUtils.
                                                                                         getUTName(demandModelRow[_ID_COL_NAME])));
                }
            }
        }
        return networkNodes;
    }

    /* Returns a list of PLATFORM_DEFINITION entities. */
    public List<Entity> generatePlatforDefinitions() {
        return new ArrayList<>();
    }

    /* Returns a list of SERVICE_REQUEST entities. */
    public List<Entity> generateServiceRequests() {
        return new ArrayList<>();
    }

    /* Returns a list of NMTS Fragment messages. */
    public List<Entity> generateNmtsElements() {
        return new ArrayList<>();
    }

}
