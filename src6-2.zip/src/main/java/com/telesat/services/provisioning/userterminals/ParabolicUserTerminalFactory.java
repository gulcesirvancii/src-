package com.telesat.services.provisioning.userterminals;

import com.aalyria.spacetime.api.nbi.v1alpha.Nbi;
import com.aalyria.spacetime.api.nbi.v1alpha.resources.AntennaPatternOuterClass;
//import com.aalyria.spacetime.api.nbi.v1alpha.resources.AntennaPatternOuterClass.AntennaPattern;
import com.aalyria.spacetime.api.common.WirelessTransceiver;
import com.aalyria.spacetime.api.nbi.v1alpha.resources.NetworkElement;

import com.telesat.services.provisioning.networkwide.ParabolicAntennaConfig;
import com.telesat.services.provisioning.utils.Utils;
/**
 * A collection of methods that build Spacetime entities based on a
 * config that represents a type of user terminal.
 */
public class ParabolicUserTerminalFactory {

    // Callers should ensure that this method is only called once per type of UT,
    // since each type of UT shares the same antenna pattern. Otherwise,
    // duplicate ANTENNA_PATTERN entities will be created.
    /**
     * Returns an ANTENNA_PATTERN Entity that corresponds to the type of
     * user terminal specified by the config.
     * 
     * parameters:
     * config (ParabolicAntennaConfig): The parameters of a given type
     *                                  of user terminal.
     */
    public static Nbi.Entity buildAntennaPatternForType(ParabolicAntennaConfig config) {

        if (config.txAntennaDiameterM() <= 0) {
            System.err.println("Parabolic UT config " + config.configName() + " is \r\n" +
                               "missing tx_antenna_diameter_m.");
            return null;
        }
        if (config.txAntennaEfficiency() <= 0) {
            System.err.println("Parabolic UT config " + config.configName() + " is \r\n" +
                               "missing tx_antenna_efficiency.");
            return null;
        }
        if (config.rxAntennaDiameterM() <= 0) {
            System.err.println("Parabolic UT config " + config.configName() + " is \r\n" +
                               "missing rx_antenna_diameter_m.");
            return null;
        }
        if (config.rxAntennaEfficiency() <= 0) {
            System.err.println("Parabolic UT config " + config.configName() + " is \r\n" +
                               "missing rx_antenna_efficiency.");
            return null;
        }

        if (config.antennaPatternId().isEmpty()) {
            System.err.println("Parabolic UT config " + config.configName() + " is \r\n" +
                               "missing antenna_pattern_id.");
            return null;
        }

/*        return nbi_pb2.Entity(
            group=nbi_pb2.EntityGroup(type=nbi_pb2.EntityType.ANTENNA_PATTERN),
            id=cls.get_antenna_pattern_id(config),
            antenna_pattern=AntennaPattern(
                transmitter_and_receiver_pattern=AntennaPattern.TransmitterAndReceiverAntennaPattern(
                    transmitter_pattern=AntennaPattern(
                        parabolic_pattern=AntennaPattern.ParabolicAntennaPattern(
                            diameter_m=config.tx_antenna_diameter_m,
                            efficiency_percent=config.tx_antenna_efficiency,
                            backlobe_gain_db=utils.PARABOLIC_ANTENNA_PATTERN_DEFAULT_BACKLOBE_GAIN_DB,
                        )
                    ),
                    receiver_pattern=AntennaPattern(
                        parabolic_pattern=AntennaPattern.ParabolicAntennaPattern(
                            diameter_m=config.rx_antenna_diameter_m,
                            efficiency_percent=config.rx_antenna_efficiency,
                            backlobe_gain_db=utils.PARABOLIC_ANTENNA_PATTERN_DEFAULT_BACKLOBE_GAIN_DB,
                        ),
                    ),
                ),
            ),
        ) */

        /* Transmitter Parabolic Antenna Pattern */
        AntennaPatternOuterClass.AntennaPattern.ParabolicAntennaPattern.Builder transmitterParabolicPatternBuilder = 
                                                               AntennaPatternOuterClass.AntennaPattern.ParabolicAntennaPattern.newBuilder();
        transmitterParabolicPatternBuilder.setDiameterM(config.txAntennaDiameterM());
        transmitterParabolicPatternBuilder.setEfficiencyPercent(config.txAntennaEfficiency());
        transmitterParabolicPatternBuilder.setBacklobeGainDb(Utils.PARABOLIC_ANTENNA_PATTERN_DEFAULT_BACKLOBE_GAIN_DB);

        AntennaPatternOuterClass.AntennaPattern.ParabolicAntennaPattern transmitterParabolicPattern = transmitterParabolicPatternBuilder.build();

        /* Transmitter Antenna Pattern */
        AntennaPatternOuterClass.AntennaPattern.Builder transmitterPatternBuilder = AntennaPatternOuterClass.AntennaPattern.newBuilder();
        transmitterPatternBuilder.setParabolicPattern(transmitterParabolicPattern);
        AntennaPatternOuterClass.AntennaPattern transmitterPattern = transmitterPatternBuilder.build();
        
        /* Receiver Parabolic Antenna Pattern */
        AntennaPatternOuterClass.AntennaPattern.ParabolicAntennaPattern.Builder receiverParabolicPatternBuilder = 
                                                               AntennaPatternOuterClass.AntennaPattern.ParabolicAntennaPattern.newBuilder();
        receiverParabolicPatternBuilder.setDiameterM(config.rxAntennaDiameterM());
        receiverParabolicPatternBuilder.setEfficiencyPercent(config.rxAntennaEfficiency());
        receiverParabolicPatternBuilder.setBacklobeGainDb(Utils.PARABOLIC_ANTENNA_PATTERN_DEFAULT_BACKLOBE_GAIN_DB);

        AntennaPatternOuterClass.AntennaPattern.ParabolicAntennaPattern receiverParabolicPattern = receiverParabolicPatternBuilder.build();

        /* Receiver Antenna Pattern */
        AntennaPatternOuterClass.AntennaPattern.Builder receiverPatternBuilder = AntennaPatternOuterClass.AntennaPattern.newBuilder();
        receiverPatternBuilder.setParabolicPattern(receiverParabolicPattern);
        AntennaPatternOuterClass.AntennaPattern receiverPattern = receiverPatternBuilder.build();

        /* Transmitter and Receiver Antenna Pattern */
        AntennaPatternOuterClass.AntennaPattern.TransmitterAndReceiverAntennaPattern.Builder transmitterAndReceiverAntennaPatternBuilder =
                                                       AntennaPatternOuterClass.AntennaPattern.TransmitterAndReceiverAntennaPattern.newBuilder();
        transmitterAndReceiverAntennaPatternBuilder.setTransmitterPattern(transmitterPattern);
        transmitterAndReceiverAntennaPatternBuilder.setReceiverPattern(receiverPattern);
        AntennaPatternOuterClass.AntennaPattern.TransmitterAndReceiverAntennaPattern transmitterAndReceiverAntennaPattern = 
                                                                                             transmitterAndReceiverAntennaPatternBuilder.build();

        /* Antenna Pattern */
        AntennaPatternOuterClass.AntennaPattern.Builder antennaPatternBuilder = AntennaPatternOuterClass.AntennaPattern.newBuilder();
        antennaPatternBuilder.setTransmitterAndReceiverPattern(transmitterAndReceiverAntennaPattern);
        AntennaPatternOuterClass.AntennaPattern antennaPattern = antennaPatternBuilder.build();

        Nbi.EntityGroup.Builder groupBuilder = Nbi.EntityGroup.newBuilder();
        groupBuilder.setType(Nbi.EntityType.ANTENNA_PATTERN);
        Nbi.EntityGroup group = groupBuilder.build();

        Nbi.Entity.Builder entityBuilder = Nbi.Entity.newBuilder();
        entityBuilder.setGroup(group);
        entityBuilder.setId(Utils.formatStringForEntityId(config.antennaPatternId()));
        entityBuilder.setAntennaPattern(antennaPattern);

        Nbi.Entity entity = entityBuilder.build();
        
        return entity;
    }

    public String getAntennaPatternId(ParabolicAntennaConfig config) {
        if (config.antennaPatternId().isEmpty()) {
            System.err.println("Parabolic UT config " + config.configName() + " is \r\n" +
                               "missing antenna_pattern_id.");
            return null;
        }
        return Utils.formatStringForEntityId(config.antennaPatternId());
    }

    public static Nbi.Entity buildNetworkNode(ParabolicAntennaConfig config, String utName) {

    /*  """Returns a NETWORK_NODE Entity to model a user terminal whose type
        is defined by the provided config.

        args:
            config (ParabolicAntennaConfig): The parameters of a given type
                of user terminal.
            ut_name (str): The name of the user terminal, as determined by
                user_terminal_utils.get_ut_name().
        """
        network_interfaces = [
            network_element_pb2.NetworkInterface(
                interface_id=transceiver_model_id,
                wireless=network_element_pb2.WirelessDevice(
                    transceiver_model_id=wireless_transceiver_pb2.TransceiverModelId(
                        platform_id=UserTerminalUtils.get_platform_definition_id(
                            ut_name
                        ),
                        transceiver_model_id=transceiver_model_id,
                    ),
                ),
            )
            for transceiver_model_id in cls._TRANSCEIVER_MODEL_IDS
        ] + [
            network_element_pb2.NetworkInterface(
                interface_id=UserTerminalUtils.get_local_network_interface_id(),
                wired=network_element_pb2.WiredDevice(),
            ),
        ]
        SrMplsSidAllocator.assign_adjacency_sids_in_place(network_interfaces)

        return nbi_pb2.Entity(
            id=UserTerminalUtils.get_network_node_id(ut_name),
            group=nbi_pb2.EntityGroup(type=nbi_pb2.EntityType.NETWORK_NODE),
            network_node=network_element_pb2.NetworkNode(
                name=ut_name,
                node_id=UserTerminalUtils.get_network_node_id(ut_name),
                type=utils.USER_TERMINAL_TYPE,
                category_tag=utils.USER_TERMINAL_CATEGORY_TAG,
                routing_config=network_element_pb2.NetworkNode.RoutingConfiguration(
                    node_sid=ietf_pb2.SegmentId(
                        mpls=SrMplsSidAllocator.get_next_user_terminal_node_sid()
                    )
                ),
                node_interface=network_interfaces,
                # TODO: This can be uncommented once the nodes are
                # ready to have CDPI agents configured.
                # agent=network_element_pb2.SdnAgent(
                #     type="AIRFLOW",
                #     maximum_control_plane_latency={
                #         0: duration_pb2.Duration(seconds=5)
                #     },
                # ),
                subnet=[cls._DEFAULT_SUBNET],
            ),
        )
*/
        WirelessTransceiver.TransceiverModelId.Builder transceiverModelIdBuilder = WirelessTransceiver.TransceiverModelId.newBuilder();
        transceiverModelIdBuilder.setPlatformId(UserTerminalUtils.getPlatformDefinitionId(utName));
        NetworkElement.WirelessDevice.Builder wirelessDeviceBuilder = NetworkElement.WirelessDevice.newBuilder();
        wirelessDeviceBuilder.setPlatform(utName);

        return null;
    }
}
