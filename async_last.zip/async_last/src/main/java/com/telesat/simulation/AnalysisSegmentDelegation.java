package com.telesat.simulation;

import java.util.List;
import java.util.ArrayList;
//import java.time.Duration;

import org.slf4j.Logger;

import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass;

public class AnalysisSegmentDelegation {
    
    /* Delegated AnalysisSegment */
    SimulationOuterClass.AnalysisSegment analysisSegment;

    com.google.type.Interval interval;

    /* Path samples per P2pSrTePolicyCandidatePath of this AnaysisSegment */
    List<P2pSrTePolicyCandidatePathSamples> pathSamples;

    Logger logger;

    AnalysisSegmentDelegation(com.google.type.Interval interval, int pathCount, double cirMin, double cirMax, 
                              double eirMin, double eirMax, double fdMin, double fdMax, double ifdvMin, 
                              double ifdvMax, int sampleCount, Logger logger) {
        this.interval = interval;
        this.pathSamples = new ArrayList<>();
        this.logger = logger;

        logger.info("Creating AnalysisSegment for interval: '{}_{}' - '{}_{}'", interval.getStartTime().getSeconds(), 
                    interval.getStartTime().getNanos(), interval.getEndTime().getSeconds(), interval.getEndTime().getNanos());

        SimulationOuterClass.AnalysisSegment.Builder bder = SimulationOuterClass.AnalysisSegment.newBuilder().setInterval(this.interval);
        for (int i = 0; i < pathCount; i++) {
            String name = "test-path-" + Integer.toString(i);
            P2pSrTePolicyCandidatePathSamples pathSample = new P2pSrTePolicyCandidatePathSamples(name, cirMin, cirMax, eirMin, eirMax, fdMin, fdMax, 
                                                                                                 ifdvMin, ifdvMax, sampleCount);
            this.pathSamples.add(pathSample);
            SimulationOuterClass.P2pSrTePolicyCandidatePathStats.Builder pathBuilder = obtainP2pSrTePolicyCandidatePathStats(name, pathSample);
            bder.addP2PSrTePolcyCandidatePathStats(pathBuilder);
        }
        /* TODO: We will build analysisSegment after all segments are filled with path-values and corresponding
           percentiles are calculated per path. */
        
        this.analysisSegment = bder.build();
    }

    public SimulationOuterClass.P2pSrTePolicyCandidatePathStats.Builder obtainP2pSrTePolicyCandidatePathStats(String pathName, 
                                                                                                              P2pSrTePolicyCandidatePathSamples sample) {

        SimulationOuterClass.P2pSrTePolicyCandidatePathStats.Builder stats = SimulationOuterClass.P2pSrTePolicyCandidatePathStats.newBuilder();

        stats.setPath(pathName);

        stats.setCirAvgBps(sample.cirGetAverage());
        stats.setCirStddevBps(sample.cirGetStdDev());
        stats.setCirMinBps(sample.cirGetMin());
        stats.setCirMaxBps(sample.cirGetMax());
        stats.setCirPercentile(sample.cirGetPercentile());

        stats.setEirAvgBps(sample.eirGetAverage());
        stats.setEirStddevBps(sample.eirGetStdDev());
        stats.setEirMinBps(sample.eirGetMin());
        stats.setEirMaxBps(sample.eirGetMax());
        stats.setEirPercentile(sample.eirGetPercentile());

        java.time.Duration fdTempDur = java.time.Duration.ofMillis((long)sample.fdGetAverage()); 
        stats.setFrameDelayAvg(com.google.protobuf.Duration.newBuilder().setSeconds(fdTempDur.getSeconds()).setNanos(fdTempDur.getNano()));
        fdTempDur = java.time.Duration.ofMillis((long)sample.fdGetStdDev());
        stats.setFrameDelayStddev(com.google.protobuf.Duration.newBuilder().setSeconds(fdTempDur.getSeconds()).setNanos(fdTempDur.getNano()));
        fdTempDur = java.time.Duration.ofMillis((long)sample.fdGetMin());
        stats.setFrameDelayMin(com.google.protobuf.Duration.newBuilder().setSeconds(fdTempDur.getSeconds()).setNanos(fdTempDur.getNano()));
        fdTempDur = java.time.Duration.ofMillis((long)sample.fdGetMax());
        stats.setFrameDelayMax(com.google.protobuf.Duration.newBuilder().setSeconds(fdTempDur.getSeconds()).setNanos(fdTempDur.getNano()));
        stats.setFrameDelayPercentile(sample.fdGetPercentile());


        fdTempDur = java.time.Duration.ofMillis((long)sample.ifdvGetAverage());
        stats.setIfdvAvg(com.google.protobuf.Duration.newBuilder().setSeconds(fdTempDur.getSeconds()).setNanos(fdTempDur.getNano()));
        fdTempDur = java.time.Duration.ofMillis((long)sample.ifdvGetStdDev());
        stats.setIfdvStddev(com.google.protobuf.Duration.newBuilder().setSeconds(fdTempDur.getSeconds()).setNanos(fdTempDur.getNano()));
        fdTempDur = java.time.Duration.ofMillis((long)sample.ifdvGetMin());
        stats.setIfdvMin(com.google.protobuf.Duration.newBuilder().setSeconds(fdTempDur.getSeconds()).setNanos(fdTempDur.getNano()));
        fdTempDur = java.time.Duration.ofMillis((long)sample.ifdvGetMax());
        stats.setIfdvMax(com.google.protobuf.Duration.newBuilder().setSeconds(fdTempDur.getSeconds()).setNanos(fdTempDur.getNano()));
        stats.setIfdvPercentile(sample.ifdvGetPercentile());

        this.logger.info("Obtained path data --\n" + 
                         "    CIR.average: '{}', CIR.stddev: '{}', CIR.min: '{}', CIR.max: '{}', CIR.percentile: '{}'\n" +
                         "    EIR.average: '{}', EIR.stddev: '{}', EIR.min: '{}', EIR.max: '{}', EIR.percentile: '{}'\n" +
                         "    FD.average: '{}', FD.stddev: '{}', FD.min: '{}', FD.max: '{}', FD.percentile: '{}'\n" +
                         "    IFDV.average: '{}', IFDV.stddev: '{}', IFDV.min: '{}', IFDV.max: '{}', IFDV.percentile: '{}'\n",
                         String.format("%.3f", stats.getCirAvgBps()), String.format("%.3f", stats.getCirStddevBps()), 
                         String.format("%.3f", stats.getCirMinBps()), String.format("%.3f", stats.getCirMaxBps()), String.format("%.3f", stats.getCirPercentile()),
                         String.format("%.3f", stats.getEirAvgBps()), String.format("%.3f", stats.getEirStddevBps()), 
                         String.format("%.3f", stats.getEirMinBps()), String.format("%.3f", stats.getEirMaxBps()), String.format("%.3f", stats.getEirPercentile()),
                         String.format("%.3f", sample.fdGetAverage()), String.format("%.3f", sample.fdGetStdDev()), 
                         String.format("%.3f", sample.fdGetMin()), String.format("%.3f", sample.fdGetMax()), String.format("%.3f", sample.fdGetPercentile()),
                         String.format("%.3f", sample.ifdvGetAverage()), String.format("%.3f", sample.ifdvGetStdDev()), 
                         String.format("%.3f", sample.ifdvGetMin()), String.format("%.3f", sample.ifdvGetMax()), String.format("%.3f", sample.ifdvGetPercentile()));
        
        return stats;
    }

    public SimulationOuterClass.AnalysisSegment getAnalysisSegment() {
        return this.analysisSegment;
    }
}
