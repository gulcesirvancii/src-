package com.telesat.simulation;

public class P2pSrTePolicyCandidatePathSamples 
{
    String pathName; /* to be used as an identifier */

    double cirConfiguredMin;
    double cirConfiguredMax;

    double eirConfiguredMin;
    double eirConfiguredMax;
    
    double fdConfiguredMin;
    double fdConfiguredMax;
    
    double ifdvConfiguredMin;
    double ifdvConfiguredMax;

    int sampleCount;
    
    DataGenerator cirSamples;
    double cirPercentile; /* percentiel  of each data-block of cirValue in that group */

    DataGenerator eirSamples;
    double eirPercentile;

    DataGenerator fdSamples;
    double fdPercentile;

    DataGenerator ifdvSamples;
    double ifdvPercentile;

    public P2pSrTePolicyCandidatePathSamples(String name, double cirMin, double cirMax, double eirMin, double eirMax,
                                             double fdMin, double fdMax, double ifdvMin, double ifdvMax, int sampleCount) {
        this.pathName = name;

        this.cirConfiguredMin  = cirMin;
        this.cirConfiguredMax  = cirMax;
        this.eirConfiguredMin  = eirMin;
        this.eirConfiguredMax  = eirMax;
        this.fdConfiguredMin   = fdMin;
        this.fdConfiguredMax   = fdMax;
        this.ifdvConfiguredMin = ifdvMin;
        this.ifdvConfiguredMax = ifdvMax;
        this.sampleCount       = sampleCount;

        this.cirSamples = new DataGenerator(this.cirConfiguredMin, this.cirConfiguredMax, this.sampleCount);
        this.eirSamples = new DataGenerator(this.eirConfiguredMin, this.eirConfiguredMax, this.sampleCount);
        this.fdSamples  = new DataGenerator(this.fdConfiguredMin, this.fdConfiguredMax, this.sampleCount);
        this.ifdvSamples  = new DataGenerator(this.ifdvConfiguredMin, this.ifdvConfiguredMax, this.sampleCount);
    }

    public String getName() {
        return this.pathName;
    }
    
    // CIR getters
    public double cirGetAverage() {
        return this.cirSamples.getAverage();
    }

    public double cirGetStdDev() {
        return this.cirSamples.getStdDev();
    }

    public double cirGetMin() {
        return this.cirSamples.getMinValue();
    }

    public double cirGetMax() {
        return this.cirSamples.getMaxValue();
    }

    public double cirGetPercentile() {
        return this.cirPercentile;
    }

    // EIR getters
    public double eirGetAverage() {
        return this.eirSamples.getAverage();
    }

    public double eirGetStdDev() {
        return this.eirSamples.getStdDev();
    }

    public double eirGetMin() {
        return this.eirSamples.getMinValue();
    }

    public double eirGetMax() {
        return this.eirSamples.getMaxValue();
    }

    public double eirGetPercentile() {
        return this.eirPercentile;
    }

    // Frame Delay getters
    public double fdGetAverage() {
        return this.fdSamples.getAverage();
    }

    public double fdGetStdDev() {
        return this.fdSamples.getStdDev();
    }

    public double fdGetMin() {
        return this.fdSamples.getMinValue();
    }

    public double fdGetMax() {
        return this.fdSamples.getMaxValue();
    }

    public double fdGetPercentile() {
        return this.fdPercentile;
    }

    // Inter-Frame Delay Variations getters
    public double ifdvGetAverage() {
        return this.ifdvSamples.getAverage();
    }

    public double ifdvGetStdDev() {
        return this.ifdvSamples.getStdDev();
    }

    public double ifdvGetMin() {
        return this.ifdvSamples.getMinValue();
    }

    public double ifdvGetMax() {
        return this.ifdvSamples.getMaxValue();
    }

    public double ifdvGetPercentile() {
        return this.ifdvPercentile;
    }
}
