package com.telesat.simulation;

//import java.security.Timestamp;
import java.time.Instant;
import java.util.concurrent.TimeUnit;
import java.util.List;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.inprocess.InProcessChannelBuilder;
import io.grpc.Grpc;
import io.grpc.InsecureChannelCredentials;
import io.grpc.StatusRuntimeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aalyria.spacetime.simulation.v1alpha.SimulationServiceGrpc;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.type.Interval;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass;

public class SimulationClient {
    private static final Logger logger = LoggerFactory.getLogger(SimulationClient.class);
    
    private final ManagedChannel channel;
    private final SimulationServiceGrpc.SimulationServiceBlockingStub blockingStub;
    private final SimulationServiceGrpc.SimulationServiceStub asyncStub;
    
    /**
     * Construct client connecting to the server at {@code host:port}.
     */
    public SimulationClient(String host, int port) {
        this(ManagedChannelBuilder.forAddress(host, port)
                // Channels are secure by default (via SSL/TLS). For the example we disable TLS to avoid
                // needing certificates.
                .usePlaintext()
                .build());
    }

    /**
     * Construct client connecting to an in-process server by name (no network sockets).
     */
    public static SimulationClient forInProcess(String inProcessName) {
        ManagedChannel ch = InProcessChannelBuilder.forName(inProcessName)
                .directExecutor()
                .build();
        return new SimulationClient(ch);
    }
    
    /**
     * Construct client for accessing SimulationService using the existing channel.
     */
    SimulationClient(ManagedChannel channel) {
        this.channel = channel;
        blockingStub = SimulationServiceGrpc.newBlockingStub(channel);
        asyncStub = SimulationServiceGrpc.newStub(channel);
    }
    
    /**
     * Shutdown the channel
     */
    public void shutdown() throws InterruptedException {
        channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
    }
    
    public int createScenario(String scenarioId, String scenarioName, String description) {
        logger.info("Creating scenario: '{}' with name: '{}' with desription: '{}'", 
                    scenarioId, scenarioName, description);

        SimulationOuterClass.Scenario sc = SimulationOuterClass.Scenario.newBuilder()
                                                                        .setName(scenarioName)
                                                                        .setDescription(description)
                                                                        .build();
        SimulationOuterClass.CreateScenarioRequest request = SimulationOuterClass.CreateScenarioRequest.newBuilder()
                                                                                                       .setScenarioId(scenarioId)
                                                                                                       .setScenario(sc)
                                                                                                       .build();
        
        try {
            SimulationOuterClass.Scenario response = blockingStub.createScenario(request);
            logger.info("CreateScenario response: scenario-name='{}', description='{}'", 
                        response.getName(), response.getDescription());
        } 
        catch (StatusRuntimeException e) {
            logger.error("RPC failed: {}", e.getStatus());
            return 1;
        }

        return 0;
    } 

    /* proto format of GetScenario:
     * message GetScenarioRequest {
     *   // Required. The name of the scenario to retrieve.
     *   // Format: scenarios/{scenario}
     *   string name = 1;
     * }
     * We consider 'scenarioName' is not int the for above, so it will be prefixed with 'scenarios/'
     */
    public SimulationOuterClass.Scenario getScenario(String scenarioName) {
        logger.info("Get scenario with name: '{}'", scenarioName);

        String formedScName = "scenarios/" + scenarioName;
        SimulationOuterClass.GetScenarioRequest request = SimulationOuterClass.GetScenarioRequest.newBuilder()
                                                                                                 .setName(formedScName)
                                                                                                 .build();
        try {
            SimulationOuterClass.Scenario response = blockingStub.getScenario(request);
            logger.info("GetScenario response: scenario-name='{}', description='{}'", 
                        response.getName(), response.getDescription());
            return response;
        } 
        catch (StatusRuntimeException e) {
            logger.error("RPC failed: {}", e.getStatus());
            /* Return an empty Scenario instance */
            return SimulationOuterClass.Scenario.newBuilder().setName("").build();
        }
    }

    /* Creates Simulation instance with specified attributes, 
     * which is ready for sending create-simulation request to the server.
     * 'startSeconds' and 'startNanos', 'endSeconds' and 'endTime' shall indicate timestamps for the 'interval'
     * */
    public SimulationOuterClass.Simulation createSimulation(String simulationName, long startSeconds, int startNanos, long endSeconds, int endNanos) {

        logger.info("Create simulation with simulation-name: '{}', start-seconds: '{}', start-nanos: '{}', end-seconds: '{}', end-nanos: '{}'",
                    simulationName, startSeconds, startNanos, endSeconds, endNanos);

        com.google.protobuf.Timestamp stimestamp = com.google.protobuf.Timestamp.newBuilder().setSeconds(startSeconds).setNanos(startNanos).build();
        com.google.protobuf.Timestamp etimestamp = com.google.protobuf.Timestamp.newBuilder().setSeconds(endSeconds).setNanos(endNanos).build();
        
        String simname = "simulations/" + simulationName;
        com.google.type.Interval interval = com.google.type.Interval.newBuilder().setStartTime(stimestamp).setEndTime(etimestamp).build();
        /* 'scenario' attribute will be assigned when this simuation is attached to a scenario */
        return SimulationOuterClass.Simulation.newBuilder().setName(simname).setInterval(interval).build();
    }

    /* Sends a create-smimulation request to the server for creation a simulation for the scenario specified with 'scenarioName' */
    public com.google.longrunning.Operation createSimulationForScenario(String scenarioName, String simulationId, SimulationOuterClass.Simulation simulation) {

        logger.info("Create simulation with scenario-name: '{}', simulation-id: '{}', name: '{}', start-time: '{}', end-time: '{}'",
                    scenarioName, simulationId, simulation.getName(), 
                    simulation.getInterval().getStartTime().getSeconds() + "_" + simulation.getInterval().getStartTime().getNanos(),
                    simulation.getInterval().getEndTime().getSeconds() + "_" + simulation.getInterval().getEndTime().getNanos());

        String snname = "scenarios/" + scenarioName;
        /* TODO: This method (update fields of a built message) may not be good way for realtime performance purposes. 
                 We may choose another approach. 
         */
        SimulationOuterClass.Simulation upsim = simulation.toBuilder().setScenario(snname).build(); 
        SimulationOuterClass.CreateSimulationRequest request = SimulationOuterClass.CreateSimulationRequest.newBuilder()
                                                                                                           .setSimulationId(simulationId)
                                                                                                           .setSimulation(upsim)
                                                                                                           .build();
        try {
            com.google.longrunning.Operation response = blockingStub.createSimulation(request);
            logger.info("Response to CreateSimulationRequest: operation-name='{}', is-done:='{}', code='{}'", 
                        response.getName(), response.getDone(), response.getError().getCode());
            return response;
        } 
        catch (StatusRuntimeException e) {
            logger.error("RPC failed: {}", e.getStatus());
            /* Return an errored operation. */
            com.google.rpc.Status status = com.google.rpc.Status.newBuilder()
                                                                .setCode(com.google.rpc.Code.DEADLINE_EXCEEDED_VALUE)
                                                                .setMessage("Runtime exception: " + e.getMessage())
                                                                .build();
            return com.google.longrunning.Operation.newBuilder().setName("").setDone(true).setError(status).build();
        }
    }

    /* Although it is not clear that 'name' attribute shall be based on simulation-id used during creation or name attribute
       of the simulation, we consider it as name attribute */
    public SimulationOuterClass.Simulation getSimulation(String simulationName) {
        logger.info("Get simulation with name: '{}'", simulationName);

        String formedSimName = "simulations/" + simulationName;
        SimulationOuterClass.GetSimulationRequest request = SimulationOuterClass.GetSimulationRequest.newBuilder()
                                                                                                     .setName(formedSimName)
                                                                                                     .build();
        try {
            SimulationOuterClass.Simulation response = blockingStub.getSimulation(request);
            logger.info("getSimulation response: simulation-name='{}', scenario-name='{}', state='{}', " +
                        "create-timestamp='{}', interval=(start='{}_{}', end='{}_{})", 
                        response.getName(), response.getScenario(), response.getState(), response.getCreateTime(), 
                        response.getInterval().getStartTime().getSeconds(), response.getInterval().getStartTime().getNanos(),
                        response.getInterval().getEndTime().getSeconds(), response.getInterval().getEndTime().getNanos());
            return response;
        } 
        catch (StatusRuntimeException e) {
            logger.error("RPC failed: {}", e.getStatus());
            /* Return an empty Scenario instance */
            return SimulationOuterClass.Simulation.newBuilder().setName("").build();
        }

    }

    /* Creates an Analysis instance for local usage, from client side point of view */
    public SimulationOuterClass.Analysis constructAnalysis(String scenarioName, String analysisName, 
                                                            com.google.type.Interval interval, com.google.protobuf.Duration resolution) {

        logger.info("Constructing Analysis object for scenario: '{}' with name: '{}' for start: '{}_{}' and end: '{}_{}' interval with resolution: '{}_{}'",
                    scenarioName, analysisName, interval.getStartTime().getSeconds(), interval.getStartTime().getNanos(),
                    interval.getEndTime().getSeconds(), interval.getEndTime().getNanos(),
                    resolution.getSeconds(), resolution.getNanos());

        // name shall be in the form of 'scenarios/{scenario}/analyses/{analysis}'
        String name = "scenarios/" + scenarioName + "/analyses/" + analysisName;
        return SimulationOuterClass.Analysis.newBuilder()
                                            .setName(name)
                                            .setInterval(interval)
                                            .setResolution(resolution)
                                            .build();
    }

    /* 'parent' shall be in the form of 'simulations/{simulation}' as indicating the simulation in which this analysis will be created. */
    public SimulationOuterClass.Analysis createAnalysis(String simulation, String id, SimulationOuterClass.Analysis analysis) {

        logger.info("Create analysis with id: '{}' and name: '{}' for simulation: '{}' with interval: '{}_{}-{}_{}' and resolution: '{}_{}'",
                    id, analysis.getName(), simulation, 
                    analysis.getInterval().getStartTime().getSeconds(), analysis.getInterval().getStartTime().getNanos(), 
                    analysis.getInterval().getEndTime().getSeconds(), analysis.getInterval().getEndTime().getNanos(),
                    analysis.getResolution().getSeconds(), analysis.getResolution().getNanos());

        /* 'parent' of the request shall be in the form of 'simulations/{simulation}' */
        String parent = "simulations/" + simulation;
        SimulationOuterClass.CreateAnalysisRequest request = SimulationOuterClass.CreateAnalysisRequest.newBuilder()
                                                                                                       .setParent(parent)
                                                                                                       .setAnalysisId(id)
                                                                                                       .setAnalysis(analysis)
                                                                                                       .build();

        try {
            SimulationOuterClass.Analysis response = blockingStub.createAnalysis(request);
            logger.info("Got response for 'createAnalysis with name: '{}' ", response.getName());
            return response;
        }
        catch (StatusRuntimeException e) {
            logger.error("createAnalysis: RPC failed: {}", e.getStatus());
            /* Return an empty Scenario instance */
            return null; 
        }
    }

    public SimulationOuterClass.Analysis getAnalysis(String analysisName, String parentSimulation) {
        logger.info("getAnalysis: Get request for analysis: '{}' for parent simulation: '{}'", analysisName, parentSimulation);

        /* 'name' of the request shall be in the form of 'simulations/{simulation}/analyses/{analysis}' */
        String name = "simulations/" + parentSimulation + "/analyses/" + analysisName;
        SimulationOuterClass.GetAnalysisRequest request = SimulationOuterClass.GetAnalysisRequest.newBuilder()
                                                                                                 .setName(name)
                                                                                                 .build();
        try {
            SimulationOuterClass.Analysis response = blockingStub.getAnalysis(request);
            logger.info("Got response for 'getAnalysis with name: '{}' ", response.getName());
            return response;
        }
        catch (StatusRuntimeException e) {
            logger.error("getAnalysis: RPC failed: {}", e.getStatus());
            /* Return an empty Scenario instance */
            return null; 
        }
    }

    /* Logs details of analysis (and to process on provided anaysis data (later)) */
    public void detailsOfAnalysis(SimulationOuterClass.Analysis analysis) {
        List<SimulationOuterClass.AnalysisSegment> analysisList = analysis.getSegmentsList();
        int anSegmentCount = (analysisList != null) ? analysisList.size() : 0;
        logger.info("detailsOfAnaysis: Successfully created Analysis with name: '{}', analysis-segment count: '{}'", analysis.getName(), anSegmentCount);
        for (int i = 0; i < anSegmentCount; i++) {
            SimulationOuterClass.AnalysisSegment aSegment = analysisList.get(i);
            List<SimulationOuterClass.P2pSrTePolicyCandidatePathStats> paths = aSegment.getP2PSrTePolcyCandidatePathStatsList();
            logger.info("detailsOfAnalysis: Number of paths: '{}'", paths.size());
            for (int j = 0; j < paths.size(); j++) {
                SimulationOuterClass.P2pSrTePolicyCandidatePathStats stats = paths.get(j);
                logger.info("detailsOfAnalysis: path stats [{}, {}] -- \n" +
                            "    CIR.average: '{}', CIR.stddev: '{}', CIR.min: '{}', CIR.max: '{}', CIR.percentile: '{}'\n" +
                            "    EIR.average: '{}', EIR.stddev: '{}', EIR.min: '{}', EIR.max: '{}', EIR.percentile: '{}'\n" +
                            "    FD.average: '{}_{}', FD.stddev: '{}_{}', FD.min: '{}_{}', FD.max: '{}_{}', FD.percentile: '{}'\n" +
                            "    IFDV.average: '{}_{}', IFDV.stddev: '{}_{}', IFDV.min: '{}_{}', IFDV.max: '{}_{}', IFDV.percentile: '{}'\n",
                            i, j,
                            String.format("%.3f", stats.getCirAvgBps()), String.format("%.3f", stats.getCirStddevBps()), 
                            String.format("%.3f", stats.getCirMinBps()), String.format("%.3f", stats.getCirMaxBps()), String.format("%.3f", stats.getCirPercentile()),
                            String.format("%.3f", stats.getEirAvgBps()), String.format("%.3f", stats.getEirStddevBps()), 
                            String.format("%.3f", stats.getEirMinBps()), String.format("%.3f", stats.getEirMaxBps()), String.format("%.3f", stats.getEirPercentile()),
                            stats.getFrameDelayAvg().getSeconds(), stats.getFrameDelayAvg().getNanos(), 
                            stats.getFrameDelayStddev().getSeconds(), stats.getFrameDelayStddev().getNanos(),
                            stats.getFrameDelayMin().getSeconds(), stats.getFrameDelayMin().getNanos(),
                            stats.getFrameDelayMax().getSeconds(), stats.getFrameDelayMax().getNanos(),
                            stats.getFrameDelayPercentile(),
                            stats.getIfdvAvg().getSeconds(), stats.getIfdvAvg().getNanos(), 
                            stats.getIfdvStddev().getSeconds(), stats.getIfdvStddev().getNanos(),
                            stats.getIfdvMin().getSeconds(), stats.getIfdvMin().getNanos(),
                            stats.getIfdvMax().getSeconds(), stats.getIfdvMax().getNanos(),
                            stats.getIfdvPercentile());
            }
        }
    }

    /**
     * Run a complete simulation workflow
     * @throws InterruptedException 
     * @throws InvalidProtocolBufferException 
     */
    public void runSimulationWorkflow() throws InterruptedException, InvalidProtocolBufferException {
        String scenarioId = "test-scenario:" + System.currentTimeMillis();
        String scenarioName = "test-scenario";
        String scenarioDescription = "Test for Spacetime scenario API.";

        String simulationName = "test-simulation";
        String simulationId = simulationName + ":" + System.currentTimeMillis();

        logger.info("=== Starting Simulation Workflow ===");
        
        // 1. Create scenario
        createScenario(scenarioId, scenarioName, scenarioDescription);
        Thread.sleep(1000);
        // Second try to create
        createScenario(scenarioId, scenarioName, scenarioDescription);
        
        // Get scenario
        SimulationOuterClass.Scenario gsc = getScenario(scenarioName);
        logger.info("Got scenario for name: '{}' -- scenario-name: '{}', description: '{}'",
                    scenarioName, gsc.getName(), gsc.getDescription());

        // 3. Create Simulation
        /* TODO: 'seconds' and 'nanos' for time values shall be provided through DateTime objects for both start-time and end-time */
        // If we compute Timestamp from`System.currentTimeMillis()`.
        long millis = System.currentTimeMillis();
        long seconds = millis/ 1000;
        int nanos = (int)((millis % 1000) * 1000000);
        logger.info("Timestamps by using currentTimeMillis: seconds: '{}', nanos: '{}'", seconds, nanos);
        // If we compute Timestamp from `Instant.now()`.
        Instant now = Instant.now();
        seconds = now.getEpochSecond();
        nanos = now.getNano();
        // logger.info("Now: timestamp: '{}_{}' -- '{}'", now.getEpochSecond(), now.getNano(), now);
        // Instant now5 = now.plusSeconds(5);
        // logger.info("Now+5: timestamp: '{}_{}' -- '{}'", now5.getEpochSecond(), now5.getNano(), now5);
        // Instant now25 = now.plusSeconds(25);
        // logger.info("Now+25: timestamp: '{}_{}' -- '{}'", now25.getEpochSecond(), now25.getNano(), now25);
        logger.info("Timestamps by using Instant.now(): seconds: '{}', nanos: '{}'", seconds, nanos);
        /* Create simulation starting 5 seconds later from 'now' for 20 seconds */
        SimulationOuterClass.Simulation sim  = createSimulation(simulationName, now.plusSeconds(5).getEpochSecond(), nanos, 
                                                                now.plusSeconds(25).getEpochSecond(), nanos);
        com.google.longrunning.Operation op1 = createSimulationForScenario(scenarioName, simulationId, sim);
        logger.info("Result of simulation creation -- operation-nmae: '{}', is-done: '{}'",
                    op1.getName(), op1.getDone());
        if ((op1.hasMetadata()) && (op1.getMetadata().is(SimulationOuterClass.CreateSimulationMetadata.class))) {
            SimulationOuterClass.CreateSimulationMetadata metadata = op1.getMetadata().unpack(SimulationOuterClass.CreateSimulationMetadata.class);
            logger.info("Received percentage of processing through metadata: '{}%'", metadata.getProgressPercent());
        }

        // 3a. Re-create simulation (to test progress-percent increase)
        op1 = createSimulationForScenario(scenarioName, simulationId, sim);
        logger.info("(2) Result of simulation creation -- operation-nmae: '{}', is-done: '{}'",
                    op1.getName(), op1.getDone());
        if ((op1.hasMetadata()) && (op1.getMetadata().is(SimulationOuterClass.CreateSimulationMetadata.class))) {
            SimulationOuterClass.CreateSimulationMetadata metadata = op1.getMetadata().unpack(SimulationOuterClass.CreateSimulationMetadata.class);
            logger.info("(2): Received percentage of processing through metadata: '{}%'", metadata.getProgressPercent());
        }

        // 3b. Re-create simulation (to test progress-percent increase)
        op1 = createSimulationForScenario(scenarioName, simulationId, sim);
        logger.info("(3) Result of simulation creation -- operation-nmae: '{}', is-done: '{}'",
                    op1.getName(), op1.getDone());
        if ((op1.hasMetadata()) && (op1.getMetadata().is(SimulationOuterClass.CreateSimulationMetadata.class))) {
            SimulationOuterClass.CreateSimulationMetadata metadata = op1.getMetadata().unpack(SimulationOuterClass.CreateSimulationMetadata.class);
            logger.info("(3): Received percentage of processing through metadata: '{}%'", metadata.getProgressPercent());
        }

        // Get Simulation
        SimulationOuterClass.Simulation gsim  = getSimulation(simulationName);
        logger.info("Received simulation due to 'getSimulation' with name: '{}'", gsim.getName());

        // Create anaysis
        String analysisName = "test-analysis";
        /* TODO: Interval and resolution parameters shall be built through DateTime objects */
        /* Use time interval determined for simulation */
        //com.google.protobuf.Timestamp istt = com.google.protobuf.Timestamp.newBuilder().setSeconds(System.currentTimeMillis()/1000).setNanos(0).build();
        //com.google.protobuf.Timestamp iett = com.google.protobuf.Timestamp.newBuilder().setSeconds(istt.getSeconds() + 20).setNanos(0).build();
        com.google.protobuf.Timestamp istt = com.google.protobuf.Timestamp.newBuilder().setSeconds(now.plusSeconds(5).getEpochSecond()).setNanos(nanos).build();
        com.google.protobuf.Timestamp iett = com.google.protobuf.Timestamp.newBuilder().setSeconds(now.plusSeconds(25).getEpochSecond()).setNanos(nanos).build();
        com.google.type.Interval anInterval = com.google.type.Interval.newBuilder().setStartTime(istt).setEndTime(iett).build();
        com.google.protobuf.Duration anResolution = com.google.protobuf.Duration.newBuilder().setSeconds(1).setNanos(0).build();
        SimulationOuterClass.Analysis anInstance = constructAnalysis(scenarioName, analysisName, anInterval, anResolution);

        String analysisId = analysisName + ":" + System.currentTimeMillis();
        SimulationOuterClass.Analysis analysis = createAnalysis(simulationName, analysisId, anInstance);
        if (analysis == null) {
            logger.warn("Cannot create an Analysis successfully with name: '{}' for simulation: '{}' of scenario: '{}'",
                        analysisName, simulationName, scenarioName);
        }
        else {
            List<SimulationOuterClass.AnalysisSegment> analysisList = analysis.getSegmentsList();
            int anSegmentCount = (analysisList != null) ? analysisList.size() : 0;
            logger.info("Successfully created Analysis with name: '{}', analysis-segment count: '{}'", analysisName, anSegmentCount);
            detailsOfAnalysis(analysis);
        }

        
        long diff = anInterval.getEndTime().getSeconds() - anInterval.getStartTime().getSeconds();
        logger.info("Diff: '{}'", diff);

        // Get Analysis
        SimulationOuterClass.Analysis ganalysis = getAnalysis(analysisName, simulationName);
        if (ganalysis == null) {
            logger.warn("Cannot get an Analysis successfully with name: '{}' for simulation: '{}'",
                        analysisName, simulationName);
        }
        else {
            logger.info("Successfully get Analysis with name: '{}'", ganalysis.getName());
        }

        logger.info("=== Simulation Workflow Complete ===");
    }

    /**
     * Main Menu
     */
    public static void main(String[] args) throws Exception {
        String host = "localhost";
        int port = 50051;
        String inProcessName = null;
        String target = null; // e.g., "localhost:50051"

        // Keep the original argument parsing
        for (int i = 0; i < args.length; i++) {
            if ("--inprocess".equals(args[i]) && i + 1 < args.length) {
                inProcessName = args[i + 1];
                i++;
            } else if ("--target".equals(args[i]) && i + 1 < args.length) {
                target = args[i + 1];
                i++;
            } else if (i == 0 && !args[i].startsWith("--")) {
                // If the first arg contains a colon, treat it as full target
                if (args[i].contains(":")) {
                    target = args[i];
                } else {
                    host = args[i];
                }
            } else if (i == 1 && !args[i].startsWith("--")) {
                port = Integer.parseInt(args[i]);
            }
        }

        SimulationClient client;
        if (inProcessName != null) {
            client = SimulationClient.forInProcess(inProcessName);
        } else if (target != null) {
            ManagedChannel ch = Grpc.newChannelBuilder(target, InsecureChannelCredentials.create()).build();
            client = new SimulationClient(ch);
        } else {
            client = new SimulationClient(host, port);
        }

        java.util.Scanner scanner = new java.util.Scanner(System.in);
        try {
            boolean running = true;
            while (running) {
                System.out.println("\n=== Simulation Demo Menu ===");
                System.out.println("1) Run full simulation workflow");
                System.out.println("2) Create scenario");
                System.out.println("3) Get scenario");
                System.out.println("4) Create simulation for a scenario");
                System.out.println("5) Get simulation");
                System.out.println("6) Create analysis for a simulation");
                System.out.println("7) Get analysis");
                System.out.println("0) Exit");
                System.out.print("Enter your choice: ");

                String choice = scanner.nextLine().trim();

                try {
                    switch (choice) {
                        case "1":
                            // Full workflow
                            client.runSimulationWorkflow();
                            break;

                        case "2": {
                            // Create scenario
                            System.out.print("Scenario ID (leave empty for auto): ");
                            String scenarioId = scanner.nextLine().trim();
                            if (scenarioId.isEmpty()) {
                                scenarioId = "scenario-" + System.currentTimeMillis();
                            }

                            System.out.print("Scenario name (e.g. test-scenario): ");
                            String scenarioName = scanner.nextLine().trim();
                            if (scenarioName.isEmpty()) {
                                scenarioName = "test-scenario";
                            }

                            System.out.print("Scenario description: ");
                            String desc = scanner.nextLine().trim();
                            if (desc.isEmpty()) {
                                desc = "Demo scenario";
                            }

                            int rc = client.createScenario(scenarioId, scenarioName, desc);
                            System.out.println("createScenario returned: " + rc);
                            break;
                        }

                        case "3": {
                            // Get scenario
                            System.out.print("Scenario name (without prefix, e.g. test-scenario): ");
                            String gScName = scanner.nextLine().trim();
                            if (gScName.isEmpty()) {
                                gScName = "test-scenario";
                            }
                            SimulationOuterClass.Scenario sc = client.getScenario(gScName);
                            System.out.println("GetScenario -> name: " + sc.getName() +
                                               ", description: " + sc.getDescription());
                            break;
                        }

                        case "4": {
                            // Create simulation for a scenario
                            System.out.print("Scenario name (without prefix, e.g. test-scenario): ");
                            String scnName = scanner.nextLine().trim();
                            if (scnName.isEmpty()) {
                                scnName = "test-scenario";
                            }

                            System.out.print("Simulation name (e.g. test-simulation): ");
                            String simName = scanner.nextLine().trim();
                            if (simName.isEmpty()) {
                                simName = "test-simulation";
                            }

                            System.out.print("Simulation ID (leave empty for auto): ");
                            String simId = scanner.nextLine().trim();
                            if (simId.isEmpty()) {
                                simId = simName + ":" + System.currentTimeMillis();
                            }

                            System.out.print("Start offset in seconds (default 5): ");
                            String offStartStr = scanner.nextLine().trim();
                            long offStart = offStartStr.isEmpty() ? 5L : Long.parseLong(offStartStr);

                            System.out.print("Duration in seconds (default 20): ");
                            String durationStr = scanner.nextLine().trim();
                            long duration = durationStr.isEmpty() ? 20L : Long.parseLong(durationStr);

                            Instant now = Instant.now();
                            long startSec = now.plusSeconds(offStart).getEpochSecond();
                            long endSec = now.plusSeconds(offStart + duration).getEpochSecond();
                            int nanos = now.getNano();

                            SimulationOuterClass.Simulation sim =
                                client.createSimulation(simName, startSec, nanos, endSec, nanos);
                            com.google.longrunning.Operation op =
                                client.createSimulationForScenario(scnName, simId, sim);

                            System.out.println("CreateSimulation -> operation name: " + op.getName() +
                                               ", done: " + op.getDone());
                            break;
                        }

                        case "5": {
                            // Get simulation
                            System.out.print("Simulation name (without prefix, e.g. test-simulation): ");
                            String gSimName = scanner.nextLine().trim();
                            if (gSimName.isEmpty()) {
                                gSimName = "test-simulation";
                            }
                            SimulationOuterClass.Simulation gsim = client.getSimulation(gSimName);
                            System.out.println("GetSimulation -> name: " + gsim.getName() +
                                               ", scenario: " + gsim.getScenario() +
                                               ", state: " + gsim.getState());
                            break;
                        }

                        case "6": {
                            // Create analysis for a simulation
                            System.out.print("Scenario name (without prefix, e.g. test-scenario): ");
                            String aScName = scanner.nextLine().trim();
                            if (aScName.isEmpty()) {
                                aScName = "test-scenario";
                            }

                            System.out.print("Parent simulation name (without prefix, e.g. test-simulation): ");
                            String parentSim = scanner.nextLine().trim();
                            if (parentSim.isEmpty()) {
                                parentSim = "test-simulation";
                            }

                            System.out.print("Analysis name (e.g. test-analysis): ");
                            String anName = scanner.nextLine().trim();
                            if (anName.isEmpty()) {
                                anName = "test-analysis";
                            }

                            System.out.print("Start offset in seconds (default 5): ");
                            String aOffStartStr = scanner.nextLine().trim();
                            long aOffStart = aOffStartStr.isEmpty() ? 5L : Long.parseLong(aOffStartStr);

                            System.out.print("Duration in seconds (default 20): ");
                            String aDurationStr = scanner.nextLine().trim();
                            long aDuration = aDurationStr.isEmpty() ? 20L : Long.parseLong(aDurationStr);

                            System.out.print("Resolution in seconds (default 1): ");
                            String resStr = scanner.nextLine().trim();
                            long resSec = resStr.isEmpty() ? 1L : Long.parseLong(resStr);

                            Instant nowA = Instant.now();
                            com.google.protobuf.Timestamp st =
                                com.google.protobuf.Timestamp.newBuilder()
                                    .setSeconds(nowA.plusSeconds(aOffStart).getEpochSecond())
                                    .setNanos(nowA.getNano())
                                    .build();
                            com.google.protobuf.Timestamp et =
                                com.google.protobuf.Timestamp.newBuilder()
                                    .setSeconds(nowA.plusSeconds(aOffStart + aDuration).getEpochSecond())
                                    .setNanos(nowA.getNano())
                                    .build();

                            com.google.type.Interval interval =
                                com.google.type.Interval.newBuilder()
                                    .setStartTime(st)
                                    .setEndTime(et)
                                    .build();

                            com.google.protobuf.Duration resolution =
                                com.google.protobuf.Duration.newBuilder()
                                    .setSeconds(resSec)
                                    .setNanos(0)
                                    .build();

                            SimulationOuterClass.Analysis an =
                                client.constructAnalysis(aScName, anName, interval, resolution);
                            String anId = anName + ":" + System.currentTimeMillis();

                            SimulationOuterClass.Analysis createdAn =
                                client.createAnalysis(parentSim, anId, an);
                            if (createdAn == null) {
                                System.out.println("Analysis could not be created.");
                            } else {
                                System.out.println("Analysis created: " + createdAn.getName());
                                client.detailsOfAnalysis(createdAn);
                            }
                            break;
                        }

                        case "7": {
                            // Get analysis
                            System.out.print("Analysis name (without prefix, e.g. test-analysis): ");
                            String gaName = scanner.nextLine().trim();
                            if (gaName.isEmpty()) {
                                gaName = "test-analysis";
                            }

                            System.out.print("Parent simulation name (without prefix, e.g. test-simulation): ");
                            String gParentSim = scanner.nextLine().trim();
                            if (gParentSim.isEmpty()) {
                                gParentSim = "test-simulation";
                            }

                            SimulationOuterClass.Analysis gan = client.getAnalysis(gaName, gParentSim);
                            if (gan == null) {
                                System.out.println("Analysis not found.");
                            } else {
                                System.out.println("GetAnalysis -> name: " + gan.getName());
                                client.detailsOfAnalysis(gan);
                            }
                            break;
                        }

                        case "0":
                            running = false;
                            break;

                        default:
                            System.out.println("Invalid choice.");
                    }
                } catch (Exception ex) {
                    System.err.println("Error during operation: " + ex.getMessage());
                    ex.printStackTrace();
                }
            }
        } finally {
            try {
                client.shutdown();
            } finally {
                scanner.close();
            }
        }
    }
   
    /**
     * Main method to run the client
     */
    /*
    public static void main(String[] args) throws Exception {
        String host = "localhost";
        int port = 50051;
        String inProcessName = null;
        String target = null; // e.g., "localhost:50051"

        for (int i = 0; i < args.length; i++) {
            if ("--inprocess".equals(args[i]) && i + 1 < args.length) {
                inProcessName = args[i + 1];
                i++;
            } 
            else if ("--target".equals(args[i]) && i + 1 < args.length) {
                target = args[i + 1];
                i++;
            } 
            else if (i == 0 && !args[i].startsWith("--")) {
                // If the first arg contains a colon, treat it as full target
                if (args[i].contains(":")) {
                    target = args[i];
                } else {
                    host = args[i];
                }
            } 
            else if (i == 1 && !args[i].startsWith("--")) {
                port = Integer.parseInt(args[i]);
            }
        }

        SimulationClient client;
        if (inProcessName != null) {
            client = SimulationClient.forInProcess(inProcessName);
        } 
        else if (target != null) {
            ManagedChannel ch = Grpc.newChannelBuilder(target, InsecureChannelCredentials.create()).build();
            client = new SimulationClient(ch);
        } 
        else {
            client = new SimulationClient(host, port);
        }

        try {
            // Run the complete workflow
            client.runSimulationWorkflow();
        } 
        finally {
            client.shutdown();
        }
    }
    */
}