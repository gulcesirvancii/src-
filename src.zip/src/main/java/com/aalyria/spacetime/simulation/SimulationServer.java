package com.aalyria.spacetime.simulation;

import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateScenarioRequest;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateSimulationMetadata;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateSimulationRequest;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteScenarioRequest;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.DeleteSimulationRequest;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetScenarioRequest;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetSimulationRequest;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosRequest;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosResponse;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsRequest;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsResponse;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation.State;
import com.aalyria.spacetime.simulation.v1alpha.SimulationServiceGrpc;
import com.google.longrunning.Operation;
import com.google.protobuf.Any;
import com.google.protobuf.Empty;
import com.google.protobuf.Timestamp;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.Status;
import io.grpc.inprocess.InProcessServerBuilder;
import io.grpc.stub.StreamObserver;
import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SimulationServer {
    private static final Logger logger = LoggerFactory.getLogger(SimulationServer.class);

    private Server server;
    private final int port;

    public SimulationServer(int port) {
        this.port = port;
    }

    public void start() throws IOException {
        server =
                ServerBuilder.forPort(port)
                        .addService(new SimulationServiceImpl())
                        .build()
                        .start();

        logger.info("Simulation server started, listening on port {}", port);
        Runtime.getRuntime()
                .addShutdownHook(
                        new Thread(
                                () -> {
                                    logger.info("Shutting down gRPC server...");
                                    try {
                                        SimulationServer.this.stop();
                                    } catch (InterruptedException e) {
                                        logger.error("Error shutting down server", e);
                                        Thread.currentThread().interrupt();
                                    }
                                }));
    }

    public void startInProcess(String inProcessName) throws IOException {
        server =
                InProcessServerBuilder.forName(inProcessName)
                        .directExecutor()
                        .addService(new SimulationServiceImpl())
                        .build()
                        .start();

        logger.info("Simulation in-process server started with name '{}'", inProcessName);
        Runtime.getRuntime()
                .addShutdownHook(
                        new Thread(
                                () -> {
                                    logger.info("Shutting down in-process gRPC server...");
                                    try {
                                        SimulationServer.this.stop();
                                    } catch (InterruptedException e) {
                                        logger.error("Error shutting down in-process server", e);
                                        Thread.currentThread().interrupt();
                                    }
                                }));
    }

    public void stop() throws InterruptedException {
        if (server != null) {
            server.shutdown().awaitTermination(30, TimeUnit.SECONDS);
        }
    }

    public void blockUntilShutdown() throws InterruptedException {
        if (server != null) {
            server.awaitTermination();
        }
    }

    static class SimulationServiceImpl extends SimulationServiceGrpc.SimulationServiceImplBase {
        private static final Logger serviceLogger =
                LoggerFactory.getLogger(SimulationServiceImpl.class);

        private final Map<String, Scenario> scenarios = new ConcurrentHashMap<>();
        private final Map<String, Simulation> simulations = new ConcurrentHashMap<>();

        @Override
        public void listScenarios(
                ListScenariosRequest request,
                StreamObserver<ListScenariosResponse> responseObserver) {
            Collection<Scenario> values = new ArrayList<>(scenarios.values());
            ListScenariosResponse response =
                    ListScenariosResponse.newBuilder()
                            .addAllScenarios(values)
                            .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
        }

        @Override
        public void getScenario(
                GetScenarioRequest request, StreamObserver<Scenario> responseObserver) {
            Scenario scenario = scenarios.get(request.getName());
            if (scenario == null) {
                responseObserver.onError(
                        Status.NOT_FOUND
                                .withDescription("Scenario not found: " + request.getName())
                                .asRuntimeException());
                return;
            }
            responseObserver.onNext(scenario);
            responseObserver.onCompleted();
        }

        @Override
        public void createScenario(
                CreateScenarioRequest request, StreamObserver<Scenario> responseObserver) {
            if (request.getScenarioId().isBlank()) {
                responseObserver.onError(
                        Status.INVALID_ARGUMENT
                                .withDescription("scenario_id must be provided")
                                .asRuntimeException());
                return;
            }

            Scenario.Builder builder = request.getScenario().toBuilder();
            if (builder.getName().isBlank()) {
                builder.setName("scenarios/" + request.getScenarioId());
            }

            Scenario scenario = builder.build();

            if (scenarios.putIfAbsent(scenario.getName(), scenario) != null) {
                responseObserver.onError(
                        Status.ALREADY_EXISTS
                                .withDescription("Scenario already exists: " + scenario.getName())
                                .asRuntimeException());
                return;
            }

            serviceLogger.info("Scenario created: {}", scenario.getName());
            responseObserver.onNext(scenario);
            responseObserver.onCompleted();
        }

        @Override
        public void deleteScenario(
                DeleteScenarioRequest request, StreamObserver<Empty> responseObserver) {
            Scenario removed = scenarios.remove(request.getName());
            if (removed == null) {
                responseObserver.onError(
                        Status.NOT_FOUND
                                .withDescription("Scenario not found: " + request.getName())
                                .asRuntimeException());
                return;
            }

            simulations.values().removeIf(sim -> sim.getScenario().equals(request.getName()));

            responseObserver.onNext(Empty.getDefaultInstance());
            responseObserver.onCompleted();
        }

        @Override
        public void listSimulations(
                ListSimulationsRequest request,
                StreamObserver<ListSimulationsResponse> responseObserver) {
            Collection<Simulation> values = new ArrayList<>(simulations.values());
            ListSimulationsResponse response =
                    ListSimulationsResponse.newBuilder()
                            .addAllSimulations(values)
                            .build();
            responseObserver.onNext(response);
            responseObserver.onCompleted();
        }

        @Override
        public void getSimulation(
                GetSimulationRequest request, StreamObserver<Simulation> responseObserver) {
            Simulation simulation = simulations.get(request.getName());
            if (simulation == null) {
                responseObserver.onError(
                        Status.NOT_FOUND
                                .withDescription("Simulation not found: " + request.getName())
                                .asRuntimeException());
                return;
            }
            responseObserver.onNext(simulation);
            responseObserver.onCompleted();
        }

        @Override
        public void createSimulation(
                CreateSimulationRequest request, StreamObserver<Operation> responseObserver) {
            if (request.getSimulationId().isBlank()) {
                responseObserver.onError(
                        Status.INVALID_ARGUMENT
                                .withDescription("simulation_id must be provided")
                                .asRuntimeException());
                return;
            }

            Simulation.Builder builder = request.getSimulation().toBuilder();
            if (builder.getScenario().isBlank()) {
                responseObserver.onError(
                        Status.INVALID_ARGUMENT
                                .withDescription("simulation.scenario must be provided")
                                .asRuntimeException());
                return;
            }

            Scenario scenario = scenarios.get(builder.getScenario());
            if (scenario == null) {
                responseObserver.onError(
                        Status.NOT_FOUND
                                .withDescription("Scenario not found: " + builder.getScenario())
                                .asRuntimeException());
                return;
            }

            if (builder.getName().isBlank()) {
                builder.setName("simulations/" + request.getSimulationId());
            }

            Instant now = Instant.now();
            Timestamp createTime =
                    Timestamp.newBuilder()
                            .setSeconds(now.getEpochSecond())
                            .setNanos(now.getNano())
                            .build();

            builder.setCreateTime(createTime);
            builder.setState(State.SUCCEEDED);

            Simulation simulation = builder.build();
            simulations.put(simulation.getName(), simulation);

            CreateSimulationMetadata metadata =
                    CreateSimulationMetadata.newBuilder()
                            .setProgressPercent(100.0)
                            .build();

            Operation operation =
                    Operation.newBuilder()
                            .setName("operations/createSimulation/" + request.getSimulationId())
                            .setDone(true)
                            .setMetadata(Any.pack(metadata))
                            .setResponse(Any.pack(simulation))
                            .build();

            serviceLogger.info(
                    "Simulation created: {} for scenario {}", simulation.getName(), simulation.getScenario());

            responseObserver.onNext(operation);
            responseObserver.onCompleted();
        }

        @Override
        public void deleteSimulation(
                DeleteSimulationRequest request, StreamObserver<Empty> responseObserver) {
            Simulation removed = simulations.remove(request.getName());
            if (removed == null) {
                responseObserver.onError(
                        Status.NOT_FOUND
                                .withDescription("Simulation not found: " + request.getName())
                                .asRuntimeException());
                return;
            }

            responseObserver.onNext(Empty.getDefaultInstance());
            responseObserver.onCompleted();
        }
    }

    public static void main(String[] args) throws IOException, InterruptedException {
        int port = 50051;
        String inProcessName = null;

        for (int i = 0; i < args.length; i++) {
            if ("--inprocess".equals(args[i]) && i + 1 < args.length) {
                inProcessName = args[i + 1];
                i++;
            } else if (!args[i].startsWith("--")) {
                port = Integer.parseInt(args[i]);
            }
        }

        SimulationServer server = new SimulationServer(port);
        if (inProcessName != null) {
            server.startInProcess(inProcessName);
        } else {
            server.start();
        }
        server.blockUntilShutdown();
    }
}

