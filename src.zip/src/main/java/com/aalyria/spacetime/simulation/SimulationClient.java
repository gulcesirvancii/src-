package com.aalyria.spacetime.simulation;

import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateScenarioRequest;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.CreateSimulationRequest;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetScenarioRequest;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.GetSimulationRequest;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosRequest;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListScenariosResponse;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsRequest;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.ListSimulationsResponse;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Scenario;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation.State;
import com.aalyria.spacetime.simulation.v1alpha.SimulationServiceGrpc;
import com.google.longrunning.Operation;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Timestamp;
import com.google.type.Interval;
import io.grpc.Grpc;
import io.grpc.InsecureChannelCredentials;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import io.grpc.inprocess.InProcessChannelBuilder;
import java.time.Duration;
import java.time.Instant;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SimulationClient {
    private static final Logger logger = LoggerFactory.getLogger(SimulationClient.class);

    private final ManagedChannel channel;
    private final SimulationServiceGrpc.SimulationServiceBlockingStub blockingStub;

    public SimulationClient(String host, int port) {
        this(
                ManagedChannelBuilder.forAddress(host, port)
                        .usePlaintext()
                        .build());
    }

    public static SimulationClient forInProcess(String inProcessName) {
        ManagedChannel channel =
                InProcessChannelBuilder.forName(inProcessName)
                        .directExecutor()
                        .build();
        return new SimulationClient(channel);
    }

    SimulationClient(ManagedChannel channel) {
        this.channel = channel;
        this.blockingStub = SimulationServiceGrpc.newBlockingStub(channel);
    }

    public void shutdown() throws InterruptedException {
        channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
    }

    public void runInteractiveMenu() {
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;
        while (!exit) {
            printMenu();
            String choice = scanner.nextLine().trim();
            try {
                switch (choice) {
                    case "1" -> listScenarios();
                    case "2" -> createScenario(scanner);
                    case "3" -> getScenario(scanner);
                    case "4" -> createSimulation(scanner);
                    case "5" -> listSimulations();
                    case "6" -> getSimulation(scanner);
                    case "7" -> {
                        exit = true;
                        System.out.println("Exiting...");
                    }
                    default -> System.out.println("Invalid choice. Please try again.");
                }
            } catch (StatusRuntimeException | InvalidProtocolBufferException e) {
                logger.error("An error occurred during the RPC call", e);
            }
        }
    }

    private void printMenu() {
        System.out.println();
        System.out.println("=== Simulation Client Menu ===");
        System.out.println("1) List scenarios");
        System.out.println("2) Create scenario");
        System.out.println("3) Get scenario details");
        System.out.println("4) Create simulation");
        System.out.println("5) List simulations");
        System.out.println("6) Get simulation details");
        System.out.println("7) Exit");
        System.out.print("Select option: ");
    }

    private void listScenarios() {
        logger.info("Listing scenarios");
        ListScenariosResponse response =
                blockingStub.listScenarios(ListScenariosRequest.getDefaultInstance());
        if (response.getScenariosCount() == 0) {
            System.out.println("No scenarios found.");
            return;
        }
        response.getScenariosList()
                .forEach(
                        scenario ->
                                System.out.printf(
                                        "- %s (%s)%n", scenario.getName(), scenario.getDescription()));
    }

    private void createScenario(Scanner scanner) {
        String scenarioId = prompt(scanner, "Scenario ID");
        String description = prompt(scanner, "Description (optional)");

        Scenario.Builder scenarioBuilder =
                Scenario.newBuilder()
                        .setName(toScenarioName(scenarioId));
        if (!description.isBlank()) {
            scenarioBuilder.setDescription(description);
        }

        Scenario scenario =
                blockingStub.createScenario(
                        CreateScenarioRequest.newBuilder()
                                .setScenarioId(scenarioId)
                                .setScenario(scenarioBuilder.build())
                                .build());

        System.out.printf("Scenario created: %s%n", scenario.getName());
    }

    private void getScenario(Scanner scanner) {
        String scenarioId = prompt(scanner, "Scenario ID");
        Scenario scenario =
                blockingStub.getScenario(
                        GetScenarioRequest.newBuilder()
                                .setName(toScenarioName(scenarioId))
                                .build());

        System.out.printf(
                "Scenario: %s%nDescription: %s%n",
                scenario.getName(),
                scenario.getDescription());
    }

    private void createSimulation(Scanner scanner) throws InvalidProtocolBufferException {
        String simulationId = prompt(scanner, "Simulation ID");
        String scenarioId = prompt(scanner, "Scenario ID to use");
        long durationMinutes = Long.parseLong(prompt(scanner, "Duration (minutes)"));

        Interval interval = buildInterval(Duration.ofMinutes(durationMinutes));
        Simulation simulation =
                Simulation.newBuilder()
                        .setName(toSimulationName(simulationId))
                        .setScenario(toScenarioName(scenarioId))
                        .setInterval(interval)
                        .setState(State.RUNNING)
                        .build();

        Operation operation =
                blockingStub.createSimulation(
                        CreateSimulationRequest.newBuilder()
                                .setSimulationId(simulationId)
                                .setSimulation(simulation)
                                .build());

        System.out.printf("Operation: %s (done=%s)%n", operation.getName(), operation.getDone());

        if (operation.getDone() && operation.hasResponse()) {
            Simulation created =
                    operation.getResponse().unpack(Simulation.class);
            printSimulation(created);
        }
    }

    private void listSimulations() {
        logger.info("Listing simulations");
        ListSimulationsResponse response =
                blockingStub.listSimulations(ListSimulationsRequest.getDefaultInstance());
        if (response.getSimulationsCount() == 0) {
            System.out.println("No simulations found.");
            return;
        }
        response.getSimulationsList().forEach(this::printSimulation);
    }

    private void getSimulation(Scanner scanner) {
        String simulationId = prompt(scanner, "Simulation ID");
        Simulation simulation =
                blockingStub.getSimulation(
                        GetSimulationRequest.newBuilder()
                                .setName(toSimulationName(simulationId))
                                .build());
        printSimulation(simulation);
    }

    private void printSimulation(Simulation simulation) {
        System.out.printf(
                "Simulation: %s%n  Scenario: %s%n  State: %s%n",
                simulation.getName(),
                simulation.getScenario(),
                simulation.getState());
        if (simulation.hasInterval()) {
            Timestamp start = simulation.getInterval().getStartTime();
            Timestamp end = simulation.getInterval().getEndTime();
            System.out.printf(
                    "  Start: %s%n  End: %s%n",
                    formatTimestamp(start),
                    formatTimestamp(end));
        }
    }

    private Interval buildInterval(Duration duration) {
        Instant now = Instant.now();
        Instant end = now.plus(duration);

        Timestamp startTs =
                Timestamp.newBuilder()
                        .setSeconds(now.getEpochSecond())
                        .setNanos(now.getNano())
                        .build();
        Timestamp endTs =
                Timestamp.newBuilder()
                        .setSeconds(end.getEpochSecond())
                        .setNanos(end.getNano())
                        .build();

        return Interval.newBuilder()
                .setStartTime(startTs)
                .setEndTime(endTs)
                .build();
    }

    private String prompt(Scanner scanner, String label) {
        System.out.print(label + ": ");
        return scanner.nextLine().trim();
    }

    private String toScenarioName(String scenarioId) {
        return scenarioId.startsWith("scenarios/") ? scenarioId : "scenarios/" + scenarioId;
    }

    private String toSimulationName(String simulationId) {
        return simulationId.startsWith("simulations/") ? simulationId : "simulations/" + simulationId;
    }

    private String formatTimestamp(Timestamp timestamp) {
        Instant instant =
                Instant.ofEpochSecond(timestamp.getSeconds(), timestamp.getNanos());
        return instant.toString();
    }

    public static void main(String[] args) throws Exception {
        String host = "localhost";
        int port = 50051;
        String inProcessName = null;
        String target = null;

        for (int i = 0; i < args.length; i++) {
            if ("--inprocess".equals(args[i]) && i + 1 < args.length) {
                inProcessName = args[i + 1];
                i++;
            } else if ("--target".equals(args[i]) && i + 1 < args.length) {
                target = args[i + 1];
                i++;
            } else if (i == 0 && !args[i].startsWith("--")) {
                if (args[i].contains(":")) {
                    target = args[i];
                } else {
                    host = args[i];
                }
            } else if (i == 1 && !args[i].startsWith("--")) {
                port = Integer.parseInt(args[i]);
            }
        }

        SimulationClient client;
        if (inProcessName != null) {
            client = SimulationClient.forInProcess(inProcessName);
        } else if (target != null) {
            ManagedChannel channel =
                    Grpc.newChannelBuilder(target, InsecureChannelCredentials.create())
                            .build();
            client = new SimulationClient(channel);
        } else {
            client = new SimulationClient(host, port);
        }

        try {
            client.runInteractiveMenu();
        } finally {
            client.shutdown();
        }
    }
}

