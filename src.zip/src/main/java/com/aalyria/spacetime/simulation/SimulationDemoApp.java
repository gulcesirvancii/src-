package com.aalyria.spacetime.simulation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Simple demo runner that starts the SimulationServer in-process and drives the SimulationClient
 * against it without opening any network sockets or requiring additional SDKs/frameworks.
 */
public final class SimulationDemoApp {
    private static final Logger logger = LoggerFactory.getLogger(SimulationDemoApp.class);
    private static final String IN_PROCESS_NAME = "simulation-demo";

    private SimulationDemoApp() {
    }

    public static void main(String[] args) throws Exception {
        SimulationServer server = new SimulationServer(0);
        server.startInProcess(IN_PROCESS_NAME);

        // Run the client workflow against the in-process server.
        SimulationClient client = SimulationClient.forInProcess(IN_PROCESS_NAME);

        try {
            logger.info("Starting interactive simulation menu on in-process server '{}'.", IN_PROCESS_NAME);
            client.runInteractiveMenu();
        } finally {
            client.shutdown();
            server.stop();
        }

        logger.info("Simulation demo completed successfully.");
    }
}



