package com.telesat.simulation;

import java.util.SplittableRandom;
import java.util.stream.DoubleStream;

public class DataGenerator
{
    SplittableRandom random = new SplittableRandom();

    double minLimit;
    double maxLimit;
    int count;
    /* TODO: distribution function may be provided */

    /* for output */
    double[] values;
    double minValue;
    double maxValue;
    double average;
    double stddev;

    public DataGenerator(double min, double max, int count) {
        this.minLimit = min;
        this.maxLimit = max;
        this.count = count;

        calculateStatsForAPeriod();
    }

    public void calculateStats() {
        // get the sum of array
        double sum = 0.0;
        double max = 0.0;
        double min = Double.MAX_VALUE;
        for (double i : this.values) {
            sum += i;
            if (max < i) {
                max = i;
            }
            if (min > i) {
                min = i;
            }
        }
        this.maxValue = max;
        this.minValue = min;

        // get the mean of array
        int length = this.values.length;
        this.average = sum / length;

        // calculate the standard deviation
        double standardDeviation = 0.0;
        for (double num : this.values) {
            standardDeviation += Math.pow(num - this.average, 2);
        }

        this.stddev = Math.sqrt(standardDeviation / length);
    }

    public void calculateStatsForAPeriod() {
        SplittableRandom splittableRandom = new SplittableRandom();
        DoubleStream valueStream = splittableRandom.doubles(this.count, this.minLimit, this.maxLimit);
        this.values = valueStream.toArray();
        calculateStats();
    }

    // Getters
    public double getMinValue() {
        return this.minValue;
    }

    public double getMaxValue() {
        return this.maxValue;
    }

    public double getAverage() {
        return this.average;
    }

    public double getStdDev() {
        return this.stddev;
    }

    public double[] getValues() {
        return this.values;
    }

    public static void main(String[] args) {

        DataGenerator dg = new DataGenerator(1234, 9876, 100);
        System.out.format("Min: %.3f, Max: %.3f, average: %.3f, stddev: %.3f%n", dg.getMinValue(), dg.getMaxValue(), dg.getAverage(), dg.getStdDev());
        double[] vals = dg.getValues();
        for (double val : vals) {
            System.out.format("%.3f, ", val);
        }
        System.out.println("\n");
    }
}
