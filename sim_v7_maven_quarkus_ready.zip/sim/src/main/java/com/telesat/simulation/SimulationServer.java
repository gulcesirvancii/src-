package com.telesat.simulation;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.enterprise.context.ApplicationScoped;

import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass;

/**
 * Quarkus-managed core state and helper methods.
 *
 * IMPORTANT: Quarkus starts the gRPC server. This class must NOT create or
 * start a {@code io.grpc.Server} instance.
 */
@ApplicationScoped
public class SimulationServer {

    private static final Logger logger = LoggerFactory.getLogger(SimulationServer.class);

    @ConfigProperty(name = "sim.config.file", defaultValue = "config/sim_server_config.json")
    String configFile;

    SimulationServerConfiguration config;

    // Package-private on purpose: used by SimulationGrpcService in the same package.
    final Map<String, ScenarioDelegation> scenariosForId = new ConcurrentHashMap<>();
    final Map<String, ScenarioDelegation> scenariosForName = new ConcurrentHashMap<>();

    final Map<String, SimulationDelegation> simulationsForId = new ConcurrentHashMap<>();
    final Map<String, SimulationDelegation> simulationsForName = new ConcurrentHashMap<>();

    final Map<String, AnalysisDelegation> analysesForId = new ConcurrentHashMap<>();
    final Map<String, AnalysisDelegation> analysesForName = new ConcurrentHashMap<>();

    ExecutorService executor;

    @PostConstruct
    void init() {
        // Keep the thread pool small; Quarkus will manage the server threads.
        executor = Executors.newFixedThreadPool(2);
        readConfiguration(configFile);
        logger.info("SimulationServer initialized. configFile={}", configFile);
    }

    @PreDestroy
    void shutdown() {
        if (executor != null) {
            executor.shutdownNow();
        }
        logger.info("SimulationServer shutdown.");
    }

    public SimulationOuterClass.Scenario getScenarioForId(String scenarioId) {
        ScenarioDelegation sc = scenariosForId.get(scenarioId);
        return (sc == null) ? null : sc.getScenario();
    }

    public SimulationOuterClass.Scenario getScenarioForName(String scenarioName) {
        ScenarioDelegation sc = scenariosForName.get(scenarioName);
        return (sc == null) ? null : sc.getScenario();
    }

    public void setScenario(String scenarioId, SimulationOuterClass.Scenario scenario) {
        ScenarioDelegation sc = new ScenarioDelegation(scenarioId, scenario);
        scenariosForId.put(scenarioId, sc);
        scenariosForName.put(scenario.getName(), sc);
    }

    public SimulationOuterClass.Simulation getSimulationForId(String simulationId) {
        SimulationDelegation simd = simulationsForId.get(simulationId);
        return (simd == null) ? null : simd.getSimulation();
    }

    public SimulationOuterClass.Simulation getSimulationForName(String simulationName) {
        SimulationDelegation simd = simulationsForName.get(simulationName);
        return (simd == null) ? null : simd.getSimulation();
    }

    void setSimulation(String simulationId, SimulationOuterClass.Simulation simulation) {
        SimulationDelegation simd = simulationsForId.get(simulationId);
        if (simd == null) {
            simd = new SimulationDelegation(simulationId, simulation);
            simulationsForId.put(simulationId, simd);
        } else {
            simd.setSimulation(simulation);
        }

        String fsimname = simulation.getName();
        String[] parts = fsimname.split("/");
        String simname = parts[parts.length - 1];
        simulationsForName.put(simname, simd);
    }

    public SimulationOuterClass.Analysis getAnalysisForId(String analysisId) {
        AnalysisDelegation adel = analysesForId.get(analysisId);
        return (adel == null) ? null : adel.getAnalysis();
    }

    public SimulationOuterClass.Analysis getAnalysisForName(String name) {
        AnalysisDelegation adel = analysesForName.get(name);
        return (adel == null) ? null : adel.getAnalysis();
    }

    /**
     * Returns the Analysis instance possibly rebuilt from the provided input.
     */
    public SimulationOuterClass.Analysis setAnalysis(String parent, String analysisId, SimulationOuterClass.Analysis analysis) {

        String fsimname = parent;
        String[] parts = fsimname.split("/");
        if (parts.length > 2) {
            logger.info("setAnalysis: Name format of analysis parent is possibly unexpected: '{}'", fsimname);
        }
        String parentSimulation = parts[parts.length - 1];

        AnalysisDelegation del = new AnalysisDelegation(parentSimulation, analysisId, analysis, this.config, logger);
        analysesForId.put(analysisId, del);

        String faname = analysis.getName();
        parts = faname.split("/");
        if (parts.length > 4) {
            logger.info("setAnalysis: Name format of analysis is possibly unexpected: '{}'", faname);
        }
        String aname = parts[parts.length - 1];
        analysesForName.put(aname, del);

        return del.getAnalysis();
    }

    public void readConfiguration(String confFileName) {
        try {
            this.config = new SimulationServerConfiguration(confFileName);
            this.config.parseForJson();
        } catch (Exception e) {
            logger.warn("Failed to read configuration from '{}'. Continuing with defaults.", confFileName, e);
            this.config = new SimulationServerConfiguration(confFileName);
        }
    }
}
