package com.telesat.simulation;

import java.time.Instant;

import jakarta.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.quarkus.grpc.GrpcService;
import io.grpc.Status;
import io.grpc.stub.StreamObserver;

import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass;
import com.aalyria.spacetime.simulation.v1alpha.SimulationServiceGrpc;
import com.google.longrunning.Operation;
import com.google.protobuf.Any;
import com.google.protobuf.Timestamp;
import com.google.rpc.Code;

/**
 * Quarkus gRPC service implementation.
 *
 * Note: We only implement the subset of RPCs currently used by the client/demo.
 * All other RPCs remain UNIMPLEMENTED by default.
 */
@GrpcService
public class SimulationGrpcService extends SimulationServiceGrpc.SimulationServiceImplBase {

    private static final Logger logger = LoggerFactory.getLogger(SimulationGrpcService.class);

    @Inject
    SimulationServer server;

    @Override
    public void createScenario(SimulationOuterClass.CreateScenarioRequest request,
                               StreamObserver<SimulationOuterClass.Scenario> responseObserver) {

        String scenarioId = request.getScenarioId();
        logger.info("Received CreateScenarioRequest id='{}' name='{}'", scenarioId, request.getScenario().getName());

        SimulationOuterClass.Scenario existing = server.getScenarioForId(scenarioId);
        if (existing != null) {
            // No formal error model in the proto for this RPC in our stub server.
            responseObserver.onNext(SimulationOuterClass.Scenario.newBuilder().setName("").build());
            responseObserver.onCompleted();
            return;
        }

        SimulationOuterClass.Scenario created = SimulationOuterClass.Scenario.newBuilder(request.getScenario()).build();
        server.setScenario(scenarioId, created);

        responseObserver.onNext(created);
        responseObserver.onCompleted();
    }

    @Override
    public void getScenario(SimulationOuterClass.GetScenarioRequest request,
                            StreamObserver<SimulationOuterClass.Scenario> responseObserver) {

        String fscname = request.getName();
        String[] parts = fscname.split("/");
        String scname = parts[parts.length - 1];

        SimulationOuterClass.Scenario sc = server.getScenarioForName(scname);
        if (sc == null) {
            sc = server.getScenarioForId(scname);
        }
        if (sc == null) {
            responseObserver.onNext(SimulationOuterClass.Scenario.newBuilder().setName("").build());
            responseObserver.onCompleted();
            return;
        }

        responseObserver.onNext(SimulationOuterClass.Scenario.newBuilder(sc).build());
        responseObserver.onCompleted();
    }

    @Override
    public void createSimulation(SimulationOuterClass.CreateSimulationRequest request,
                                 StreamObserver<Operation> responseObserver) {

        String simId = request.getSimulationId();
        String operationName = "operations/" + simId;

        logger.info("CreateSimulation simId={}", simId);

        // Resolve scenario
        String fscname = request.getSimulation().getScenario();
        String[] parts = fscname.split("/");
        String scname = parts[parts.length - 1];

        SimulationOuterClass.Scenario sc = server.getScenarioForName(scname);
        if (sc == null) {
            sc = server.getScenarioForId(scname);
        }
        if (sc == null) {
            com.google.rpc.Status status = com.google.rpc.Status.newBuilder()
                    .setCode(Code.UNAVAILABLE_VALUE)
                    .setMessage("No scenario found with name/id: " + scname)
                    .build();

            Operation op = Operation.newBuilder()
                    .setName(operationName)
                    .setDone(true)
                    .setError(status)
                    .build();
            responseObserver.onNext(op);
            responseObserver.onCompleted();
            return;
        }

        // Create RUNNING simulation
        SimulationOuterClass.Simulation sim = request.getSimulation().toBuilder()
                .setState(SimulationOuterClass.Simulation.State.RUNNING)
                .setCreateTime(Timestamp.newBuilder().setSeconds(Instant.now().getEpochSecond()).build())
                .build();

        server.setSimulation(simId, sim);

        SimulationDelegation simd = server.simulationsForId.get(simId);
        if (simd == null) {
            com.google.rpc.Status status = com.google.rpc.Status.newBuilder()
                    .setCode(Code.INTERNAL_VALUE)
                    .setMessage("SimulationDelegation was not created for simId: " + simId)
                    .build();

            Operation op = Operation.newBuilder()
                    .setName(operationName)
                    .setDone(true)
                    .setError(status)
                    .build();
            responseObserver.onNext(op);
            responseObserver.onCompleted();
            return;
        }

        // Initial LRO operation
        SimulationOuterClass.CreateSimulationMetadata metadata =
                SimulationOuterClass.CreateSimulationMetadata.newBuilder()
                        .setProgressPercent(0.0)
                        .build();

        Operation op = Operation.newBuilder()
                .setName(operationName)
                .setDone(false)
                .setMetadata(Any.pack(metadata))
                .build();

        simd.putOperation(operationName, op);

        responseObserver.onNext(op);
        responseObserver.onCompleted();

        // Background completion
        server.executor.submit(() -> runSimulationAsync(simId));
    }

    private void runSimulationAsync(String simId) {
        String operationName = "operations/" + simId;

        SimulationDelegation simd = server.simulationsForId.get(simId);
        if (simd == null) {
            logger.error("runSimulationAsync: No delegation found for simId={}", simId);
            return;
        }

        try {
            for (int i = 1; i <= 10; i++) {
                Thread.sleep(200);
                double progress = i * 10.0;

                SimulationOuterClass.CreateSimulationMetadata metadata =
                        SimulationOuterClass.CreateSimulationMetadata.newBuilder()
                                .setProgressPercent(progress)
                                .build();

                Operation updated = Operation.newBuilder()
                        .setName(operationName)
                        .setDone(false)
                        .setMetadata(Any.pack(metadata))
                        .build();

                simd.putOperation(operationName, updated);
            }

            SimulationOuterClass.Simulation current = server.getSimulationForId(simId);
            if (current == null) {
                throw new IllegalStateException("Simulation not found for simId=" + simId);
            }

            SimulationOuterClass.Simulation finalSim = current.toBuilder()
                    .setState(SimulationOuterClass.Simulation.State.SUCCEEDED)
                    .build();

            server.setSimulation(simId, finalSim);

            Operation doneOp = Operation.newBuilder()
                    .setName(operationName)
                    .setDone(true)
                    .setResponse(Any.pack(finalSim))
                    .build();

            simd.putOperation(operationName, doneOp);
            logger.info("Simulation {} DONE", simId);

        } catch (Exception e) {
            com.google.rpc.Status status = com.google.rpc.Status.newBuilder()
                    .setCode(Code.INTERNAL_VALUE)
                    .setMessage(e.getMessage() == null ? "runSimulationAsync failed" : e.getMessage())
                    .build();

            Operation failed = Operation.newBuilder()
                    .setName(operationName)
                    .setDone(true)
                    .setError(status)
                    .build();

            simd.putOperation(operationName, failed);
            logger.error("runSimulationAsync failed for simId={}", simId, e);
        }
    }

    @Override
    public void getSimulation(SimulationOuterClass.GetSimulationRequest request,
                              StreamObserver<SimulationOuterClass.Simulation> responseObserver) {

        String fsimname = request.getName();
        String[] parts = fsimname.split("/");
        String simname = parts[parts.length - 1];

        SimulationOuterClass.Simulation sim = server.getSimulationForName(simname);
        if (sim == null) {
            sim = server.getSimulationForId(simname);
        }

        if (sim == null) {
            responseObserver.onError(Status.NOT_FOUND.withDescription("Simulation not found: " + request.getName()).asRuntimeException());
            return;
        }

        responseObserver.onNext(SimulationOuterClass.Simulation.newBuilder(sim).build());
        responseObserver.onCompleted();
    }

    @Override
    public void createAnalysis(SimulationOuterClass.CreateAnalysisRequest request,
                               StreamObserver<SimulationOuterClass.Analysis> responseObserver) {

        String analysisId = request.getAnalysisId();
        String parent = request.getParent();
        logger.info("CreateAnalysis analysisId={} parent={}", analysisId, parent);

        SimulationOuterClass.Analysis created = SimulationOuterClass.Analysis.newBuilder(request.getAnalysis()).build();

        // store and (re)build segments using AnalysisDelegation
        SimulationOuterClass.Analysis rebuilt = server.setAnalysis(parent, analysisId, created);

        responseObserver.onNext(rebuilt);
        responseObserver.onCompleted();
    }

    @Override
    public void getAnalysis(SimulationOuterClass.GetAnalysisRequest request,
                            StreamObserver<SimulationOuterClass.Analysis> responseObserver) {

        String fanname = request.getName();
        String[] parts = fanname.split("/");
        String aname = parts[parts.length - 1];

        SimulationOuterClass.Analysis analysis = server.getAnalysisForName(aname);
        if (analysis == null) {
            responseObserver.onNext(SimulationOuterClass.Analysis.newBuilder().build());
            responseObserver.onCompleted();
            return;
        }

        responseObserver.onNext(SimulationOuterClass.Analysis.newBuilder(analysis).build());
        responseObserver.onCompleted();
    }
}
