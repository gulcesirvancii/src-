package com.telesat.simulation;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation;
import com.google.longrunning.Operation;

public class SimulationDelegation {
    private Simulation delegatedSimulation;
    private final String simulationId;

    // LRO 
    private final Map<String, Operation> operations = new ConcurrentHashMap<>();

    public SimulationDelegation(String id, Simulation simulation) {
        this.simulationId = id;
        this.delegatedSimulation = simulation;
    }

    public Simulation getSimulation() { return delegatedSimulation; }
    public void setSimulation(Simulation simulation) { this.delegatedSimulation = simulation; }

    public String getSimulationId() { return simulationId; }

    public Operation getOperation(String operationName) {
        return operations.get(operationName);
    }

    public void putOperation(String operationName, Operation op) {
        operations.put(operationName, op);
    }
}
