package com.telesat.simulation;

import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass;
import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass.Simulation;

 /* Delegating class for Spacetime Simulation */
public class SimulationDelegation
{
    SimulationOuterClass.Simulation delegatedSimulation;

    String simulationId;

    public SimulationDelegation(String id, Simulation simulation) {
        this.simulationId = id;
        this.delegatedSimulation = simulation;
    }

    public Simulation getSimulation() {
        return this.delegatedSimulation;
    }
        
    public String getSimulationId() {
        return this.simulationId;
    }
}