package com.telesat.simulation;

import com.aalyria.spacetime.simulation.v1alpha.SimulationOuterClass;

/**
* Delegating class for Spacetime Scenario to keep all scenario related information
*/
public class ScenarioDelegation
{
    SimulationOuterClass.Scenario delegatedScenario;
        /* Scenario definition does not include 'scenarioId', so include in delegating class */
    String scenarioId;

    public ScenarioDelegation(String id, SimulationOuterClass.Scenario scenario) {
        this.scenarioId = id;
        this.delegatedScenario = scenario;
    }

    public SimulationOuterClass.Scenario getScenario() {
        return this.delegatedScenario;
    }

    public String getScenarioId() {
        return this.scenarioId;
    }
}

